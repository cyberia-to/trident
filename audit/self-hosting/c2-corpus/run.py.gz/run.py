"""Run unchanged semantic harnesses with the actual retained C2; no compiler build."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / 'trident'
JOY = ROOT / 'install-compiler-work-budget/bin/joy'
C2 = ROOT / 'measurements/body-scale-closure-20b-files-wnfaub83/result.dag'
CLOSURE = ROOT / 'measurements/body-scale-closure-20b.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


closure = json.loads(CLOSURE.read_text())
assert closure['status'] == 'compiler-returned'
assert sha(C2) == 'fe0390b92257edf58686e50571160fc7985b0883ede116c6dcfd0a9f7820b5d0'
assert sha(JOY) == '506f665b0567cf8d7d669f152153b72dbbbd4520e926a4f47955d2f0bef487b8'
sources = {row['path']: sha(REPO / row['path']) for row in closure['sources'].values()}
assert all(sources[row['path']] == row['sha256'] for row in closure['sources'].values())
jobs = [('main', 'run-native-compiler.py', 402),
        ('constants', 'check-guest-constant-linking.py', 31),
        ('callable', 'check-guest-function-imports.py', 32),
        ('types', 'check-guest-type-imports.py', 24),
        ('intrinsics', 'check-guest-intrinsics.py', 37),
        ('generated-profile', 'check-generated-compiler-profile.py', 21)]
inputs = dict(scope='Actual supplied C2 semantic corpus; independent raw Rust oracles stay reference-only',
              revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
              start=stamp(), compiler=str(C2), compiler_sha256=sha(C2),
              compiler_particle=C2.read_bytes()[8:40].hex(), binary=str(JOY), binary_sha256=sha(JOY),
              closure_receipt=str(CLOSURE), closure_receipt_sha256=sha(CLOSURE),
              source_sha256=sources, harness_sha256={str(path.relative_to(REPO)): sha(path)
                  for path in sorted((REPO / 'audit/self-hosting').glob('*.py'))},
              workers=2, env={'PYTHONDONTWRITEBYTECODE': '1'})
(OUT / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')


def run(job):
    name, script, expected = job
    receipt, log = OUT / (name + '.json'), OUT / (name + '.log')
    command = ['python3', str(REPO / 'audit/self-hosting' / script), '--joy', str(JOY),
               '--compiler', str(C2), '--output', str(receipt)]
    if name == 'main':
        command += ['--time-ms', '60000']
    report = dict(command=command, cwd=str(REPO), start=stamp(), expected_observations=expected,
                  status='running', receipt=str(receipt), log=str(log))
    path = OUT / (name + '-command.json')
    path.write_text(json.dumps(report, indent=2) + '\n')
    started = time.monotonic_ns()
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=REPO, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'},
                                stdout=stream, stderr=subprocess.STDOUT, check=False)
    report.update(status='finished', exit_code=result.returncode, end=stamp(),
                  elapsed_nanoseconds=time.monotonic_ns() - started, log_sha256=sha(log))
    if receipt.exists():
        data = json.loads(receipt.read_text())
        report.update(receipt_sha256=sha(receipt), receipt_status=data.get('status'),
                      commands=len(data.get('commands', [])), observations=len(data.get('observations', [])))
    path.write_text(json.dumps(report, indent=2) + '\n')
    return name, report


results = {}
with ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(run, job) for job in jobs]
    for future in as_completed(futures):
        name, report = future.result()
        results[name] = report
        print(json.dumps(dict(corpus=name, **report)), flush=True)
unchanged = sha(C2) == inputs['compiler_sha256'] and sha(JOY) == inputs['binary_sha256']
unchanged = unchanged and all(sha(REPO / name) == value for name, value in sources.items())
summary = dict(scope=inputs['scope'], inputs_unchanged=unchanged, results=results, end=stamp(),
               passed=unchanged and all(r['exit_code'] == 0 and r.get('receipt_status') == 'passed'
                   and r.get('observations') == r['expected_observations'] for r in results.values()))
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(passed=summary['passed'], inputs_unchanged=unchanged)), flush=True)

import hashlib,json,os,pathlib,subprocess,time
ROOT=pathlib.Path.cwd();HERE=ROOT.parent/'measurements/lexer-frame'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
metadata=json.loads(subprocess.check_output(['cargo','metadata','--locked','--offline','--no-deps','--format-version','1'],text=True))
package=next(p for p in metadata['packages'] if p['manifest_path']==str(ROOT/'Cargo.toml'))
covered=['native_compiler','native_lexer_frames']
targets=[t['name'] for t in package['targets'] if t['kind']==['test'] and t['test']]
remaining=[t for t in targets if t not in covered]
command=['cargo','test','--release','--locked','--offline','--lib','--bins']
for name in remaining:command+=['--test',name]
command+=['--','--test-threads=4']
env=dict(os.environ,CARGO_TARGET_DIR=str(ROOT.parent/'target-lexer'))
paths=['lib/std/compiler/nox/lexer.tri','tests/native_lexer_frames.rs','tests/fixtures/native_lexer_frames.tri','tests/fixtures/native_lexer_frames_before.tri']
report=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_hashes={p:sha(ROOT/p) for p in paths},covered_in_other_run=covered,other_log='native-focused-v9.log',all_integration_targets=targets,remaining_targets=remaining,environment=dict(CARGO_TARGET_DIR=env['CARGO_TARGET_DIR']),commands=[],status='running')
receipt=HERE/'remaining-v9.json'
with receipt.open('x') as file:
 def flush():
  file.seek(0);file.truncate();json.dump(report,file,indent=2);file.write('\n');file.flush()
 flush()
 for name,cmd in [('remaining-tests-v9',command),('doc-tests-v9',['cargo','test','--release','--locked','--offline','--doc','--','--test-threads=4'])]:
  row=dict(command=cmd,log=name+'.log',status='running');report['commands'].append(row);flush();start=time.monotonic_ns()
  with (HERE/row['log']).open('xb') as output:p=subprocess.run(cmd,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
  row.update(status='completed',exit_code=p.returncode,elapsed_nanoseconds=time.monotonic_ns()-start,log_sha256=sha(HERE/row['log']));flush()
  if p.returncode:report['status']='failed';flush();raise SystemExit(p.returncode)
 assert all(sha(ROOT/p)==h for p,h in report['source_hashes'].items())
 report['status']='passed';flush();print(json.dumps(report))

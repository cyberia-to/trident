"""Bind the complete split Cargo gate to exact captured source and raw logs."""
import gzip,hashlib,json,pathlib,re
ROOT=pathlib.Path.cwd();BASE=ROOT.parent/'measurements/lexer-frame';OUT=ROOT/'audit/self-hosting/lexer-frame-chunks'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_text())
gate=read(OUT/'full-gate.json');assert gate['status']=='running'
metadata=json.loads(gzip.decompress((OUT/gate['cargo_metadata']['path']).read_bytes()))
package=next(p for p in metadata['packages'] if p['manifest_path']==str(ROOT/'Cargo.toml'))
by_path={str(pathlib.Path(t['src_path']).relative_to(ROOT)):f"{t['kind'][0]}:{t['name']}" for t in package['targets'] if t['test'] and t['kind'][0] in ['lib','bin','test']}
remaining=read(BASE/'remaining-v9.json');assert remaining['status']=='passed'
supplemental=read(BASE/'component-reviewed-v9-command.json');assert supplemental['exit_code']==0
keys=['passed','failed','ignored','filtered_out']
def empty():return {key:0 for key in keys}
def add(a,b):
 for key in keys:a[key]+=b[key]
combined=[];coverage=[];counts=dict(primary=empty(),supplemental=empty(),observed=empty())
for row in gate['commands']:
 path=BASE/(row['id']+'.log');raw=path.read_bytes();text=raw.decode();suites=[];target=None
 for line in text.splitlines():
  match=re.match(r'\s*Running (?:unittests )?(.+?) \(',line)
  if match:target=by_path[match.group(1)]
  match=re.match(r'\s*Doc-tests (\S+)',line)
  if match:target='doc:'+match.group(1)
  match=re.match(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
  if match:
   assert target is not None and match.group(1)=='ok' and match.group(3)=='0',line
   suites.append(dict(target=target,passed=int(match.group(2)),failed=int(match.group(3)),ignored=int(match.group(4)),filtered_out=int(match.group(6))))
   target=None
 assert sorted(row['targets'])==sorted(s['target'] for s in suites),(row['id'],suites)
 assert not re.search(r'^warning(?:\[|:)',text,re.M),row['id']
 result=empty()
 for suite in suites:add(result,suite)
 assert result['failed']==0 and result['filtered_out']==0
 row.update(exit_code=0,raw_sha256=sha(raw),raw_bytes=len(raw),suite_results=suites,counts=result)
 if row['kind']=='primary':coverage+=row['targets']
 add(counts[row['kind']],result);add(counts['observed'],result)
 stored=gzip.compress(raw,mtime=0);(OUT/row['raw_log']).write_bytes(stored);row['stored_sha256']=sha(stored);combined.append(raw)
assert len(coverage)==len(set(coverage)) and sorted(coverage)==sorted(gate['coverage']['metadata_targets'])
for row in gate['sources']:
 b=(ROOT/row['path']).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes']
assert all(sha((ROOT/path).read_bytes())==h for path,h in supplemental['source_hashes'].items())
raw=b''.join(combined);stored=gzip.compress(raw,mtime=0);(OUT/'full-rust.log.gz').write_bytes(stored)
gate['combined_log']=dict(path='full-rust.log.gz',encoding='gzip',raw_sha256=sha(raw),stored_sha256=sha(stored),raw_bytes=len(raw),ordered_commands=[r['id'] for r in gate['commands']],ordered_raw_logs=[r['raw_log'] for r in gate['commands']],concatenation_only=True)
counts['unique']=dict(counts['primary']);gate['counts']=counts
gate['coverage'].update(covered_targets=coverage,missing_targets=[],unique_registered_tests=sum(counts['unique'][k] for k in ['passed','failed','ignored']),observed_test_executions=counts['observed']['passed']+counts['observed']['failed'])
check=(BASE/'check-v9.log').read_bytes();assert b'Finished ' in check and not re.search(rb'^warning(?:\[|:)|^error:',check,re.M)
(OUT/'check-v9.log.gz').write_bytes(gzip.compress(check,mtime=0))
gate['all_target_check']=dict(argv=['cargo','check','--release','--locked','--offline','--all-targets'],env={'CARGO_TARGET_DIR':'../target-lexer'},cwd=str(ROOT),exit_code=0,path='check-v9.log.gz',encoding='gzip',raw_sha256=sha(check),stored_sha256=sha((OUT/'check-v9.log.gz').read_bytes()))
gate['checks']=dict(warnings=0,failures=0,source_unchanged=True)
gate['status']='passed';(OUT/'full-gate.json').write_text(json.dumps(gate,indent=2)+'\n')
print(json.dumps(dict(status=gate['status'],counts=counts,covered_targets=len(coverage))))

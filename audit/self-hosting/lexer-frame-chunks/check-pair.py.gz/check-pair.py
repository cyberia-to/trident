"""Measure two frozen C0-built seeds with identical JOB1 cases and explicit caps."""
import hashlib,json,pathlib,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
HERE=pathlib.Path(__file__).resolve().parent
JOY=ROOT/'install-compiler-work-budget/bin/joy'
HOST=['--arena-nodes','1000000000','--budget','20000000000','--frames','65536','--time-ms','3600000','--validation-visits','16777216','--resident-nodes','3145728','--collection-work','10000000000']
LIMITS=dict(modules=128,diagnostics=16,sequence_length=65536,validation_visits=16777216,artifact_bytes=16777216,artifact_nodes=196608,artifact_depth=4096,reductions=20000000000,arena_nodes=1000000000,evaluator_frames=65536)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def padded(n):
 a,b=b'program sample //',b'\nfn main()->Field{13}'
 return a+b' '*(n-len(a)-len(b))+b
cases=[('baseline',b'program sample fn main()->Field{13}',0),('valid4096',padded(4096),0),('valid65536',padded(65536),0),('diagnostic',b'program sample //'+b' '*4096+b'\nfn main()->Field{missing}',5),('exact65536',b'\xff'+bytes(65535),1),('excess65537',b'\xff'+bytes(65536),7)]
assert padded(65536)==(HERE.parent/'lexer-frame-baseline-valid65536.tri').read_bytes()
receipt=HERE/'pair.json'
report=dict(scope='paired C0-built C1 lexer experiment; no C2 claim',joy_sha256=sha(JOY),host_flags=HOST,source_capture_sha256=sha(HERE/'capture.json'),script_sha256=sha(pathlib.Path(__file__)),variants=[])
with receipt.open('x') as file:
 def flush():
  file.seek(0);file.truncate();json.dump(report,file,indent=2);file.write('\n');file.flush()
 def run(argv,row):
  assert sha(JOY)==report['joy_sha256']
  start=time.monotonic_ns();p=subprocess.run([str(JOY),*map(str,argv)],capture_output=True,text=True,timeout=3660)
  c=dict(command=[str(JOY),*map(str,argv)],exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,elapsed_nanoseconds=time.monotonic_ns()-start)
  row['commands'].append(c);flush();return json.loads(p.stdout) if p.stdout.lstrip().startswith('{') else None
 for variant in ['before','after']:
  compiler=HERE/(variant+'.dag');record=dict(variant=variant,compiler_sha256=sha(compiler),compiler_particle=compiler.read_bytes()[8:40].hex(),observations=[]);report['variants'].append(record)
  baseline=None
  for name,source,code in cases:
   directory=HERE/(variant+'-'+name);directory.mkdir();path=directory/'sample.tri';path.write_bytes(source)
   limits=dict(LIMITS,source_bytes=len(source));manifest=dict(version=1,entry_module='sample',entry_function='main',modules=[dict(logical_path='sample',file='sample.tri',origin_name='source-capacity',origin_version='1')],options=dict(target=0,input_profile=0,output_profile=0,optimization=0,cfg_flags=[]),limits=limits)
   package=directory/'package.json';package.write_text(json.dumps(manifest,indent=2)+'\n');job=directory/'job.dag';program=directory/'result.dag'
   row=dict(case=name,source_sha256=sha(path),source_bytes=len(source),expected_diagnostic=code,manifest=manifest,commands=[]);record['observations'].append(row)
   pack=run(['pack-job','--compiler',compiler,'--manifest',package,'-o',job,*HOST],row)
   assert pack['ok'] and pack['package']['compiler_particle']==record['compiler_particle'];row['job_sha256']=sha(job)
   result=run(['run-artifact',compiler,'--input',job,'--emit','result' if code else 'program','-o',program,*HOST],row);row['execution']=result
   if row['commands'][-1]['exit_code']:
    row['status']='runtime-failed';flush();continue
   assert result['ok'];execution=result['execution'];compiled=execution['compiler_job']
   assert execution['program_particle']==record['compiler_particle'] and execution['input_particle']==pack['package']['job_particle'];assert compiled['limits']==limits
   if code:
    assert compiled['status']=='compile_error' and len(compiled['diagnostics'])==1 and compiled['diagnostics'][0]['code']==code
    if name=='diagnostic':
     d=compiled['diagnostics'][0];assert source[d['start_byte']:d['end_byte']]==b'missing'
   else:
    assert compiled['status']=='success'
    if baseline is None:baseline=program.read_bytes()
    assert program.read_bytes()==baseline;row['baseline_artifact_equal']=True
   row['status']='passed';row['result_sha256']=sha(program);flush()
  assert sha(compiler)==record['compiler_sha256']
 report['status']='completed';flush()
 print(json.dumps([(r['variant'],[(o['case'],o['status']) for o in r['observations']]) for r in report['variants']]))

"""Retain exact 0.4 merge identities and local documentation integration checks."""
import gzip,hashlib,json
from pathlib import Path
R=Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap');M=R/'measurements'
OUT=R/'trident/audit/self-hosting/bootstrap-results/native-acceptance-integration'
def require(ok,msg):
 if not ok:raise ValueError(msg)
def digest(raw):return hashlib.sha256(raw).hexdigest()
selected={};merges=[]
for path in sorted((M/'sh6-integration').rglob('*')):
 if path.is_file():selected['merges/'+path.relative_to(M/'sh6-integration').as_posix()]=path
 if path.name=='receipt.json':
  row=json.loads(path.read_bytes());require(row['status']=='passed' and row['base_ref']=='release/0.4' and row['expected_tree']==row['actual_tree'],'reviewed 0.4 merge');merges.append({k:row[k] for k in ('repository','pr','base','head','merge','actual_tree')})
require({(r['repository'],r['pr']) for r in merges}=={('joy',22),('joy',23),('trident',112),('trident',113),('trident',114),('trisha',18),('trisha',19)},'all seven reviewed feature merges')
for name in ('merge-accepted-pr.py','merge-accepted-pr-v2.py',Path(__file__).name):selected['commands/'+name]=M/name
for name in ('trident-sh6-accepted-install.log','trident-sh6-integrated-install.log','trident-sh6-integrated-actionlint.log','trident-sh6-integrated-source-tests.log'):
 path=Path('/tmp')/name;require(path.is_file(),'actual integration log');selected['local/'+name]=path
for path in sorted((M/'accepted-selfhost-kit/postinstall').glob('*')):
 if path.is_file():selected['kit-postinstall/'+path.name]=path
require(json.loads((M/'accepted-selfhost-kit/postinstall/receipt.json').read_bytes())['status']=='passed','kit postcommit install')
for path in sorted((M/'sh6-integration-root-review').glob('*')):
 if path.is_file():selected['review/'+path.name]=path
selected['review/review-sh6-integration-root.py']=M/'review-sh6-integration-root.py'
require(json.loads((M/'sh6-integration-root-review/review.json').read_bytes())['status']=='passed','root integration review')
report=dict(schema='trident/native-acceptance-integration/v1',status='passed',merges=merges,files={})
OUT.mkdir()
for name,path in sorted(selected.items()):
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=OUT/(name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed);require(gzip.decompress(destination.read_bytes())==path.read_bytes(),'byte-exact original');report['files'][name]=dict(bytes=len(raw),sha256=digest(raw),compressed_bytes=len(packed),compressed_sha256=digest(packed))
(OUT/'retention.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','merges':len(merges),'retained_files':len(selected)}))

"""Root review of exact integration commits and final documentation bindings."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap');M=R/'measurements';T=R/'trident'
OUT=M/'sh6-integration-root-review';OUT.mkdir()
def require(ok,label):
 if not ok:raise ValueError(label)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
rows=[]
for path in sorted((M/'sh6-integration').glob('*/receipt.json')):
 d=json.loads(path.read_bytes());repo=R/({'joy':'joy','trident':'trident','trisha':'trisha-selfhost-kit'}[d['repository']])
 require(d['status']=='passed' and d['base_ref']=='release/0.4','successful integration target')
 require(git(repo,'rev-parse',d['merge']+'^{tree}')==d['expected_tree']==d['actual_tree'],'exact merge tree')
 require(git(repo,'rev-list','--parents','-n','1',d['merge']).split()==[d['merge'],d['base'],d['head']],'exact parents')
 rows.append({k:d[k] for k in ('repository','pr','base','head','merge','actual_tree')})
require(len(rows)==7,'seven feature merges')
base='99c8a44f405ebd010c6075467b0e568e8bb7a590'
require(git(T,'rev-parse','HEAD')=='6bc98d3c'+git(T,'rev-parse','HEAD')[8:],'reviewed documentation integration head')
require(not git(T,'diff',base,'--name-only','--','src','compiler','lib','Cargo.toml','Cargo.lock','scripts','.github'),'implementation identical to accepted upstream')
paths=['.claude/plans/native-compiler-arena.md','README.md','audit/self-hosting-progress.md','docs/guides/README.md','docs/guides/self-hosted-compilation.md','reference/roadmap.md','docs/explanation/vision.md','docs/explanation/atlas.md']
files={p:dict(bytes=(T/p).stat().st_size,sha256=sha(T/p)) for p in paths}
kit=R/'trisha-selfhost-kit/audit/selfhost-kit/accepted/selfhost-kit.tar.gz';require(sha(kit)=='a3052d95c3de6d622157988a8e74826b2f0140724a634298458c3d75f6b508bd','retained accepted kit')
for p in ['docs/guides/self-hosted-compilation.md','audit/self-hosting-progress.md']:
 text=(T/p).read_text();require('c66c2da3da0d5b1da55f09be533a4d664d585bb2' in text and sha(kit) in text and 'SH7/SH8' in text,'actual kit reference and proof scope')
require(sum(len(p.read_text().splitlines()) for p in (T/'.claude').rglob('*.md'))==1000,'memory line budget')
subprocess.run(['git','diff','--check'],cwd=T,check=True)
post=M/'accepted-selfhost-kit/postinstall/receipt.json';d=json.loads(post.read_bytes());require(d['status']=='passed' and d['warnings']==[] and d['family_before']==d['family_after'],'completed clean kit install')
for c in d['commands']:
 require(c['status']=='completed' and c['exit_code']==0,'actual completed install command')
 for part in ('stdout','stderr'):
  p=post.parent/(c['name']+'.'+part);require(c[part]==dict(bytes=p.stat().st_size,sha256=sha(p)),'exact raw install log')
require(sha(Path(d['binary']['path']))==d['binary']['sha256'],'actual installed binary')
report=dict(status='passed',reviewer='root',scope='Exact seven integration merge trees/parents and final documentation/kit/postinstall bindings; original independent acceptance and kit reviews remain separate',command=[sys.executable,*sys.argv],source_head=git(T,'rev-parse','HEAD'),integration_base=base,merges=rows,files=files,kit_sha256=sha(kit),postinstall_receipt_sha256=sha(post),compiler_runtime_workflow_source_unchanged=True)
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','merges':len(rows),'documents':len(files),'reviewer':'root'}))

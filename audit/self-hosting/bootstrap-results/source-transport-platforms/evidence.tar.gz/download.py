import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parent
RUN=36400752982
REPO='cyberia-to/trident'
HEAD='85ab2d3f33d4e5d5e057600782aeb99bed2dfeb2'

def identity(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def get(name,endpoint):
 argv=['gh','api',endpoint]
 start=time.time_ns()
 with (ROOT/name).open('xb') as out,(ROOT/(name+'.stderr')).open('xb') as err:
  p=subprocess.run(argv,stdout=out,stderr=err,timeout=180)
 row=dict(argv=argv,started_ns=start,ended_ns=time.time_ns(),exit_code=p.returncode,
          stdout=dict(path=name,**identity(ROOT/name)),stderr=dict(path=name+'.stderr',**identity(ROOT/(name+'.stderr'))))
 with (ROOT/(name+'.command.json')).open('x') as out:out.write(json.dumps(row,indent=2)+'\n')
 if p.returncode:raise RuntimeError('GitHub read failed: '+name)
 return row

def load(name):return json.loads((ROOT/name).read_bytes())
base=f'repos/{REPO}/actions'
get('run-final.json',f'{base}/runs/{RUN}')
run=load('run-final.json')
assert run['id']==RUN and run['head_sha']==HEAD and run['run_attempt']==1
assert run['status']=='completed' and run['conclusion']=='success'
initial=[('run-attempt-1.json',f'{base}/runs/{RUN}/attempts/1'),
 ('jobs.json',f'{base}/runs/{RUN}/attempts/1/jobs?per_page=100'),
 ('artifacts.json',f'{base}/runs/{RUN}/artifacts?per_page=100'),
 ('run-logs.zip',f'{base}/runs/{RUN}/attempts/1/logs')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for r in pool.map(lambda v:get(*v),initial): pass
jobs=load('jobs.json');artifacts=load('artifacts.json')
assert jobs['total_count']==len(jobs['jobs'])==6
assert artifacts['total_count']==len(artifacts['artifacts'])==6
requests=[]
for row in jobs['jobs']:
 assert row['run_id']==RUN and row['head_sha']==HEAD and row['status']=='completed' and row['conclusion']=='success'
 requests += [(f"job-{row['id']}-direct.json",f"{base}/jobs/{row['id']}"),
              (f"job-{row['id']}-api.log",f"{base}/jobs/{row['id']}/logs")]
for row in artifacts['artifacts']:
 requests += [(f"artifact-{row['id']}-api.json",f"{base}/artifacts/{row['id']}"),
              (f"artifact-{row['id']}.zip",f"{base}/artifacts/{row['id']}/zip")]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for r in pool.map(lambda v:get(*v),requests):pass
get('run-final-recheck.json',f'{base}/runs/{RUN}')
print(json.dumps(dict(status='downloaded',jobs=len(jobs['jobs']),artifacts=len(artifacts['artifacts']))))

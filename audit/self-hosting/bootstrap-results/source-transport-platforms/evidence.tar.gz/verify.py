"""Read-only independent verification of original six-platform transport CI bytes."""
import ast
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT=Path(__file__).resolve().parent
HEAD='85ab2d3f33d4e5d5e057600782aeb99bed2dfeb2'
RUN=36400752982
REPO='cyberia-to/trident'
WORKFLOW='.github/workflows/selfhost-source-transport.yml'
BRANCH='test/0.4-source-transport-platforms'
TARGETS={
 'aarch64-apple-darwin':('macos-15','arm64'),
 'x86_64-apple-darwin':('macos-15-intel','x86_64'),
 'aarch64-unknown-linux-gnu':('ubuntu-24.04-arm','aarch64'),
 'x86_64-unknown-linux-gnu':('ubuntu-24.04','x86_64'),
 'aarch64-pc-windows-msvc':('windows-11-arm','arm64'),
 'x86_64-pc-windows-msvc':('windows-2022','amd64')}
SOURCE_HASHES={
 WORKFLOW:'fe99ca870db0a3dff6a02f2ed1072c6324b5e1772512edc5908e4fa71370814e',
 'audit/self-hosting/check-source-transport.py':'4831f011b0ae5a04ad843b9d2ecd485514eb2563bc7b4ab9524bfc121a1e2e4d',
 'scripts/prepare-selfhost-source.py':'4f2381880f7da77265ed562cb99bc0e7bcad4c5f7df28f8c62bf7a37f55c3711',
 'scripts/test_prepare_selfhost_source.py':'625553777cf2df5cf778ddb870f2714dfe7b1b6f171663fe5442d3c01b235dfd'}


def require(ok,label):
 if not ok:raise ValueError(label)
def identity(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def file(path):return identity(path.read_bytes())
def load(name):return json.loads((ROOT/name).read_bytes())
def native_path(value):return value.replace('\\','/').rstrip('/')

report=dict(schema='trident/source-transport-ci-independent/v1',status='running',run=RUN,attempt=1,head=HEAD,
            verifier=file(Path(__file__)),scope='Six native byte-preparation guard jobs only; no SH6, compiler execution or proof gate',targets=[])
try:
 for name in ('run-final.json','run-final-recheck.json','run-attempt-1.json'):
  run=load(name)
  require(run['id']==RUN and run['head_sha']==HEAD and run['head_branch']==BRANCH and run['run_attempt']==1,'run identity')
  require(run['status']=='completed' and run['conclusion']=='success' and run['event']=='push','original final verdict')
  require(run['path']==WORKFLOW and run['repository']['full_name']==REPO,'workflow repository')
 source=load('source.json')
 require(source['revision']==HEAD and source['compiler_source_files']==94,'source snapshot revision/closure')
 for row in source['files']:
  require(file(ROOT/'source'/row['path'])=={k:row[k] for k in ('bytes','sha256')},'exact retained source: '+row['path'])
 for name,digest in SOURCE_HASHES.items():require(file(ROOT/'source'/name)['sha256']==digest,'independently pinned source')
 parsed=ast.parse((ROOT/'source/scripts/test_prepare_selfhost_source.py').read_text())
 expected_tests={node.name for node in ast.walk(parsed) if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}
 require(len(expected_tests)==21,'21 actual named test cases')
 jobs=load('jobs.json')['jobs']; artifacts=load('artifacts.json')['artifacts']
 require(load('jobs.json')['total_count']==len(jobs)==6 and load('artifacts.json')['total_count']==len(artifacts)==6,'exact job/artifact counts')
 by_target={j['name'].removeprefix('Source transport '):j for j in jobs}
 require(set(by_target)==set(TARGETS) and len({j['id'] for j in jobs})==6,'six distinct native jobs')
 by_name={a['name']:a for a in artifacts}
 require(set(by_name)=={f'source-transport-{t}-attempt-1' for t in TARGETS} and len({a['id'] for a in artifacts})==6,'six distinct original artifacts')
 for target,(label,machine) in TARGETS.items():
  job=by_target[target];direct=load(f"job-{job['id']}-direct.json")
  require(direct==job,'direct original job equals final listing')
  require(job['run_id']==RUN and job['head_sha']==HEAD and job['run_attempt']==1 and job['status']=='completed' and job['conclusion']=='success','job source/run/verdict')
  require(job['labels']==[label] and bool(job['runner_name']) and all(s['conclusion']=='success' for s in job['steps']),'native runner and completed steps')
  artifact=by_name[f'source-transport-{target}-attempt-1'];meta=load(f"artifact-{artifact['id']}-api.json")
  require(meta==artifact and meta['expired'] is False,'direct original artifact metadata')
  require(meta['workflow_run']['id']==RUN and meta['workflow_run']['head_sha']==HEAD and meta['workflow_run']['head_branch']==BRANCH,'artifact origin')
  archive=ROOT/f"artifact-{artifact['id']}.zip";zip_identity=file(archive)
  require(zip_identity['bytes']==meta['size_in_bytes'] and 'sha256:'+zip_identity['sha256']==meta['digest'],'original GitHub ZIP digest and size')
  job_log=(ROOT/f"job-{job['id']}-api.log").read_text(encoding='utf-8')
  require(HEAD in job_log and '--target '+target in job_log and meta['name'] in job_log and zip_identity['sha256'] in job_log and str(meta['id']) in job_log,'job log source/route/upload identity')
  with zipfile.ZipFile(archive) as zip:
   names={'receipt.json',*[f'{mode}.{ext}' for mode in ('ordinary','optimized') for ext in ('json','stdout','stderr')]}
   require(set(zip.namelist())==names and len(zip.infolist())==7 and zip.testzip() is None,'complete original ZIP members/CRC')
   require(all(0<=m.file_size<=1<<20 and not m.is_dir() for m in zip.infolist()),'bounded ordinary receipt members')
   raw={name:zip.read(name) for name in names}
  receipt=json.loads(raw['receipt.json'])
  require(receipt['schema']=='trident/native-source-transport/v1' and receipt['status']=='passed','native transport success')
  require(receipt['target']==receipt['native_target']==target and receipt['machine']==machine and receipt['python'].startswith('3.13.'),'actual native Python platform')
  require(receipt['revision']==HEAD,'actual checkout revision')
  origin=dict(repository=REPO,run_id=str(RUN),run_attempt='1',event_name='push',workflow_ref=REPO+'/'+WORKFLOW+'@refs/heads/'+BRANCH,head_sha=HEAD)
  require(receipt['ci_origin']==origin,'exact reported CI origin')
  for key,name in [('implementation','audit/self-hosting/check-source-transport.py'),('tests','scripts/test_prepare_selfhost_source.py'),('preparer','scripts/prepare-selfhost-source.py')]:
   require(receipt[key]==file(ROOT/'source'/name),'actual tested source: '+key)
  require(set(receipt['files'])==names-{'receipt.json'},'complete receipt raw manifest')
  for name,row in receipt['files'].items():require(identity(raw[name])==row,'raw outcome/log binding')
  require(len(receipt['commands'])==2,'exact two interpreter modes')
  outcomes=[]
  for n,mode in enumerate(('ordinary','optimized')):
   outcome=json.loads(raw[mode+'.json']);command=receipt['commands'][n]
   require(outcome['tests']==21 and outcome['successful'] is True and outcome['optimize']==n and all(outcome[k]==0 for k in ('failures','errors','expected_failures','unexpected_successes')),'actual mode test counts')
   cwd=native_path(command['cwd']);argv=list(map(native_path,command['argv']))
   expected=[native_path(receipt['executable']),'-B','-W','error',*(['-O'] if n else []),cwd+'/audit/self-hosting/check-source-transport.py','--worker','--output',cwd+'/transport-results/'+mode+'.json']
   require(argv==expected and command['exit_code']==0,'exact source-bound child route')
   require(raw[mode+'.stdout']==b'','no substituted stdout test result')
   log=raw[mode+'.stderr'].decode('utf-8')
   lines={}
   for line in log.splitlines():
    match=re.fullmatch(r'(test_\w+) \(source_transport_tests.Preparation.\1\) \.\.\. (.+)',line)
    if match:
     require(match[1] not in lines,'unique raw test outcome');lines[match[1]]=match[2]
   require(set(lines)==expected_tests and 'Ran 21 tests in ' in log,'all named raw tests')
   skips={row['test'].split(' ')[0]:row['reason'] for row in outcome['skips']}
   require(len(skips)==len(outcome['skips']),'distinct skips')
   classifications=[]
   for name,reason in skips.items():
    if name=='test_case_alias_of_input_parent_cannot_receive_output' and reason=='filesystem has case-sensitive directory names':
     classifications.append('case-sensitive filesystem: case-alias capability not available')
    elif name=='test_source_and_parent_symlinks_reject' and reason=='Windows symlink privilege is unavailable (WinError 1314)' and 'windows' in target:
     classifications.append('Windows symlink privilege unavailable; symlink guard not executed')
    else:raise ValueError('unexpected skipped capability: '+repr((target,name,reason)))
   for name,result in lines.items():require(result==('skipped '+repr(skips[name]) if name in skips else 'ok'),'raw test success/skip consistency')
   require(log.rstrip().endswith('OK'+(f' (skipped={len(skips)})' if skips else '')),'raw unittest summary')
   outcomes.append(dict(mode=mode,selected=21,passed=21-len(skips),skipped=len(skips),skip_details=outcome['skips'],skip_classification=classifications,optimize=n))
  report['targets'].append(dict(target=target,machine=machine,python=receipt['python'],job_id=job['id'],runner_label=label,artifact_id=meta['id'],artifact_name=meta['name'],zip=zip_identity,receipt=identity(raw['receipt.json']),raw_files={name:identity(data) for name,data in raw.items()},outcomes=outcomes))
 archive_rows=[]
 with zipfile.ZipFile(ROOT/'run-logs.zip') as logs:
  require(logs.testzip() is None,'whole original run log CRC')
  for row in logs.infolist():
   require(row.file_size<=32<<20,'bounded run log member')
   archive_rows.append(dict(path=row.filename,**identity(logs.read(row))))
 report.update(status='passed',unique_test_cases=21,native_targets=6,interpreter_modes=2,
               selected_case_executions=sum(o['selected'] for t in report['targets'] for o in t['outcomes']),
               passed_case_executions=sum(o['passed'] for t in report['targets'] for o in t['outcomes']),
               skipped_case_executions=sum(o['skipped'] for t in report['targets'] for o in t['outcomes']),
               run_logs=dict(**file(ROOT/'run-logs.zip'),members=archive_rows))
except BaseException as error:
 report.update(status='failed',error=type(error).__name__+': '+str(error));raise
finally:
 output=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'verification.json')
 with output.open('x') as stream:stream.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('targets','run_logs')},sort_keys=True))

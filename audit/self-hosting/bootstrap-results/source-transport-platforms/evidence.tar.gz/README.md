# Native source-transport CI: independent read-only retention

Run [36400752982](https://github.com/cyberia-to/trident/actions/runs/36400752982), attempt 1,
head `85ab2d3f33d4e5d5e057600782aeb99bed2dfeb2`, branch
`test/0.4-source-transport-platforms`, completed successfully. This narrow
workflow tests portable source preparation only. It is not SH6, a compiler
execution, accepted-kit delivery or compilation proof gate.

Original final/attempt REST, all six listed and direct job responses, each
direct job log, complete run-log ZIP, all six artifact API responses and
original download ZIPs are retained without byte rewriting. Every GitHub
artifact size and SHA-256 matches its ZIP, and its native job upload log
contains the same name, ID and digest. Original command/exit/stderr receipts
accompany every read-only `gh api` request. No store or repository was changed.

| Native target | Ordinary passed / skipped | Optimized passed / skipped |
|---|---:|---:|
| `aarch64-apple-darwin` | 21 / 0 | 21 / 0 |
| `x86_64-apple-darwin` | 21 / 0 | 21 / 0 |
| `aarch64-unknown-linux-gnu` | 20 / 1 | 20 / 1 |
| `x86_64-unknown-linux-gnu` | 20 / 1 | 20 / 1 |
| `aarch64-pc-windows-msvc` | 21 / 0 | 21 / 0 |
| `x86_64-pc-windows-msvc` | 21 / 0 | 21 / 0 |

There are 21 distinct cases. Across six native targets and two interpreter
modes there were 252 selections: 248 passed and 4 skipped. The four skips
are the same case-alias capability test on both Linux filesystems in both
modes, explicitly reporting case-sensitive directory names. macOS and
Windows ran all 21 cases without skips. In particular, Windows did not use
the WinError1314 symlink-privilege skip. No failures, errors, expected failures
or unexpected successes occurred. Repeated interpreter modes are not counted
as new distinct tests. Actual Python was 3.13.15 on every platform.

`verification.json` independently binds original run/head/attempt/origin,
exact six native runner labels and Python architecture, pinned source bytes,
both exact worker commands, optimization flags 0/1, all named raw unittest
outcomes, raw stdout/stderr hashes and supported skip reasons. It checks the
whole run-log ZIP CRC and lists every log member identity. The optimized
checker repeated the same read-only validation; it ran no native tests.

Committed source snapshot includes the workflow, runner, helper, focused
guards, fixture metadata, historical C2/inventory and all94 frozen sources.
The runner SHA is `4831f011b0ae5a04ad843b9d2ecd485514eb2563bc7b4ab9524bfc121a1e2e4d`;
workflow SHA is `fe99ca870db0a3dff6a02f2ed1072c6324b5e1772512edc5908e4fa71370814e`.
Helper SHA remains `4f2381880f7da77265ed562cb99bc0e7bcad4c5f7df28f8c62bf7a37f55c3711`;
guards SHA remains `625553777cf2df5cf778ddb870f2714dfe7b1b6f171663fe5442d3c01b235dfd`.
The source capture used `git show 85ab2d3f:PATH`; it did not build or execute
any compiler. All byte identities appear in `source.json` and `files.json`.

Read-only verification command (choose a fresh report filename):

```sh
python3 -B -W error verify.py replay-verification.json
```

Downloading and validation completed in this measurement directory. The
accepted-kit driver remains separately prepared and unexecuted pending root’s
explicit original final36 acceptance message.

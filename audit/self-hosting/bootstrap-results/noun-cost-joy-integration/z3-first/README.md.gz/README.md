# Retained first Z3 follow-up attempt

The exact existing formal test passed, and the real good/bad CLI audits returned
0/1 with safe/unsafe verdicts. The attempt nevertheless failed its executable
identity guard: the explicit PATH mistakenly placed Rustup before Homebrew,
so Cargo rebuilt Trident with a different Rust distribution and replaced the
untracked `target-noun-cost-joy/release/trident` build product. This is a
measurement-harness failure, not an accepted unchanged-binary run.

The original 55 integration evidence files remain byte-exact. All nine source
worktrees remained clean and equal to the original recorded inputs. The
1,197-test result remains the historical observation recorded before this
follow-up; it is not relabeled as using the later binary.

`binary-replacement.json` records before/after binary identities and the search
for the original binary among Cargo dependency outputs. `original-trident` is
a byte-exact retained copy of the original binary, SHA256
`4160422e299e72ceedcfef29be99a36408273eee94a0fe84d378ed122945de1e`.
It was copied without replacing any build output or source file.

The corrected follow-up is retained separately in
`../noun-cost-z3-integration-2`. Both attempts repeat the same existing test;
neither adds a unique test to the original count.

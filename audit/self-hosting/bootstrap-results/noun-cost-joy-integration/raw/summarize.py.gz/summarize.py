#!/usr/bin/env python3
"""Derive per-package/target counts from retained Cargo output and metadata."""
import argparse
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent


def file(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def summarize(receipt_name, metadata_name, test_name):
    receipt = json.loads((OUT / receipt_name).read_text())
    if receipt['status'] != 'passed':
        raise ValueError('cannot summarize an unfinished or failed gate as passed')
    metadata = json.loads((OUT / metadata_name).read_text())
    members = set(metadata['workspace_default_members'])
    packages = [p for p in metadata['packages'] if p['id'] in members]
    targets = [(p, t) for p in packages for t in p['targets']]
    stderr = (OUT / (test_name + '.stderr')).read_text()
    stdout = (OUT / (test_name + '.stdout')).read_text()
    headers = []
    for line in stderr.splitlines():
        m = re.match(r'\s*Running (?:unittests )?(.+?) \((.+?)\)$', line)
        if m:
            relative, binary = m.groups()
            stem = Path(binary).name.rsplit('-', 1)[0]
            found = [(p, t) for p, t in targets
                     if t['name'].replace('-', '_') == stem and t['src_path'].endswith('/' + relative)]
            if len(found) != 1:
                raise ValueError(('ambiguous target', line, found))
            p, t = found[0]
            headers.append({'package': p['name'], 'target': t['name'], 'kind': t['kind'],
                            'source': file(Path(t['src_path'])), 'binary': file(Path(binary))})
        m = re.match(r'\s*Doc-tests (.+)$', line)
        if m:
            found = [(p, t) for p, t in targets if 'lib' in t['kind'] and t['name'] == m[1]]
            if len(found) != 1:
                raise ValueError(('ambiguous doctest', line))
            p, t = found[0]
            headers.append({'package': p['name'], 'target': t['name'], 'kind': ['doctest'],
                            'source': file(Path(t['src_path']))})
    pattern = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;.*$', re.M)
    summaries = list(pattern.finditer(stdout))
    if len(headers) != len(summaries):
        raise ValueError(('target/result count mismatch', len(headers), len(summaries)))
    previous = 0
    totals = {}
    for row, match in zip(headers, summaries):
        counts = dict(zip(('passed', 'failed', 'ignored', 'measured', 'filtered_out'), map(int, match.groups()[1:])))
        tests = re.findall(r'^test (.+?) \.\.\. (ok|ignored|FAILED)(?:,.*)?$', stdout[previous:match.start()], re.M)
        previous = match.end()
        if counts['passed'] + counts['failed'] + counts['ignored'] != len(tests):
            raise ValueError(('test name/count mismatch', row['target'], counts, len(tests)))
        row.update(counts=counts, tests=[{'name': name, 'status': status} for name, status in tests])
        total = totals.setdefault(row['package'], dict.fromkeys(counts, 0))
        for key, value in counts.items():
            total[key] += value
    expected = {(p['name'], t['name'], tuple(t['kind'])) for p, t in targets if t['test'] and t['kind'] != ['custom-build']}
    expected |= {(p['name'], t['name'], ('doctest',)) for p, t in targets if 'lib' in t['kind'] and t['doctest']}
    actual = {(r['package'], r['target'], tuple(r['kind'])) for r in headers}
    if expected != actual:
        raise ValueError(('target coverage mismatch', expected - actual, actual - expected))
    return {'receipt': file(OUT / receipt_name), 'metadata': file(OUT / metadata_name),
            'stdout': file(OUT / (test_name + '.stdout')), 'stderr': file(OUT / (test_name + '.stderr')),
            'counts_by_package': totals, 'targets': headers,
            'counting': 'One execution of each named default-member test target and doctests. Checks and dependency builds add no test passes.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--joy-only', action='store_true')
    args = parser.parse_args()
    data = {'schema': 'local/noun-cost-integration-summary/v1', 'joy': summarize('receipt.json', 'metadata.stdout', 'test-default')}
    if not args.joy_only:
        data['trident'] = summarize('trident-receipt.json', 'trident-metadata.stdout', 'trident-test')
    path = OUT / ('joy-summary.json' if args.joy_only else 'summary.json')
    path.write_text(json.dumps(data, indent=2) + '\n')
    for name, row in data.items():
        if isinstance(row, dict):
            print(name, row['counts_by_package'], 'targets', len(row['targets']))


if __name__ == '__main__':
    main()

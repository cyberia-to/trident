# Noun/Cost downstream integration

This local run checks the existing Joy and Trident routes with the integrated
Zheng noun/Cost component. It supplies downstream compatibility evidence. It
does not extend native-platform SH6 acceptance or prove whole-compiler SH7.

The new real detached family is `../../noun-cost-joy-integration`. Exact nine
revisions, Git trees, clean status, resolved directory paths and manifest
identities are recorded before and after the gates. No source files, pins or
old integration families were edited. Raw stdout and stderr are retained
without whitespace normalization.

The four selected revisions are Trident
`57491633fbccb58ae44dca2da438ee31430be1bc`, Joy
`ec83bd8d85b20a8bd20d2d14b0f25aab0f75e9fe`, Nox
`172811b7746cdcd6ab198a3ed976dc6c19f55d5b`, and Zheng
`633e5ba980db94ca10d9d6b67cf24d9d3aef63a7`. The five other frozen pins
are recorded in both producer receipts. `source-comparison.json` retains the
exact Git commands showing unchanged Nox `rs/` relative to the previously
tested observer source and unchanged Trident compiler, library, test and Cargo
files relative to the earlier native bootstrap pin.

## Joy

`run.py` records preparation and each command in `receipt.json`. Its working
directory is the family's `joy/`; Cargo uses the isolated
`../../target-noun-cost-joy` directory:

```text
python3 scripts/check-soft3-boundary.py
cargo metadata --format-version 1 --locked --offline --all-features
cargo fmt -- --check
cargo check --workspace --all-targets --locked --offline
cargo check --workspace --all-targets --all-features --locked --offline
cargo test --workspace --release --locked --offline
```

The Joy run passed 172 tests: 58 in `cyber-joy` and 114 in `joy-rs`, with
0 failed, 0 ignored and 0 Rust warnings. The 27 target summaries include
the empty `joy_rs` doctest target. `joy-summary.json` derives individual
test names, package/target counts and complete target coverage from retained
Cargo metadata and stdout/stderr. Check configurations do not add test passes.
Both Joy packages declare no selectable Cargo features.

Existing tests exercise public execution, native private proving and fresh
verification, state roots and tables, changed public outputs, retired proof
envelopes, and refusal of foreign targets/resources. The boundary script
reports 145 resolved packages, Trident compiler features `[]`, and no foreign
VM/prover dependency. `dependency-resolution.json` independently checks all
24 local packages resolve inside this real family. No whole guest compiler
self-build was rerun.

## Trident

`trident.py` records its separate commands in `trident-receipt.json` after
Joy's gates finish, using the same family and target directory sequentially:

```text
cargo metadata --format-version 1 --no-deps --locked --offline
cargo check --all-targets --locked --offline
cargo test --release --locked --offline -- --test-threads=4
```

These select Trident's supported default root package and all its ordinary
test targets and doctests. The optional neural configuration is outside this
run. The completed run passed 1,197 tests, with 0 failed, 5 existing ignored
diagnostics and 0 Rust warnings. All 46 test-target summaries, including
doctests, match the expected Cargo metadata targets. All 188 native compiler
tests and both lexer-frame tests passed. `trident-example-builds.json` retains
the 21 release example binaries built by the test command; these are not
counted as test executions.

The complete `summary.json` is derived by `python3 -B summarize.py`. Its
package/target counts remain separate from Joy's counts. `before.json`,
`after.json`, `trident-before.json` and `trident-after.json` record the same
nine clean detached input revisions, trees and manifests throughout both
runs. `files.json` freezes every retained file by its exact raw byte length
and SHA256. No failures occurred in these gate commands, and no source edits
or commits were made for this validation.

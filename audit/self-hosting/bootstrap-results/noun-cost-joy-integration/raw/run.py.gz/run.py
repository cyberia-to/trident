#!/usr/bin/env python3
"""Retain exact-commit downstream compatibility commands and untouched raw logs."""
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time

ROOT = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
OUT = Path(__file__).resolve().parent
FAMILY = ROOT / 'noun-cost-joy-integration'
TARGET = ROOT / 'target-noun-cost-joy'
PINS = {
    'trident': '57491633fbccb58ae44dca2da438ee31430be1bc',
    'joy': 'ec83bd8d85b20a8bd20d2d14b0f25aab0f75e9fe',
    'nox': '172811b7746cdcd6ab198a3ed976dc6c19f55d5b',
    'zheng': '633e5ba980db94ca10d9d6b67cf24d9d3aef63a7',
    'hemera': 'a931a0a8e7ed369852ce0f8bc6451a59745ee692',
    'strata': 'd2eb1763b8caf04e6c7647ac6fe99761519c2ef9',
    'bbg': '1d39975ad199b48c350fa4cc011cbf6f289480ee',
    'lens': '17cafe91431977b738e5b72361187cd01ad93638',
    'neuron': 'fd24e768d623604b67e20b4b93fa8e82c83ac373',
}
REPORT = {
    'schema': 'local/noun-cost-joy-integration/v1',
    'scope': 'Downstream Joy compatibility at exact clean commits; no new SH6 or proof-gate closure.',
    'status': 'running', 'pins': PINS, 'family': str(FAMILY),
    'target': str(TARGET), 'started_ns': time.time_ns(),
    'host': {'platform': platform.platform(), 'machine': platform.machine()},
    'commands': [],
}


def save():
    (OUT / 'receipt.json').write_text(json.dumps(REPORT, indent=2) + '\n')


def identity(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(OUT)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def run(name, argv, cwd, cargo=False):
    env = os.environ.copy()
    additions = {'CARGO_TARGET_DIR': str(TARGET)} if cargo else {}
    env.update(additions)
    row = {'name': name, 'argv': argv, 'cwd': str(cwd), 'env': additions,
           'status': 'running', 'started_ns': time.time_ns()}
    REPORT['commands'].append(row)
    save()
    print('START', name, flush=True)
    with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
    row.update(status='completed', returncode=result.returncode, finished_ns=time.time_ns(),
               stdout=identity(OUT / (name + '.stdout')), stderr=identity(OUT / (name + '.stderr')))
    combined = (OUT / (name + '.stdout')).read_text() + (OUT / (name + '.stderr')).read_text()
    row['rust_warning_lines'] = re.findall(r'^warning(?:\[|:).*$', combined, re.M)
    row['test_summaries'] = re.findall(r'^test result: .*$', combined, re.M)
    save()
    print('END', name, result.returncode, flush=True)
    return result.returncode


def snapshot(label):
    rows = []
    for name, revision in PINS.items():
        path = FAMILY / name
        def git(*args):
            return subprocess.check_output(['git', *args], cwd=path, text=True)
        row = {'repository': name, 'path': str(path), 'resolved_path': str(path.resolve()),
               'revision': git('rev-parse', 'HEAD').strip(), 'tree': git('rev-parse', 'HEAD^{tree}').strip(),
               'status': git('status', '--porcelain=v1', '--untracked-files=all'),
               'detached': subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=path,
                                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 1}
        if row['revision'] != revision or row['status'] or not row['detached'] or path.is_symlink() or path.resolve() != path:
            raise RuntimeError('unclean or incorrect integration input: ' + name)
        row['manifests'] = {}
        for relative in ('Cargo.toml', 'Cargo.lock', 'rs/Cargo.toml', 'cli/Cargo.toml', 'CLAUDE.md'):
            file = path / relative
            if file.is_file():
                row['manifests'][relative] = hashlib.sha256(file.read_bytes()).hexdigest()
        rows.append(row)
    data = {'observed_ns': time.time_ns(), 'inputs': rows}
    (OUT / (label + '.json')).write_text(json.dumps(data, indent=2) + '\n')
    REPORT[label] = identity(OUT / (label + '.json'))
    save()


def main():
    save()
    if FAMILY.exists():
        raise RuntimeError('integration family already exists')
    FAMILY.mkdir()
    for name, revision in PINS.items():
        source = ROOT / 'semantic-observer-integration' / name
        command = ['git', '-C', str(source), 'worktree', 'add', '--detach', str(FAMILY / name), revision]
        if run('prepare-' + name, command, ROOT):
            raise RuntimeError('worktree preparation failed: ' + name)
    snapshot('before')
    joy = FAMILY / 'joy'
    commands = [
        ('rust-version', ['rustc', '-vV'], False),
        ('cargo-version', ['cargo', '--version'], False),
        ('boundary', ['python3', 'scripts/check-soft3-boundary.py'], True),
        ('metadata', ['cargo', 'metadata', '--format-version', '1', '--locked', '--offline', '--all-features'], True),
        ('fmt-workspace', ['cargo', 'fmt', '--', '--check'], True),
        ('check-default', ['cargo', 'check', '--workspace', '--all-targets', '--locked', '--offline'], True),
        ('check-all-features', ['cargo', 'check', '--workspace', '--all-targets', '--all-features', '--locked', '--offline'], True),
        ('test-default', ['cargo', 'test', '--workspace', '--release', '--locked', '--offline'], True),
    ]
    failures = []
    for name, command, cargo in commands:
        if run(name, command, joy, cargo):
            failures.append(name)
    snapshot('after')
    before = json.loads((OUT / 'before.json').read_text())['inputs']
    after = json.loads((OUT / 'after.json').read_text())['inputs']
    if before != after:
        raise RuntimeError('integration inputs changed')
    REPORT['failures'] = failures
    REPORT['rust_warnings'] = sum(len(row['rust_warning_lines']) for row in REPORT['commands'])
    REPORT['status'] = 'passed' if not failures and not REPORT['rust_warnings'] else 'failed'
    REPORT['finished_ns'] = time.time_ns()
    save()


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        REPORT.update(status='failed', error=repr(error), finished_ns=time.time_ns())
        save()
        raise

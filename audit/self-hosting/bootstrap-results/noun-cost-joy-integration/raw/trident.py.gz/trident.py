#!/usr/bin/env python3
"""Run the supported Trident root-package gates in the clean integration family."""
import json
import platform
import time
import run as capture

OUT = capture.OUT
joy = json.loads((OUT / 'receipt.json').read_text())
if joy['status'] == 'running':
    raise SystemExit('Joy gates are still running')

capture.REPORT = {
    'schema': 'local/noun-cost-trident-integration/v1',
    'scope': 'Supported default Trident root-package release tests and all-target checks at the clean nine integration pins; optional neural configuration and whole guest self-build are not run.',
    'status': 'running', 'pins': capture.PINS, 'family': str(capture.FAMILY),
    'target': str(capture.TARGET), 'started_ns': time.time_ns(),
    'host': {'platform': platform.platform(), 'machine': platform.machine()},
    'joy_receipt': capture.identity(OUT / 'receipt.json'), 'commands': [],
}


def save():
    (OUT / 'trident-receipt.json').write_text(json.dumps(capture.REPORT, indent=2) + '\n')


capture.save = save
try:
    capture.snapshot('trident-before')
    cwd = capture.FAMILY / 'trident'
    commands = [
        ('trident-metadata', ['cargo', 'metadata', '--format-version', '1', '--no-deps', '--locked', '--offline']),
        ('trident-check', ['cargo', 'check', '--all-targets', '--locked', '--offline']),
        ('trident-test', ['cargo', 'test', '--release', '--locked', '--offline', '--', '--test-threads=4']),
    ]
    failures = []
    for name, command in commands:
        if capture.run(name, command, cwd, True):
            failures.append(name)
    capture.snapshot('trident-after')
    before = json.loads((OUT / 'trident-before.json').read_text())['inputs']
    after = json.loads((OUT / 'trident-after.json').read_text())['inputs']
    if before != after:
        raise RuntimeError('integration inputs changed during Trident gates')
    warnings = sum(len(row['rust_warning_lines']) for row in capture.REPORT['commands'])
    capture.REPORT.update(status='passed' if not failures and not warnings else 'failed',
                          failures=failures, rust_warnings=warnings, finished_ns=time.time_ns())
    save()
except BaseException as error:
    capture.REPORT.update(status='failed', error=repr(error), finished_ns=time.time_ns())
    save()
    raise

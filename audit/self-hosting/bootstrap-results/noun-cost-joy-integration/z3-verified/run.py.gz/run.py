#!/usr/bin/env python3
"""Bind one repeated formal-audit case and real CLI outcomes to an explicit Z3."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / 'noun-cost-joy-integration'
ROOT = OUT.parent.parent
FAMILY = ROOT / 'noun-cost-joy-integration'
TARGET = ROOT / 'target-noun-cost-z3'
TRIDENT = TARGET / 'release/trident'
Z3 = Path(shutil.which('z3')).resolve(strict=True)
PATH = str(Z3.parent) + os.pathsep + os.environ['PATH']
CARGO = '/opt/homebrew/bin/cargo'
RUSTC = '/opt/homebrew/bin/rustc'
ENV = dict(os.environ, PATH=PATH, CARGO_TARGET_DIR=str(TARGET), RUSTC=RUSTC)
TEST = 'preconditions_guard_obligations_and_functions_have_independent_solver_state'
REPORT = {'schema': 'local/explicit-z3-followup/v1', 'status': 'running',
          'scope': 'One existing formal test rerun with a pinned real solver, plus good/bad CLI audit outputs. No additional unique-test count.',
          'started_ns': time.time_ns(), 'commands': [], 'repeated_existing_tests': 1, 'additional_unique_tests': 0}


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save():
    (OUT / 'receipt.json').write_text(json.dumps(REPORT, indent=2) + '\n')


def original_intact():
    manifest = json.loads((PRIOR / 'files.json').read_text())
    for row in manifest['files']:
        f = PRIOR / row['path']
        if identity(f)['sha256'] != row['sha256'] or f.stat().st_size != row['bytes']:
            raise RuntimeError('original evidence changed: ' + row['path'])
    return identity(PRIOR / 'files.json')


def snapshot(name):
    expected = json.loads((PRIOR / 'before.json').read_text())['inputs']
    rows = []
    for old in expected:
        p = FAMILY / old['repository']
        def git(*args):
            return subprocess.check_output(['git', *args], cwd=p, text=True)
        row = dict(old)
        row.update(revision=git('rev-parse', 'HEAD').strip(), tree=git('rev-parse', 'HEAD^{tree}').strip(),
                   status=git('status', '--porcelain=v1', '--untracked-files=all'), resolved_path=str(p.resolve()),
                   detached=subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=p, stdout=subprocess.DEVNULL).returncode == 1)
        row['manifests'] = {relative: identity(p / relative)['sha256'] for relative in old['manifests']}
        if row != old:
            raise RuntimeError('input differs from original gate: ' + old['repository'])
        rows.append(row)
    path = OUT / (name + '.json')
    path.write_text(json.dumps({'observed_ns': time.time_ns(), 'inputs': rows}, indent=2) + '\n')
    REPORT[name] = identity(path)
    save()


def run(name, argv, expected):
    row = {'name': name, 'argv': argv, 'cwd': str(FAMILY / 'trident'),
           'env': {'PATH': PATH, 'CARGO_TARGET_DIR': str(TARGET), 'RUSTC': RUSTC},
           'started_ns': time.time_ns(), 'expected_exit_code': expected}
    REPORT['commands'].append(row)
    save()
    with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
        result = subprocess.run(argv, cwd=FAMILY / 'trident', env=ENV, stdout=stdout, stderr=stderr)
    row.update(returncode=result.returncode, finished_ns=time.time_ns(),
               stdout=identity(OUT / (name + '.stdout')), stderr=identity(OUT / (name + '.stderr')))
    save()
    if result.returncode != expected:
        raise RuntimeError('unexpected exit code: ' + name)


def main():
    if shutil.which('z3', path=PATH) != str(Z3):
        raise RuntimeError('PATH does not select the pinned Z3 executable')
    REPORT['original_evidence_before'] = original_intact()
    REPORT['z3_before'] = identity(Z3)
    REPORT['z3_path_resolution'] = shutil.which('z3', path=PATH)
    REPORT['toolchain'] = {'cargo': identity(Path(CARGO).resolve()), 'rustc': identity(Path(RUSTC).resolve())}
    snapshot('before')
    test_file = FAMILY / 'trident/tests/formal_audit.rs'
    REPORT['test_source'] = identity(test_file)
    chunk = test_file.read_text().split('fn ' + TEST + '() {', 1)[1]
    literal = re.search(r'let source = ("(?:[^"\\]|\\.)*");', chunk).group(1)
    good = json.loads(literal)
    bad = good.replace('result == 9', 'result == 10')
    if good == bad:
        raise RuntimeError('negative source did not change')
    (OUT / 'good.tri').write_text(good)
    (OUT / 'bad.tri').write_text(bad)
    REPORT['sources'] = [identity(OUT / name) for name in ('good.tri', 'bad.tri')]
    run('rust-version', [RUSTC, '-vV'], 0)
    run('cargo-version', [CARGO, '--version'], 0)
    if (OUT / 'rust-version.stdout').read_bytes() != (PRIOR / 'rust-version.stdout').read_bytes() or (OUT / 'cargo-version.stdout').read_bytes() != (PRIOR / 'cargo-version.stdout').read_bytes():
        raise RuntimeError('toolchain version differs from original integration')
    run('z3-version', [str(Z3), '--version'], 0)
    run('focused-test', [CARGO, 'test', '--release', '--locked', '--offline',
                        '--test', 'formal_audit', TEST, '--', '--exact', '--nocapture'], 0)
    REPORT['trident_before'] = identity(TRIDENT)
    for name, status in (('good', 0), ('bad', 1)):
        run(name + '-audit', [str(TRIDENT), 'audit', '--z3', '--json', str(OUT / (name + '.tri'))], status)
        REPORT[name + '_result'] = json.loads((OUT / (name + '-audit.stdout')).read_text())
    if REPORT['good_result']['verdict'] != 'safe' or REPORT['bad_result']['verdict'] != 'unsafe':
        raise RuntimeError('unexpected CLI solver verdict')
    snapshot('after')
    REPORT['z3_after'] = identity(Z3)
    REPORT['trident_after'] = identity(TRIDENT)
    if REPORT['z3_before'] != REPORT['z3_after'] or REPORT['trident_before'] != REPORT['trident_after']:
        raise RuntimeError('executable changed')
    REPORT['original_evidence_after'] = original_intact()
    if REPORT['original_evidence_before'] != REPORT['original_evidence_after']:
        raise RuntimeError('original evidence manifest changed')
    warnings = re.findall(r'^warning(?:\[|:).*$', (OUT / 'focused-test.stderr').read_text(), re.M)
    REPORT.update(status='passed' if not warnings else 'failed', rust_warning_lines=warnings, finished_ns=time.time_ns())
    save()


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        REPORT.update(status='failed', error=repr(error), finished_ns=time.time_ns())
        save()
        raise

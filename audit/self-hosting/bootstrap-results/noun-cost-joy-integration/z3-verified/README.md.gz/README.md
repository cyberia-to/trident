# Explicit real-Z3 follow-up

This passed follow-up uses the same nine clean source revisions as the original
`../noun-cost-joy-integration` run. It records a separate focused result and
does not add a unique test to the original 1,197-test total. The first attempt's
toolchain-path failure remains retained in `../noun-cost-z3-integration`.

Z3 is the real binary `/opt/homebrew/Cellar/z3/4.15.4/bin/z3`, version
`4.15.4 - 64 bit`, SHA256
`ae6c8df33db9c9ae9a80b6044e77cd66529a141d8b25f0620f1e89b409594f48`.
Its directory is prepended to the original PATH, with the exact resulting PATH
retained in each command. Absolute Homebrew Cargo and Rustc are selected;
their version output equals the original integration version output byte for
byte. Their executable identities are recorded. All build outputs use the new
`target-noun-cost-z3` directory.

The recorded focused command is:

```text
/opt/homebrew/bin/cargo test --release --locked --offline --test formal_audit preconditions_guard_obligations_and_functions_have_independent_solver_state -- --exact --nocapture
```

It passed one existing test, with 16 filtered out, no ignored tests and no Rust
warnings. The same test's literal source is retained as `good.tri`; `bad.tri`
changes only the second function's postcondition from 9 to 10. The actual
compiled Trident CLI ran `audit --z3 --json` against both files. Good returned
exit 0 and top-level `safe` (both functions safe); bad returned exit 1 and
top-level `unsafe` (first function safe, second unsafe). Raw JSON and stderr
are retained, along with exact argv, executable identities and source hashes.

`before.json` and `after.json` match all original clean source identities.
Z3 and the newly built Trident CLI remain byte-exact across the two CLI checks.
The original 55 evidence files were independently rehashed before and after
this follow-up. No source files or original test outputs were modified.

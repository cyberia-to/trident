from pathlib import Path
import hashlib,importlib.util,json,runpy,subprocess,sys
r=Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap');repo=r/'trident';inputs=r/'measurements/ci-phases-readonly';stores=repo/'audit/self-hosting/bootstrap-results/run-36382085561/phase-stores';out=r/'measurements/ci-phases-imports/corpora-019';out.mkdir()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
indices={'c2':'354e5321dfb33a8cd103ad61a5a3bae7b34dab4347b8b32c38342066f4125719','c3':'cf9565cdd1e1aa7c3ea4fa135e694da3a9383cd8199638c88a6358be65c6e510'}
helper=repo/'audit/self-hosting/bootstrap-results/archive-tool/archive.py';validator=repo/'audit/self-hosting/bootstrap-results/run-36382085561/final-validation/verify-final-matrix.py';assert h(helper)=='acef178c58f48005c30ed7a300f84fc5ed8c5ab0ddcf498b318bb74ec2ec4e4e';assert h(validator)=='72cd11ec62e410e908590a785c79011989ea2c6c32872c5db31d72a62947c0ec'
v=runpy.run_path(str(validator));expected=v['load'](inputs/'expected-inputs.json');assert h(inputs/'expected-inputs.json')==v['EXPECTED'];frozen=inputs/'frozen/audit/self-hosting';assert {name:h(frozen/name) for name in expected['implementation']}==expected['implementation'];spec=importlib.util.spec_from_file_location('frozen_corpus_checker',frozen/'bootstrap_phase_checks.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
producer_replay=r/'measurements/ci-phases-imports/producer-012';prior=v['load'](producer_replay/'replay.json');assert prior['status']=='passed' and prior['index_sha256']=='51f791f67822bd9ebaf4ee77f04806d10dff592e64a7528dfc985b1d84c0c13f'
report={'schema':'local/retained-native-corpus-components/v1','status':'running','matrix_acceptance':False,'scope':'Nineteen original corpus phases; final36 acceptance remains open','indices':indices,'validator':v['identity'](validator),'driver':v['identity'](Path(__file__)),'producer_replay':v['identity'](producer_replay/'replay.json'),'commands':[],'rows':[]}
jobs={v['load'](p)['name']:p for p in inputs.glob('job-*-direct.json') if v['load'](p).get('conclusion')=='success'};selected_jobs=set()
try:
 for role,index_sha in indices.items():
  store=stores/role;assert h(store/'index.json')==index_sha;index=v['load'](store/'index.json');assert len(index['artifacts'])=={'c2':10,'c3':9}[role]
  cmd=[sys.executable,'-B',str(helper),'restore','--store',str(store),'--output',str(out/role),'--index-sha256',index_sha];p=subprocess.run(cmd,capture_output=True);(out/(role+'.stdout')).write_bytes(p.stdout);(out/(role+'.stderr')).write_bytes(p.stderr);report['commands'].append({'argv':cmd,'cwd':str(Path.cwd()),'exit_code':p.returncode});assert p.returncode==0,p.stderr.decode()
  for name,entry in index['artifacts'].items():
   root=out/role/name;zip_path,provenance=v['archive'](inputs,entry['id'],name);binding=v['store_binding'](store,entry,name,provenance);tree=v['exact_tree'](zip_path,root);receipt=v['load'](root/'receipt.json')
   assert receipt['phase']=='corpus' and receipt['generation']==int(role[1]) and receipt['ci_origin']==v['ORIGIN'] and receipt['pins']==expected['pins'] and receipt['rust_version']==expected['rust_version']
   contract,produced=c.corpus(root,receipt);producer_name=name.replace('-'+role+'-attempt-1','-producer-attempt-1');original=producer_replay/'restored'/producer_name;source_receipt=v['load'](original/'receipt.json');source_contract,compiler,_=c.producer(original,source_receipt)
   assert contract==source_contract and produced['receipt_sha256']==h(original/'receipt.json') and produced['files_sha256']==source_receipt['files']['sha256'];assert (root/receipt['producer_receipt']['path']).read_bytes()==(original/'receipt.json').read_bytes();assert (root/receipt['producer_manifest']['path']).read_bytes()==(original/'files.json').read_bytes()
   for key in ('compiler','joy'):
    original_identity=source_receipt['joy'] if key=='joy' else source_receipt['repetitions'][0][role];assert produced[key]==original_identity;assert (root/receipt[key]['path']).read_bytes()==(original/original_identity['path']).read_bytes()
   assert hashlib.sha256(compiler).hexdigest()==v['COMPILER'];corpora=[]
   for label,identity in receipt['corpora'].items():
    child=v['load'](root/identity['path']);corpora.append({'name':label,'receipt':v['identity'](root/identity['path']),'observations':len(child['observations']),'commands_including_reference_oracles':len(child['commands'])})
   assert sum(x['observations'] for x in corpora)==547 and sum(x['commands_including_reference_oracles'] for x in corpora)==1816
   job_name=f"Bootstrap {receipt['target']} repeat {receipt['repeat']} / Corpus C{role[1]}";job=v['job_identity'](jobs[job_name],job_name);v['distinct_job'](job,selected_jobs)
   report['rows'].append({'name':name,'artifact_id':entry['id'],**tree,'provenance':provenance,'store':binding,'receipt':v['identity'](root/'receipt.json'),'producer':v['identity'](original/'receipt.json'),'original_job':v['identity'](jobs[job_name]),'job_log':v['identity'](inputs/f"job-{job['id']}-api.log"),'corpora':corpora});print(name,tree,flush=True)
  assert h(store/'index.json')==index_sha
 report.update(status='passed',corpus_jobs=19,raw_files=sum(x['files'] for x in report['rows']),raw_bytes=sum(x['raw_bytes'] for x in report['rows']))
except BaseException as error:report.update(status='failed',error=f'{type(error).__name__}: {error}');raise
finally:(out/'replay.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('status','corpus_jobs','raw_files','raw_bytes','matrix_acceptance')}))

from pathlib import Path
import hashlib,importlib.util,json,re,runpy,subprocess,sys,time
r=Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap');repo=r/'trident';inputs=r/'measurements/ci-phases-readonly';store=repo/'audit/self-hosting/bootstrap-results/run-36382085561/phase-stores/producer';out=r/'measurements/ci-phases-imports/producer-007';out.mkdir()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();index_sha='6deb3f8b29d13e5eba6215c654261da2ed99b3ff3b6883e6e67738c02db7d833';assert h(store/'index.json')==index_sha
helper=repo/'audit/self-hosting/bootstrap-results/archive-tool/archive.py';validator=repo/'audit/self-hosting/bootstrap-results/run-36382085561/final-validation/verify-final-matrix.py';assert h(validator)=='72cd11ec62e410e908590a785c79011989ea2c6c32872c5db31d72a62947c0ec'
cmd=[sys.executable,'-B',str(helper),'restore','--store',str(store),'--output',str(out/'restored'),'--index-sha256',index_sha];p=subprocess.run(cmd,capture_output=True);(out/'restore.stdout').write_bytes(p.stdout);(out/'restore.stderr').write_bytes(p.stderr)
report={'schema':'local/retained-native-phase-components/v1','scope':'Seven original producer components only; matrix acceptance remains open','status':'running','matrix_acceptance':False,'index_sha256':index_sha,'command':cmd,'restore_exit_code':p.returncode,'validator_sha256':h(validator),'rows':[],'driver_sha256':h(Path(__file__))}
try:
 assert p.returncode==0,p.stderr.decode();v=runpy.run_path(str(validator));expected=json.loads((inputs/'expected-inputs.json').read_text());assert h(inputs/'expected-inputs.json')==v['EXPECTED']
 frozen=inputs/'frozen/audit/self-hosting';assert {name:h(frozen/name) for name in expected['implementation']}==expected['implementation']
 spec=importlib.util.spec_from_file_location('root_frozen_phase_checks',frozen/'bootstrap_phase_checks.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 index=json.loads((store/'index.json').read_text());assert len(index['artifacts'])==7
 source=None
 jobs={}
 for path in inputs.glob('job-*-direct.json'):
  job=v['load'](path)
  if job.get('status')=='completed' and job.get('conclusion')=='success':jobs[job['name']]=path
 selected_jobs=set()
 for name,entry in index['artifacts'].items():
  root=out/'restored'/name;zip_path,provenance=v['archive'](inputs,entry['id'],name);binding=v['store_binding'](store,entry,name,provenance);tree=v['exact_tree'](zip_path,root);receipt=v['load'](root/'receipt.json')
  assert receipt['phase']=='producer' and receipt['ci_origin']==v['ORIGIN'] and receipt['pins']==expected['pins'] and receipt['rust_version']==expected['rust_version']
  contract,compiler,current=c.producer(root,receipt);assert hashlib.sha256(compiler).hexdigest()==v['COMPILER'];assert source is None or source==current;source=current
  steps=[]
  for generation,reference in zip((2,3),expected['local_reference_steps']):
   step=c.B.load(c.B.retained(root,receipt['repetitions'][0][f'step{generation}']));steps.append({'generation':generation,'identities':v['s1_binding'](step,reference),'execution':step['execution']['execution']})
  builds=[x for x in receipt['commands'] if x['command'][:2]==['cargo','build']];assert len(builds)==2
  for build in builds:assert not re.search(rb'^warning(?:\[[^\]\r\n]+\])?:',(root/build['stderr']).read_bytes(),re.M)
  row={'name':name,'artifact_id':entry['id'],**tree,'provenance':provenance,'store':binding,'receipt':v['identity'](root/'receipt.json'),'steps':steps,'rust_warnings':0,'compiler_sha256':v['COMPILER']};job_name=f"Bootstrap {receipt['target']} repeat {receipt['repeat']} / Self-build C2 and C3";job=v['job_identity'](jobs[job_name],job_name);v['distinct_job'](job,selected_jobs);row['original_job']=v['identity'](jobs[job_name]);row['job_log']=v['identity'](inputs/f"job-{job['id']}-api.log");report['rows'].append(row);print(name,tree,flush=True)
 assert h(store/'index.json')==index_sha
 report.update(status='passed',producers=7,raw_files=sum(x['files'] for x in report['rows']),raw_bytes=sum(x['raw_bytes'] for x in report['rows']))
except BaseException as error:report.update(status='failed',error=f'{type(error).__name__}: {error}');raise
finally:(out/'replay.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({x:report[x] for x in ('status','producers','raw_files','raw_bytes','matrix_acceptance')}))

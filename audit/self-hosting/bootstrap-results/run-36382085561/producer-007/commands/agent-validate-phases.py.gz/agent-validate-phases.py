"""Verify downloaded completed phases and exact producer-to-consumer receipt binding."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

OUT=Path(__file__).resolve().parent
FROZEN=OUT/'frozen/audit/self-hosting'
spec=importlib.util.spec_from_file_location('frozen_phase_checks',FROZEN/'bootstrap_phase_checks.py')
C=importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
B=C.B
expected=json.loads((OUT/'expected-inputs.json').read_bytes())
origin=dict(run_id='36382085561',run_attempt='1',head_sha='57491633fbccb58ae44dca2da438ee31430be1bc')
B.require(expected['run_id']==36382085561 and expected['head_sha']==origin['head_sha'] and expected['run_attempt']==1,'expected run mismatch')
B.require(C.implementation()==expected['implementation'],'frozen implementation identity')
reports=[]
for path in sorted((OUT/'phases').glob('*/receipt.json')):
 reports.append((path.parent,B.load(path)))
producers={(r['target'],r['repeat']):(root,r) for root,r in reports if r.get('phase')=='producer' and r.get('status')=='produced'}
rows=[]
source_contract=None
for root,report in sorted(reports,key=lambda x:(x[1].get('phase')!='producer',x[0].name)):
 phase=report.get('phase')
 if report.get('status') not in ('produced','passed'):
  rows.append(dict(name=root.name,status='incomplete',observed_status=report.get('status'),receipt_sha256=B.sha(root/'receipt.json')))
  continue
 B.require(report['pins']==expected['pins'] and report['ci_origin']==origin and report['rust_version']==expected['rust_version'],'actual phase expected pins/origin/Rust')
 label='producer' if phase=='producer' else f"c{report['generation']}"
 B.require(root.name==f"bootstrap-phase-{report['target']}-repeat-{report['repeat']}-{label}-attempt-1",'artifact role name')
 row=dict(name=root.name,status='verified',phase=phase,target=report['target'],repeat=report['repeat'],receipt_sha256=B.sha(root/'receipt.json'),matrix_acceptance=False)
 if phase=='producer':
  contract,compiler,source=C.producer(root,report)
  B.require(source_contract is None or source_contract==source,'producer source/options/limits differ')
  source_contract=source
  B.require(hashlib.sha256(compiler).hexdigest()=='76a07c08265bd2ef525164472b6b53ac3f0e6cbbedce3250c4202f40ffba34c8','canonical compiler differs')
  repeat=report['repetitions'][0]
  timings=[]
  for generation,local in zip((2,3),expected['local_reference_steps']):
   step=B.load(B.retained(root,repeat[f'step{generation}']))
   for key in ('compiler_sha256','result_sha256','inventory_sha256','job_sha256'):
    B.require(step[key]==local[key],f'local S1 step{generation} {key}')
   execution=step['execution']['execution']
   B.require({k:v for k,v in execution.items() if k!='elapsed_micros'}==local['execution_without_elapsed'],'local non-time execution differs')
   timings.append(dict(generation=generation,worker_execution_elapsed_microseconds=execution['elapsed_micros'],command_elapsed_nanoseconds=step['commands'][-1]['elapsed_nanoseconds']))
  row.update(compiler_sha256=hashlib.sha256(compiler).hexdigest(),exported_joy_sha256=report['joy']['sha256'],timings=timings)
 else:
  contract,binding=C.corpus(root,report)
  key=(report['target'],report['repeat'])
  B.require(key in producers,'original producer artifact not downloaded')
  producer_root,producer=producers[key]
  C.producer(producer_root,producer)
  B.require(binding['receipt_sha256']==B.sha(producer_root/'receipt.json') and binding['files_sha256']==producer['files']['sha256'],'consumer original producer receipt differs')
  B.require(binding['compiler']==producer['repetitions'][0][f"c{report['generation']}"] and binding['joy']==producer['joy'],'consumer original producer export differs')
  corpora={name:dict(status=(child:=B.load(B.retained(root,identity)))['status'],observations=len(child['observations']),commands=len(child['commands'])) for name,identity in report['corpora'].items()}
  row.update(generation=report['generation'],producer_receipt_sha256=binding['receipt_sha256'],compiler_sha256=report['compiler']['sha256'],corpora=corpora)
 warnings=[]
 for command in report['commands']:
  if Path(command['command'][0]).name in ('cargo','cargo.exe'):
   text=re.sub(r'\x1b\[[0-9;]*m','',(root/command['stderr']).read_text())
   warnings.extend(dict(file=command['stderr'],line=i+1,text=line) for i,line in enumerate(text.splitlines()) if re.match(r'^warning(?:\[|:)',line))
 row['rust_warning_lines']=warnings
 rows.append(row)
summary=dict(scope='Completed phase components only; full36-phase and actual aggregate binding remain separate',run_id=36382085561,head_sha=origin['head_sha'],
             validator_sha256=B.sha(Path(__file__)),implementation=C.implementation(),expected_inputs_sha256=B.sha(OUT/'expected-inputs.json'),rows=rows,matrix_acceptance=False)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
path=OUT/f'phase-validation-{stamp}.json'
with path.open('x',encoding='utf-8') as stream:json.dump(summary,stream,indent=2)
print(json.dumps(dict(path=str(path),verified_producers=sum(r['status']=='verified' and r.get('phase')=='producer' for r in rows),verified_consumers=sum(r['status']=='verified' and r.get('phase')=='corpus' for r in rows),incomplete=sum(r['status']=='incomplete' for r in rows),rust_warning_count=sum(len(r.get('rust_warning_lines',[])) for r in rows),matrix_acceptance=False),indent=2))

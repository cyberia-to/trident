"""Retain measured original SH6 authority and the fresh final36 replay."""
from pathlib import Path
import gzip
import hashlib
import json

R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
M = R / 'measurements'
BASE = R / 'trident/audit/self-hosting/bootstrap-results/run-36382085561'
OUT = BASE / 'accepted'
INPUTS = M / 'ci-phases-readonly'
FINAL = M / 'ci-phases-final-acceptance'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def require(value, message):
    if not value:
        raise ValueError(message)

def load(path):
    return json.loads(path.read_bytes())

report = load(FINAL / 'validation/verification.json')
require(report['status'] == 'passed' and report['native_repetitions'] == 12 and report['native_corpus_jobs'] == 24, 'complete final36 verdict')
require(sha((FINAL / 'validation/verification.json').read_bytes()) == 'be6d76f37c0daf9694e75dad83e200adc25a32b05e593fdbeec11f4d67a69f81', 'reviewed exact final verdict')
selected = {}
for path in FINAL.rglob('*'):
    if path.is_file() and not path.is_relative_to(FINAL / 'restored'):
        selected['replay/' + path.relative_to(FINAL).as_posix()] = path
for name in ('complete-native-acceptance.py', 'complete-native-acceptance.stdout', 'complete-native-acceptance.stderr', Path(__file__).name, 'import-phase-batch.py'):
    selected['commands/' + name] = M / name
for role, digest in load(FINAL / 'indices.json').items():
    path = BASE / 'phase-stores' / role / 'index.json'
    require(sha(path.read_bytes()) == digest, 'exact current index')
    selected['indices/' + role + '.json'] = path
for row in report['phases']:
    for key in ('metadata', 'job', 'job_log'):
        path = Path(row[key]['path'])
        require(sha(path.read_bytes()) == row[key]['sha256'], 'exact original phase authority')
        selected['inputs/' + path.name] = path
for row in report['original_aggregate'].values():
    path = Path(row['path'])
    require(sha(path.read_bytes()) == row['sha256'], 'exact original aggregate authority')
    selected['inputs/' + path.name] = path
for name in ('job-108868600539-api.log', 'artifact-10961755660-download.json', 'expected-inputs.json',
             'phase-validation-20260928T093400Z.json', 'original-aggregate-binding-20260928T093530Z.json',
             'verify-original-aggregate.py', 'all-components-comparison-20260928T093334Z.json'):
    selected['inputs/' + name] = INPUTS / name
for name in load(INPUTS / 'expected-inputs.json')['implementation']:
    selected['frozen/' + name] = INPUTS / 'frozen/audit/self-hosting' / name
for artifact in (10961535064, 10961720629):
    for suffix in ('json', 'stdout', 'stderr'):
        selected[f'imports/{artifact}.{suffix}'] = M / f'ci-phases-imports/{artifact}.{suffix}'
prior = BASE / 'components-034/retention.json'
retention = dict(schema='trident/native-sh6-acceptance-retention/v1', status='passed',
                 run_id=36382085561, attempt=1, head_sha='57491633fbccb58ae44dca2da438ee31430be1bc',
                 verification_sha256=sha((FINAL / 'validation/verification.json').read_bytes()),
                 native_repetitions=12, native_corpus_jobs=24,
                 raw_phase_files=sum(row['files'] for row in report['phases']),
                 raw_phase_bytes=sum(row['raw_bytes'] for row in report['phases']),
                 indices=load(FINAL / 'indices.json'),
                 prior_snapshot=dict(path='../components-034/retention.json', sha256=sha(prior.read_bytes())),
                 external_original_phase_containers=[row['zip'] for row in report['phases']],
                 files={})
OUT.mkdir()
for name, path in sorted(selected.items()):
    raw = path.read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    destination = OUT / (name + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(compressed)
    require(gzip.decompress(destination.read_bytes()) == path.read_bytes() == raw, 'byte-exact retained original')
    retention['files'][name] = dict(bytes=len(raw), sha256=sha(raw), compressed_bytes=len(compressed), compressed_sha256=sha(compressed))
(OUT / 'retention.json').write_text(json.dumps(retention, indent=2) + '\n')
print(json.dumps({k:retention[k] for k in ('status', 'raw_phase_files', 'raw_phase_bytes', 'verification_sha256')}))

"""Replay the final original native phase matrix; refuses incomplete inputs."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
BASE = R / 'trident/audit/self-hosting/bootstrap-results/run-36382085561'
INPUTS = R / 'measurements/ci-phases-readonly'
OUT = R / 'measurements/ci-phases-final-acceptance'
VALIDATOR = BASE / 'final-validation/verify-final-matrix.py'
ARCHIVER = R / 'trident/audit/self-hosting/bootstrap-results/archive-tool/archive.py'

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_bytes())

def main():
    require(not OUT.exists(), 'fresh acceptance directory')
    require(sha(VALIDATOR) == '72cd11ec62e410e908590a785c79011989ea2c6c32872c5db31d72a62947c0ec', 'frozen validator')
    require(sha(ARCHIVER) == 'acef178c58f48005c30ed7a300f84fc5ed8c5ab0ddcf498b318bb74ec2ec4e4e', 'reviewed archiver')
    final = INPUTS / 'run-36382085561-final-direct.json'
    run = load(final)
    require(run['id'] == 36382085561 and run['run_attempt'] == 1 and run['head_sha'] == '57491633fbccb58ae44dca2da438ee31430be1bc' and run['status'] == 'completed' and run['conclusion'] == 'success', 'original complete successful run required')
    indices = {}
    for role in ('producer', 'c2', 'c3'):
        path = BASE / 'phase-stores' / role / 'index.json'
        require(len(load(path)['artifacts']) == 12, 'twelve original artifacts per role')
        indices[role] = sha(path)
    artifacts = [load(p) for p in INPUTS.glob('artifact-*.json') if not p.name.endswith('-download.json')]
    aggregate = [a for a in artifacts if a['name'] == 'bootstrap-phase-matrix-comparison-attempt-1']
    require(len(aggregate) == 1, 'one original aggregate')
    jobs = [p for p in INPUTS.glob('job-*-direct.json') if load(p)['name'] == 'Compare twelve native self-builds and twenty-four compiler corpora']
    require(len(jobs) == 1 and load(jobs[0])['conclusion'] == 'success', 'one successful original aggregate job')
    OUT.mkdir()
    (OUT / 'restored').mkdir()
    commands = []
    def call(name, argv):
        with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
            result = subprocess.run(list(map(str, argv)), cwd=R / 'measurements', stdout=stdout, stderr=stderr)
        commands.append(dict(argv=list(map(str, argv)), cwd=str(R / 'measurements'), exit_code=result.returncode))
        (OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        require(result.returncode == 0, name + ' failed; original output retained')
    for role, digest in indices.items():
        stage = OUT / ('restore-' + role)
        call(role, [sys.executable, '-B', '-W', 'error', ARCHIVER, 'restore', '--store', BASE / 'phase-stores' / role, '--output', stage, '--index-sha256', digest])
        for phase in stage.iterdir():
            destination = OUT / 'restored' / phase.name
            require(phase.is_dir() and not destination.exists(), 'unique restored phase')
            phase.rename(destination)
        stage.rmdir()
    require(len(list((OUT / 'restored').iterdir())) == 36, 'all original phases restored')
    index_file = OUT / 'indices.json'
    index_file.write_text(json.dumps(indices, indent=2) + '\n')
    args = dict(restored=OUT / 'restored', stores=BASE / 'phase-stores', indices=index_file, inputs=INPUTS,
                **{'runner-directory': INPUTS / 'frozen/audit/self-hosting', 'expected': INPUTS / 'expected-inputs.json',
                   'aggregate-job': jobs[0], 'final-run': final, 'output': OUT / 'validation',
                   'indices-sha256': sha(index_file), 'aggregate-id': aggregate[0]['id']})
    argv = [sys.executable, '-B', '-W', 'error', VALIDATOR]
    for name, value in args.items():
        argv.extend(['--' + name, value])
    call('final-validation', argv)
    report = load(OUT / 'validation/verification.json')
    require(report['status'] == 'passed' and report['native_repetitions'] == 12 and report['native_corpus_jobs'] == 24, 'complete final verdict')
    print(json.dumps(dict(status='passed', receipt=str(OUT / 'validation/verification.json'))))

if __name__ == '__main__':
    main()

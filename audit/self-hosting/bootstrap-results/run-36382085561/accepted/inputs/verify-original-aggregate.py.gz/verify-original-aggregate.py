"""Bind the original aggregate to downloaded phases; store replay is separate."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

OUT = Path(__file__).resolve().parent
FROZEN = OUT / 'frozen/audit/self-hosting'
spec = importlib.util.spec_from_file_location('frozen_phase_checks', FROZEN / 'bootstrap_phase_checks.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
B = C.B
ORIGIN = dict(run_id='36382085561', run_attempt='1', head_sha='57491633fbccb58ae44dca2da438ee31430be1bc')
expected = B.load(OUT / 'expected-inputs.json')
B.require(C.implementation() == expected['implementation'], 'frozen implementation')
reports = [(p.parent, B.load(p)) for p in sorted((OUT / 'phases').glob('*/receipt.json'))]
B.require(len(reports) == 36 and all(r['pins'] == expected['pins'] for _, r in reports), 'original36 exact source pins')
compiler = C.compare_matrix(reports, ORIGIN)
B.require(compiler == '76a07c08265bd2ef525164472b6b53ac3f0e6cbbedce3250c4202f40ffba34c8', 'canonical compiler')
api = OUT / 'artifact-10961755660.json'
archive = OUT / 'artifact-10961755660.zip'
meta = B.load(api)
B.require(meta['id'] == 10961755660 and meta['name'] == 'bootstrap-phase-matrix-comparison-attempt-1', 'original artifact role')
B.require(meta['workflow_run']['id'] == 36382085561 and meta['workflow_run']['head_sha'] == ORIGIN['head_sha'], 'original artifact origin')
B.require(meta['size_in_bytes'] == archive.stat().st_size <= 16 << 20 and meta['digest'] == 'sha256:' + B.sha(archive), 'original API/ZIP binding')
with zipfile.ZipFile(archive) as source:
    B.require(source.namelist() == ['files.json', 'receipt.json'] or source.namelist() == ['receipt.json', 'files.json'], 'exact aggregate members')
    B.require(all(x.file_size <= 16 << 20 for x in source.infolist()), 'bounded aggregate members')
    raw, files = source.read('receipt.json'), source.read('files.json')
actual = json.loads(raw)
B.require(actual['schema'] == C.SCHEMA and actual['phase'] == 'matrix' and actual['status'] == 'passed', 'original aggregate passed')
B.require(actual['ci_origin'] == ORIGIN and actual['implementation'] == expected['implementation'] and actual['compiler_sha256'] == compiler, 'aggregate origin/implementation/compiler')
B.require(actual['files'] == dict(path='files.json', bytes=len(files), sha256=hashlib.sha256(files).hexdigest()) and json.loads(files) == {}, 'original aggregate manifest')
bindings = {root.name: B.sha(root / 'receipt.json') for root, _ in reports}
rows = actual['phase_reports']
B.require(len(rows) == 36 and all(Path(r['path']).name == 'receipt.json' for r in rows), 'aggregate receipt roles')
B.require({Path(r['path']).parent.name: r['sha256'] for r in rows} == bindings, 'all36 original phase receipt hashes')
extracted = OUT / 'aggregate/bootstrap-phase-matrix-comparison-attempt-1'
B.require((extracted / 'receipt.json').read_bytes() == raw and (extracted / 'files.json').read_bytes() == files, 'exact extracted aggregate')
job_path = OUT / 'job-108868600539-direct.json'
log_path = OUT / 'job-108868600539-api.log'
job = B.load(job_path)
B.require((job['id'], job['run_id'], job['run_attempt'], job['head_sha'], job['status'], job['conclusion'], job['name']) == (108868600539, 36382085561, 1, ORIGIN['head_sha'], 'completed', 'success', 'Compare twelve native self-builds and twenty-four compiler corpora'), 'original aggregate job')
B.require(log_path.is_file(), 'raw aggregate log retained')
run_path = OUT / 'run-36382085561-final-direct.json'
run = B.load(run_path)
B.require((run['id'], run['run_attempt'], run['head_sha'], run['status'], run['conclusion']) == (36382085561, 1, ORIGIN['head_sha'], 'completed', 'success'), 'original successful final run')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
path = OUT / f'original-aggregate-binding-{stamp}.json'
report = dict(status='passed', scope=__doc__, command=[sys.executable, '-W', 'error', str(Path(__file__))], cwd=str(Path.cwd()), verifier_sha256=B.sha(Path(__file__)), expected_origin=ORIGIN, implementation=C.implementation(), expected_inputs_sha256=B.sha(OUT / 'expected-inputs.json'), compiler_sha256=compiler, phase_receipts=bindings, original_files={str(p.relative_to(OUT)): dict(bytes=p.stat().st_size, sha256=B.sha(p)) for p in (api, archive, job_path, log_path, run_path)}, root_final_store_replay_pending=True)
with path.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(path=str(path), status=report['status'], phases=len(reports), compiler_sha256=compiler, root_final_store_replay_pending=True)))

"""Independent read-only review of the fresh final36 replay and original authority."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import stat
import sys
import zipfile

HERE = Path(__file__).resolve().parent
R = HERE.parent.parent
FINAL = R / 'measurements/ci-phases-final-acceptance'
BASE = R / 'trident/audit/self-hosting/bootstrap-results/run-36382085561'
REPORT = FINAL / 'validation/verification.json'
EXPECTED_REPORT = 'be6d76f37c0daf9694e75dad83e200adc25a32b05e593fdbeec11f4d67a69f81'
ORIGIN = dict(run_id='36382085561', run_attempt='1', head_sha='57491633fbccb58ae44dca2da438ee31430be1bc')
FROZEN = HERE / 'frozen/audit/self-hosting'

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    return json.loads(path.read_bytes())

need(sha(REPORT) == EXPECTED_REPORT, 'exact reviewed final report')
report = load(REPORT)
need(report['status'] == 'passed' and report['native_repetitions'] == 12 and report['native_corpus_jobs'] == 24, 'actual complete verdict')
validator = BASE / 'final-validation/verify-final-matrix.py'
archiver = R / 'trident/audit/self-hosting/bootstrap-results/archive-tool/archive.py'
need(sha(validator) == report['validator_sha256'] == '72cd11ec62e410e908590a785c79011989ea2c6c32872c5db31d72a62947c0ec', 'reviewed validator')
need(sha(archiver) == 'acef178c58f48005c30ed7a300f84fc5ed8c5ab0ddcf498b318bb74ec2ec4e4e', 'reviewed archiver')
seen_identities = {}
def identities(value):
    if isinstance(value, dict):
        if set(('path', 'bytes', 'sha256')).issubset(value):
            p = Path(value['path'])
            need(p.is_relative_to(R) and not p.is_symlink(), 'ordinary identity under workspace')
            actual = dict(bytes=p.stat().st_size, sha256=sha(p))
            need(actual == {key: value[key] for key in actual}, 'identity differs: ' + str(p))
            seen_identities[str(p)] = actual
        for child in value.values():
            identities(child)
    elif isinstance(value, list):
        for child in value:
            identities(child)
identities(report)
expected = load(HERE / 'expected-inputs.json')
need(sha(HERE / 'expected-inputs.json') == 'd1dca2687520edbded3bc6e3088fe7fb1d72a43318a3cc15b87e1aea3ca35dde', 'expected inputs pin')
spec = importlib.util.spec_from_file_location('frozen_phase_checks', FROZEN / 'bootstrap_phase_checks.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
need(C.implementation() == expected['implementation'], 'frozen three-module implementation')
indices = load(FINAL / 'indices.json')
need(set(indices) == {'producer', 'c2', 'c3'}, 'three roles')
indexed = {}
for role, digest in indices.items():
    p = BASE / 'phase-stores' / role / 'index.json'
    need(sha(p) == digest, 'current store index bytes')
    index = load(p)
    need(index['run_id'] == 36382085561 and index['head_sha'] == ORIGIN['head_sha'], 'store origin')
    need(len(index['artifacts']) == 12, 'complete role')
    for name, entry in index['artifacts'].items():
        need(name not in indexed, 'distinct indexed phase')
        indexed[name] = role, entry
phases = report['phases']
need(len(phases) == 36 and {p['name'] for p in phases} == set(indexed), 'exact original36 set')
need({p.name for p in (FINAL / 'restored').iterdir()} == set(indexed), 'exact restored directories')
receipts, job_ids, artifact_ids, totals = [], set(), set(), dict(files=0, raw_bytes=0)
warnings = []
for phase in phases:
    name = phase['name']
    role, entry = indexed[name]
    root = FINAL / 'restored' / name
    receipt = load(root / 'receipt.json')
    need(receipt['pins'] == expected['pins'] and receipt['ci_origin'] == ORIGIN, 'actual source pins/origin')
    need(receipt['rust_version'] == expected['rust_version'], 'actual Rust pin')
    meta = load(Path(phase['metadata']['path']))
    need(entry['id'] == meta['id'] and meta['id'] not in artifact_ids and meta['name'] == name, 'distinct artifact binding')
    artifact_ids.add(meta['id'])
    need(meta['workflow_run']['id'] == 36382085561 and meta['workflow_run']['head_sha'] == ORIGIN['head_sha'], 'raw API origin')
    need(meta['digest'] == 'sha256:' + phase['zip']['sha256'] and meta['size_in_bytes'] == phase['zip']['bytes'], 'raw API/ZIP digest')
    manifest = load(Path(phase['store']['manifest']['path']))
    need(entry['manifest_sha256'] == phase['store']['manifest']['sha256'], 'index-to-manifest binding')
    need(manifest['metadata_sha256'] == phase['metadata']['sha256'] == phase['store']['metadata']['sha256'], 'store original metadata binding')
    need(manifest['id'] == meta['id'] and manifest['name'] == name and manifest['zip'] == {key: phase['zip'][key] for key in ('bytes', 'sha256')}, 'store original artifact binding')
    actual_files = set()
    for p in root.rglob('*'):
        mode = p.lstat().st_mode
        need(stat.S_ISREG(mode) or stat.S_ISDIR(mode), 'ordinary restored entry')
        if stat.S_ISREG(mode):
            actual_files.add(p.relative_to(root).as_posix())
    count = size = 0
    with zipfile.ZipFile(Path(phase['zip']['path'])) as archive:
        rows = [r for r in archive.infolist() if not r.is_dir()]
        need(len(rows) == len({r.filename for r in rows}) and {r.filename for r in rows} == actual_files, 'exact original ZIP file names')
        for row in rows:
            with archive.open(row) as source, (root / row.filename).open('rb') as target:
                while block := source.read(1 << 20):
                    need(target.read(len(block)) == block, 'restored bytes differ from original ZIP')
                need(target.read(1) == b'', 'restored trailing bytes')
            need((root / row.filename).stat().st_size == row.file_size, 'restored exact length')
            count += 1
            size += row.file_size
    need((count, size) == (phase['files'], phase['raw_bytes']), 'measured totals')
    totals['files'] += count
    totals['raw_bytes'] += size
    job = load(Path(phase['job']['path']))
    need(job['id'] not in job_ids and job['run_id'] == 36382085561 and job['head_sha'] == ORIGIN['head_sha'] and job['run_attempt'] == 1, 'distinct original job origin')
    need(job['status'] == 'completed' and job['conclusion'] == 'success', 'original native job passed')
    suffix = 'Self-build C2 and C3' if role == 'producer' else 'Corpus ' + role.upper()
    need(job['name'] == f"Bootstrap {receipt['target']} repeat {receipt['repeat']} / {suffix}", 'original job role')
    job_ids.add(job['id'])
    if role == 'producer':
        repeat = receipt['repetitions'][0]
        for generation, reference in zip((2, 3), expected['local_reference_steps']):
            step = C.B.load(C.B.retained(root, repeat[f'step{generation}']))
            need(all(step[key] == reference[key] for key in ('compiler_sha256', 'result_sha256', 'inventory_sha256', 'job_sha256')), 'local S1 inputs')
            need({k: v for k, v in step['execution']['execution'].items() if k != 'elapsed_micros'} == reference['execution_without_elapsed'], 'local S1 non-time execution')
        for command in receipt['commands']:
            if command['command'][0] == 'cargo':
                text = re.sub(r'\x1b\[[0-9;]*m', '', (root / command['stderr']).read_text())
                warnings.extend(line for line in text.splitlines() if re.match(r'^warning(?:\[|:)', line))
    receipts.append((root, receipt))
need(not warnings, 'native Rust warnings')
compiler = C.compare_matrix(receipts, ORIGIN)
need(compiler == report['compiler_sha256'] == '76a07c08265bd2ef525164472b6b53ac3f0e6cbbedce3250c4202f40ffba34c8', 'frozen explicit-origin comparison')
local = load(FINAL / 'validation/local-replay/receipt.json')
original = load(FINAL / 'validation/original-aggregate.json')
with zipfile.ZipFile(HERE / 'artifact-10961755660.zip') as archive:
    need((FINAL / 'validation/original-aggregate.json').read_bytes() == archive.read('receipt.json'), 'original aggregate receipt bytes')
    need((FINAL / 'validation/original-aggregate-files.json').read_bytes() == archive.read('files.json'), 'original aggregate manifest bytes')
need(local['status'] == original['status'] == 'passed' and local['ci_origin'] is None and original['ci_origin'] == ORIGIN, 'distinct local/original origins')
bindings = {root.name: sha(root / 'receipt.json') for root, _ in receipts}
for aggregate in (local, original):
    rows = aggregate['phase_reports']
    need(len(rows) == 36 and {Path(r['path']).parent.name: r['sha256'] for r in rows} == bindings, 'local/original/restored receipt equality')
job = load(HERE / 'job-108868600539-direct.json')
need(job['id'] not in job_ids and job['id'] == 108868600539 and job['conclusion'] == 'success', 'distinct original aggregate job')
need((HERE / 'job-108868600539-api.log').is_file(), 'original aggregate log retained')
run = load(HERE / 'run-36382085561-final-direct.json')
need((run['id'], run['head_sha'], run['run_attempt'], run['status'], run['conclusion']) == (36382085561, ORIGIN['head_sha'], 1, 'completed', 'success'), 'original final run authority')
commands = load(FINAL / 'commands.json')
need(len(commands) == 4 and all(c['exit_code'] == 0 for c in commands) and report['local_command']['exit_code'] == 0, 'actual restore/replay exits')
need(all(sha(BASE / 'phase-stores' / role / 'index.json') == digest for role, digest in indices.items()) and sha(REPORT) == EXPECTED_REPORT, 'reviewed inputs unchanged')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
output = HERE / f'final-replay-review-{stamp}.json'
result = dict(status='passed', scope=__doc__, command=[sys.executable, '-B', '-W', 'error', str(Path(__file__))], cwd=str(Path.cwd()), reviewer_sha256=sha(Path(__file__)), reviewed_report=dict(path=str(REPORT), sha256=EXPECTED_REPORT), validator_sha256=sha(validator), archiver_sha256=sha(archiver), indices=indices, expected_origin=ORIGIN, phases=36, native_repetitions=12, native_corpus_jobs=24, distinct_phase_jobs=len(job_ids), compiler_sha256=compiler, **totals, checked_file_identities=len(seen_identities), rust_warnings=warnings, blocking_findings=[], retained_aggregate_log=dict(path=str(HERE / 'job-108868600539-api.log'), sha256=sha(HERE / 'job-108868600539-api.log')))
with output.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(path=str(output), status='passed', **totals, phases=36, rust_warnings=0)))

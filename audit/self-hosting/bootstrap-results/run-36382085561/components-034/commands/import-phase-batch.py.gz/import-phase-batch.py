from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap');repo=r/'trident';inputs=r/'measurements/ci-phases-readonly';stores=repo/'audit/self-hosting/bootstrap-results/run-36382085561/phase-stores';out=r/'measurements/ci-phases-imports'
helper=repo/'audit/self-hosting/bootstrap-results/archive-tool/archive.py';assert hashlib.sha256(helper.read_bytes()).hexdigest()=='acef178c58f48005c30ed7a300f84fc5ed8c5ab0ddcf498b318bb74ec2ec4e4e'
for ident in sys.argv[1:]:
 artifact=int(ident);meta=json.loads((inputs/f'artifact-{artifact}.json').read_text());name=meta['name'];role=name.rsplit('-attempt-',1)[0].rsplit('-',1)[1]
 assert role in ('producer','c2','c3') and name.startswith('bootstrap-phase-') and name.endswith('-attempt-1')
 path=out/f'{artifact}.json';assert not path.exists()
 cmd=[sys.executable,'-B',str(helper),'import','--zip',str(inputs/f'artifact-{artifact}.zip'),'--metadata',str(inputs/f'artifact-{artifact}.json'),'--run-id','36382085561','--head-sha','57491633fbccb58ae44dca2da438ee31430be1bc','--name',name,'--store',str(stores/role)]
 start=time.monotonic_ns();p=subprocess.run(cmd,capture_output=True)
 (out/f'{artifact}.stdout').write_bytes(p.stdout);(out/f'{artifact}.stderr').write_bytes(p.stderr)
 path.write_text(json.dumps({'argv':cmd,'cwd':str(Path.cwd()),'exit_code':p.returncode,'elapsed_ns':time.monotonic_ns()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
 print(artifact,p.returncode,p.stdout.decode(),p.stderr.decode(),flush=True)
 if p.returncode:raise SystemExit(p.returncode)

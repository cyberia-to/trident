"""Retain the exact original Linux x64 and Intel macOS additions and their component replay."""
from pathlib import Path
import gzip
import hashlib
import json

R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
M = R / 'measurements'
BASE = R / 'trident/audit/self-hosting/bootstrap-results/run-36382085561'
OUT = BASE / 'components-034'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def load(path):
    return json.loads(path.read_bytes())

producer = load(M / 'ci-phases-imports/producer-012/replay.json')
corpus = load(M / 'ci-phases-imports/corpora-022/replay.json')
assert producer['status'] == corpus['status'] == 'passed'
assert corpus['corpus_jobs'] == 22 and len(producer['rows']) == 12
indices = {'producer': producer['index_sha256'], **corpus['indices']}
selected = {}
for name in ('c2.stdout', 'c2.stderr', 'c3.stdout', 'c3.stderr', 'replay.json'):
    selected['corpora-022/' + name] = M / 'ci-phases-imports/corpora-022' / name
for name in ('replay-phase-corpora-022.py', 'import-phase-batch.py', Path(__file__).name):
    selected['commands/' + name] = M / name
for name in ('stdout', 'stderr'):
    selected['corpora-022/driver.' + name] = M / ('ci-phases-imports/replay-corpora-022.' + name)
for role, digest in indices.items():
    path = BASE / 'phase-stores' / role / 'index.json'
    assert sha(path.read_bytes()) == digest
    selected[role + '-index.json'] = path
selected['inputs/agent-phase-validation.json'] = M / 'ci-phases-readonly/phase-validation-20260928T085339Z.json'
for artifact, job in ((10959394712, 108829529729), (10959529394, 108829992661), (10960005998, 108829992644)):
    for suffix in ('json', 'stdout', 'stderr'):
        selected[f'imports/{artifact}.{suffix}'] = M / f'ci-phases-imports/{artifact}.{suffix}'
    for suffix in ('direct.json', 'api.log'):
        selected[f'jobs/job-{job}-{suffix}'] = M / f'ci-phases-readonly/job-{job}-{suffix}'
prior = BASE / 'components-031/retention.json'
report = dict(schema='trident/native-phase-components-retention/v1',
              status='twelve-producers-and-twenty-two-corpora-verified', matrix_acceptance=False,
              run_id=36382085561, head_sha='57491633fbccb58ae44dca2da438ee31430be1bc',
              indices=indices, producers=12, corpus_jobs=22,
              raw_files=producer['raw_files'] + corpus['raw_files'],
              raw_bytes=producer['raw_bytes'] + corpus['raw_bytes'],
              prior_snapshot=dict(path='../components-031/retention.json', sha256=sha(prior.read_bytes())), files={})
OUT.mkdir()
for name, path in selected.items():
    raw = path.read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    destination = OUT / (name + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(compressed)
    assert gzip.decompress(destination.read_bytes()) == path.read_bytes() == raw
    report['files'][name] = dict(bytes=len(raw), sha256=sha(raw), compressed_bytes=len(compressed),
                                 compressed_sha256=sha(compressed))
(OUT / 'retention.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('status', 'raw_files', 'raw_bytes', 'indices')}))

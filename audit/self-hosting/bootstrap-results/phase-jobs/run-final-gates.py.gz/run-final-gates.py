from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
CWD = ROOT / "trident-phases"
NAMES = [".github/workflows/selfhost-bootstrap.yml", ".github/workflows/selfhost-bootstrap-repeat.yml",
         "audit/self-hosting/bootstrap-runner.py", "audit/self-hosting/bootstrap-phases.py",
         "audit/self-hosting/bootstrap_phase_checks.py", "audit/self-hosting/test_bootstrap_runner.py",
         "audit/self-hosting/test_bootstrap_phases.py", "reference/self-hosting.md"]
CORE = ["audit/self-hosting/test_bootstrap_runner.py", "audit/self-hosting/test_bootstrap_phases.py",
        "audit/self-hosting/test_selfhost_fixed_point.py"]
LEGACY = ["audit/self-hosting/test_compiler_selection.py", "audit/self-hosting/test_native_compiler_runner.py"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source():
    return {name: sha((CWD / name).read_bytes()) for name in NAMES}


before = source()
commands = [
    ("final-normal", ["python3", "-B", "-W", "error", "-m", "unittest", *CORE, *LEGACY], CWD, 0),
    ("final-optimized-boundaries", ["python3", "-B", "-O", "-W", "error", "-m", "unittest", *CORE], CWD, 0),
    ("legacy-optimized-original-diagnostic", ["python3", "-B", "-O", "-W", "error", "-m", "unittest", *LEGACY], ROOT / "trident-ci", 1),
    ("final-actionlint", [str(ROOT / "actionlint-bin/actionlint"), *NAMES[:2]], CWD, 0),
    ("final-diffcheck", ["git", "diff", "--check"], CWD, 0),
]
rows = []
for name, argv, cwd, expected in commands:
    started = time.monotonic_ns()
    result = subprocess.run(argv, cwd=cwd, capture_output=True)
    elapsed = time.monotonic_ns() - started
    (OUT / (name + ".stdout")).write_bytes(result.stdout)
    (OUT / (name + ".stderr")).write_bytes(result.stderr)
    rows.append(dict(name=name, argv=argv, cwd=str(cwd), expected_exit=expected,
                     exit_code=result.returncode, elapsed_ns=elapsed,
                     stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr)))
    print(name, result.returncode, result.stderr.decode()[-150:], flush=True)
after = source()
record = dict(base_revision="c17bd0371c11746f46e20222c48cae2ab08be79d",
              observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope="Exact uncommitted phase delivery; synthetic wiring tests supply no guest or SH6 acceptance",
              legacy_optimized_diagnostic="Existing assertion-based corpus routing tests require ordinary Python; phase corpus-child explicitly rejects optimized Python. The diagnostic retains the original c17 behavior.",
              source_before=before, source_after=after, commands=rows)
(OUT / "final-gates.json").write_text(json.dumps(record, indent=2) + "\n")
if before != after or any(row["exit_code"] != row["expected_exit"] for row in rows):
    raise SystemExit(1)

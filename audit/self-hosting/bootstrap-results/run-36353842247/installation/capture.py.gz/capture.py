import gzip, hashlib, json, os, pathlib, re, subprocess, time
r=pathlib.Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
repo=r/'trident-legacy-retention'
work=r/'measurements/legacy-retention/install'
work.mkdir()
prefix=r/'install-legacy-retention'
(prefix/'bin').mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def capture():
 result={}
 for name in ('trident','joy','nox','hemera','strata','zheng','bbg','lens','neuron'):
  path=repo if name=='trident' else r/name
  result[name]=dict(path=str(path),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=path,text=True))
 return result
def source_hashes():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
 return {name:sha(repo/name) for name in names if name and ((name.startswith(('src/','lib/','compiler/')) and name.endswith(('.rs','.tri'))) or name in ('Cargo.toml','Cargo.lock','build.rs'))}
report=dict(scope='Local isolated postcommit installation of an audit-only Trident revision; no compiler/runtime change or native CI acceptance',command_script=str(pathlib.Path(__file__).resolve()),command_script_sha256=sha(pathlib.Path(__file__)),inputs_start=capture(),source_sha256_start=source_hashes(),commands=[],started_ns=time.time_ns())
env=os.environ.copy();env['PATH']=str(prefix/'bin')+os.pathsep+env['PATH']
command=['cargo','install','--path',str(repo),'--force','--locked','--offline','--root',str(prefix),'--target-dir',str(r/'target-legacy-retention'),'--jobs','2']
report['commands'].append(dict(command=command,cwd=str(repo),path_prefix=str(prefix/'bin')))
with (work/'stdout.log').open('xb') as out,(work/'stderr.log').open('xb') as err:
 result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
report['commands'][-1]['exit_code']=result.returncode
report['inputs_end']=capture();report['source_sha256_end']=source_hashes();report['finished_ns']=time.time_ns()
report['rust_warning_lines']=[line for line in (work/'stderr.log').read_text().splitlines() if re.match(r'^warning(?::|\[)',line)]
report['source_unchanged']=report['source_sha256_start']==report['source_sha256_end']
report['inputs_unchanged']=report['inputs_start']==report['inputs_end']
report['status']='passed' if result.returncode==0 and report['source_unchanged'] and report['inputs_unchanged'] and not report['rust_warning_lines'] else 'failed'
report['binaries']={}
if result.returncode==0:
 for binary in ('trident','trident-lsp'):
  path=prefix/'bin'/binary;report['binaries'][binary]=dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
 smoke=subprocess.run([str(prefix/'bin/trident'),'--version'],cwd=repo,env=env,capture_output=True,text=True)
 report['commands'].append(dict(command=[str(prefix/'bin/trident'),'--version'],exit_code=smoke.returncode,stdout=smoke.stdout,stderr=smoke.stderr))
 if smoke.returncode!=0:report['status']='failed'
report['logs']={name:dict(bytes=(work/name).stat().st_size,sha256=sha(work/name)) for name in ('stdout.log','stderr.log')}
(work/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],exit_code=result.returncode,rust_warnings=len(report['rust_warning_lines']),source_unchanged=report['source_unchanged'],inputs_unchanged=report['inputs_unchanged'])),flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)

"""Local binding and rejection replay for the immutable failed CI aggregate."""
import datetime
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys

out = Path(__file__).resolve().parent
script = out / 'bootstrap-runner-at-c17bd03.py'
spec = importlib.util.spec_from_file_location('frozen', script)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
origin = dict(run_id='36359020560', run_attempt='1', head_sha='c17bd0371c11746f46e20222c48cae2ab08be79d')
aggregate = out / 'aggregate/bootstrap-matrix-comparison-attempt-1/receipt.json'
d = m.load(aggregate)
expected_error = 'ValueError: bootstrap not passed/current schema'
m.require(d['ci_origin'] == origin and d['status'] == 'failed' and d['error'] == expected_error, 'unexpected aggregate')
seen = set()
for row in d['platform_reports']:
    name = PurePosixPath(row['path']).parent.name
    m.require(name not in seen, 'duplicate platform')
    seen.add(name)
    m.require(m.sha(out / 'platforms' / name / 'receipt.json') == row['sha256'], 'original receipt hash mismatch')
expected = {f'bootstrap-{target}-repeat-{number}-attempt-1' for target in m.TARGETS for number in (1, 2)}
m.require(seen == expected, 'incomplete exact matrix set')
reports = [(out / 'platforms' / name, m.load(out / 'platforms' / name / 'receipt.json')) for name in sorted(seen)]
try:
    m.compare_matrix(reports, origin)
except ValueError as error:
    m.require('ValueError: ' + str(error) == expected_error, 'different rejection')
else:
    raise ValueError('partial matrix was accepted')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
replay = out / ('matrix-local-replay-' + stamp)
command = [sys.executable, '-W', 'error', str(script), '--matrix', str(out / 'platforms'), '--output', str(replay)]
env = dict(os.environ)
env.pop('GITHUB_ACTIONS', None)
p = subprocess.run(command, capture_output=True, env=env, timeout=90)
m.require(p.returncode == 1 and expected_error.encode('utf-8') in p.stderr, 'different CLI rejection')
m.require(m.load(replay / 'receipt.json')['ci_origin'] is None, 'local replay falsely claims CI origin')
run = m.load(out / 'run-36359020560-final-direct.json')
job = m.load(out / 'job-108794676918-direct.json')
m.require((run['id'], run['head_sha'], run['run_attempt'], run['status'], run['conclusion']) ==
          (36359020560, origin['head_sha'], 1, 'completed', 'failure'), 'final run mismatch')
m.require(job['id'] == 108794676918 and job['run_id'] == 36359020560 and job['status'] == 'completed' and job['conclusion'] == 'failure', 'aggregate job mismatch')
report = dict(scope='Local verification of actual failed CI aggregate. No matrix acceptance.', run_id=36359020560,
              head_sha=origin['head_sha'], run_attempt=1, aggregate_sha256=m.sha(aggregate), aggregate_origin=origin,
              all_twelve_original_receipt_hashes_match=True, explicit_origin_comparison_error=expected_error,
              platform_statuses={name: receipt['status'] for name, (_, receipt) in zip(sorted(seen), reports)},
              validator_sha256=m.sha(script), command=command, exit_code=p.returncode,
              stdout=p.stdout.decode('utf-8'), stderr=p.stderr.decode('utf-8'), local_replay_ci_origin=None,
              final_run_api_sha256=m.sha(out / 'run-36359020560-final-direct.json'),
              aggregate_job_api_sha256=m.sha(out / 'job-108794676918-direct.json'))
path = out / 'aggregate-validation.json'
with path.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
print(path)

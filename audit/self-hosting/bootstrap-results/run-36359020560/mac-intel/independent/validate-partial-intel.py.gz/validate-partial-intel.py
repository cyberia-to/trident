"""Validate finished components of timed-out jobs without accepting whole repetitions."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re

out = Path(__file__).resolve().parent
script = out / 'bootstrap-runner-at-c17bd03.py'
spec = importlib.util.spec_from_file_location('frozen', script)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
expected_pins = dict(re.findall(r'"([a-z]+)":"([0-9a-f]{40})"', (out / 'selfhost-bootstrap-at-c17bd03.yml').read_text()))
expected_pins['trident'] = 'c17bd0371c11746f46e20222c48cae2ab08be79d'
origin = dict(run_id='36359020560', run_attempt='1', head_sha=expected_pins['trident'])
baseline_root = out / 'platforms/bootstrap-x86_64-pc-windows-msvc-repeat-2-attempt-1'
baseline_report = m.load(baseline_root / 'receipt.json')
baseline_compiler, baseline_source, baseline_inventory = m.compiler_steps(baseline_root, baseline_report['repetitions'][0])
rows = []
for number, job, artifact in ((1, 108732342534, 10951539650), (2, 108732342711, 10952109432)):
    root = out / 'platforms' / f'bootstrap-x86_64-apple-darwin-repeat-{number}-attempt-1'
    receipt = m.load(root / 'receipt.json')
    m.require(receipt['status'] == 'running' and receipt['pins'] == expected_pins and receipt['ci_origin'] == origin and
              receipt['runner_sha256'] == m.sha(script) and receipt['profile'] == m.PROFILE, 'partial job identity mismatch')
    m.require(receipt['target'] == 'x86_64-apple-darwin' and receipt['rust_version'] == '1.95.0' and
              'host: x86_64-apple-darwin' in receipt['host']['rust'].splitlines() and
              'release: 1.95.0' in receipt['host']['rust'].splitlines(), 'native tool identity mismatch')
    repeat = receipt['repetitions'][0]
    m.require(m.selected(receipt) == [number] and repeat['number'] == number, 'wrong repetition')
    compiler, source, inventory_sha = m.compiler_steps(root, repeat)
    m.require(compiler == baseline_compiler and inventory_sha == baseline_inventory and
              all(source[k] == baseline_source[k] for k in ('source_sha256_set', 'options', 'limits')), 'frozen compilation inputs differ')
    compiler_sha = hashlib.sha256(compiler).hexdigest()
    m.require(compiler_sha == '76a07c08265bd2ef525164472b6b53ac3f0e6cbbedce3250c4202f40ffba34c8', 'different completed compiler')
    corpora = {}
    for name, identity in repeat['corpora'].items():
        child = m.load(m.retained(root, identity))
        m.corpus_identity(child, compiler_sha, repeat['tools']['joy'], m.CORPORA[name[3:] + '.py'])
        corpora[name] = dict(status=child['status'], observations=len(child['observations']), commands=len(child['commands']))
    timings = {}
    for stage in ('step2', 'step3'):
        step = m.load(root / repeat[stage]['path'])
        command = step['commands'][-1]
        timings[stage] = dict(command_elapsed_nanoseconds=command['elapsed_nanoseconds'], execution=json.loads(command['stdout'])['execution'])
    warnings = []
    for command in receipt['commands']:
        if command['command'][0] == 'cargo':
            text = re.sub(r'\x1b\[[0-9;]*m', '', (root / command['stderr']).read_text())
            warnings.extend(dict(file=command['stderr'], line=i + 1, text=line) for i, line in enumerate(text.splitlines()) if re.match(r'^warning(?:\[|:)', line))
    last = receipt['commands'][-1]
    active_name = last['command'][last['command'].index('--output') + 1].replace('\\', '/').split('/')[-1]
    active = m.load(root / f'repeat-{number}' / active_name)
    log = out / f'job-{job}-api.log'
    timeout_lines = [dict(line=i + 1, text=line) for i, line in enumerate(log.read_text().splitlines()) if 'has timed out after 330 minutes' in line]
    m.require(len(timeout_lines) == 1 and active['status'] == 'running', 'interruption evidence differs')
    rows.append(dict(repeat=number, job_id=job, artifact_id=artifact, compiler_sha256=compiler_sha, inventory_sha256=inventory_sha,
                     receipt_sha256=m.sha(root / 'receipt.json'), completed_corpora=corpora, whole_build_timings=timings,
                     active_command=last, active_corpus=dict(path=active_name, status=active['status'], observations=len(active['observations']), commands=len(active['commands'])),
                     timeout_evidence=timeout_lines, rust_warning_lines=warnings, whole_repetition_accepted=False))
report = dict(scope='Finished components verified only; both whole repetitions and matrix remain unaccepted after330-minute GitHub step timeout.',
              run_id=36359020560, head_sha=expected_pins['trident'], validator_sha256=m.sha(script), rows=rows, matrix_acceptance=False)
path = out / 'intel-partial-validation-strict.json'
with path.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
print(path)

"""Retain the original failed c17 run without changing any prior artifact entry."""
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import time
import zipfile

repo = Path.cwd().resolve()
inputs = Path(__file__).resolve().parent
run = repo / 'audit/self-hosting/bootstrap-results/run-36359020560'
store = run / 'platform-store'
mac = run / 'mac-intel'
aggregate = run / 'aggregate'
helper = repo / 'audit/self-hosting/bootstrap-results/archive-tool/archive.py'
runner_path = inputs / 'bootstrap-runner-at-c17bd03.py'
head = 'c17bd0371c11746f46e20222c48cae2ab08be79d'
origin = dict(run_id='36359020560', run_attempt='1', head_sha=head)
error_text = 'ValueError: bootstrap not passed/current schema'
old_sha = '2949968787dca98cb5740f76c499969b8002792e26bc0732772694174d3d3174'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    with path.open('rb') as stream:
        h = hashlib.sha256()
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
        return h.hexdigest()


def load(path):
    return json.loads(path.read_bytes())


for folder in (mac, aggregate):
    folder.mkdir(exist_ok=False)
manifests = {mac: [], aggregate: []}


def retain(folder, name, raw, compress=True):
    path = folder / (name + '.gz' if compress else name)
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = gzip.compress(raw, compresslevel=9, mtime=0) if compress else raw
    with path.open('xb') as stream:
        stream.write(encoded)
    manifests[folder].append(dict(path=str(path.relative_to(folder)), raw_bytes=len(raw), raw_sha256=sha_bytes(raw),
                                  stored_bytes=len(encoded), stored_sha256=sha_bytes(encoded)))


def receipt(folder, name, value):
    retain(folder, name, (json.dumps(value, indent=2) + '\n').encode('utf-8'))


def command(name, argv, expected=0):
    started = time.time_ns()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    env.pop('GITHUB_ACTIONS', None)
    p = subprocess.run(argv, cwd=repo, env=env, capture_output=True, timeout=240)
    retain(mac, 'operations/' + name + '.stdout', p.stdout)
    retain(mac, 'operations/' + name + '.stderr', p.stderr)
    receipt(mac, 'operations/' + name + '.json', dict(command=argv, cwd=str(repo), started_ns=started, ended_ns=time.time_ns(),
            exit_code=p.returncode, environment_overrides={'PYTHONDONTWRITEBYTECODE': '1', 'GITHUB_ACTIONS': None}))
    require(p.returncode == expected, name + ': unexpected exit code ' + str(p.returncode))
    return p


try:
    source_revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    receipt(mac, 'invocation.json', dict(command=[sys.executable, '-W', 'error', str(Path(__file__).resolve())], cwd=str(repo),
            source_revision=source_revision, helper_sha256=sha(helper), runner_sha256=sha(runner_path), script_sha256=sha(Path(__file__)),
            run_id=36359020560, head_sha=head, matrix_acceptance=False))
    retain(mac, 'source/retain-final.py', Path(__file__).read_bytes())
    require(sha(store / 'index.json') == old_sha, 'unexpected original ten-entry store index')
    before = {str(p.relative_to(store)): sha(p) for p in store.rglob('*') if p.is_file()}
    old = load(store / 'index.json')
    require(len(old['artifacts']) == 10, 'ten original entries required')
    retain(mac, 'operations/index-010.json', (store / 'index.json').read_bytes())
    receipt(mac, 'operations/store-before.json', before)
    for count, number, artifact in ((11, 1, 10951539650), (12, 2, 10952109432)):
        name = f'bootstrap-x86_64-apple-darwin-repeat-{number}-attempt-1'
        command(f'import-{artifact}', [sys.executable, '-W', 'error', str(helper), 'import', '--zip', str(inputs / f'artifact-{artifact}.zip'),
                '--metadata', str(inputs / f'artifact-{artifact}.json'), '--run-id', '36359020560', '--head-sha', head,
                '--name', name, '--store', str(store)])
        retain(mac, f'operations/index-{count:03}.json', (store / 'index.json').read_bytes())
        print('imported', artifact, sha(store / 'index.json'), flush=True)
    final = load(store / 'index.json')
    require(len(final['artifacts']) == 12 and all(final['artifacts'][n] == v for n, v in old['artifacts'].items()), 'prior index entries changed')
    require(all(sha(store / p) == digest for p, digest in before.items() if p != 'index.json'), 'prior stored bytes changed')
    final_sha = sha(store / 'index.json')
    restored = inputs / 'restored-012-final'
    command('restore-012', [sys.executable, '-W', 'error', str(helper), 'restore', '--store', str(store), '--output', str(restored), '--index-sha256', final_sha])
    spec = importlib.util.spec_from_file_location('frozen', runner_path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    expected = json.loads(gzip.decompress((run / 'windows-x64/expected.json.gz').read_bytes()))
    require(sha(runner_path) == expected['runner_sha256'], 'frozen runner changed')
    require(len(expected['local_reference_steps']) == 2, 'two local reference steps required')
    checks, reports = [], []
    for name, identity in sorted(final['artifacts'].items()):
        artifact = identity['id']
        meta = load(inputs / f'artifact-{artifact}.json')
        archive = inputs / f'artifact-{artifact}.zip'
        require(meta['name'] == name and meta['workflow_run']['id'] == 36359020560 and meta['workflow_run']['head_sha'] == head, 'archive provenance')
        require(meta['digest'] == 'sha256:' + sha(archive) and meta['size_in_bytes'] == archive.stat().st_size, 'archive API digest/size')
        root = restored / name
        with zipfile.ZipFile(archive) as z:
            files = [x for x in z.infolist() if not x.is_dir()]
            require({x.filename for x in files} == {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}, 'restored file set differs')
            for row in files:
                require(z.read(row) == (root / row.filename).read_bytes(), 'restored ZIP bytes differ: ' + row.filename)
        producer = m.load(root / 'receipt.json')
        require(producer['pins'] == expected['pins'] and producer['runner_sha256'] == expected['runner_sha256'] and producer['ci_origin'] == origin, 'producer source/tool origin')
        require(producer['rust_version'] == expected['rust_version'] and producer['profile'] == m.PROFILE, 'producer profile/Rust release')
        require('host: ' + producer['target'] in producer['host']['rust'].splitlines(), 'native Rust host')
        number = m.selected(producer)[0]
        require(name == f"bootstrap-{producer['target']}-repeat-{number}-attempt-1", 'artifact target/repetition name')
        repeat = producer['repetitions'][0]
        compiler, source, inventory_sha = m.compiler_steps(root, repeat)
        require(sha_bytes(compiler) == '76a07c08265bd2ef525164472b6b53ac3f0e6cbbedce3250c4202f40ffba34c8', 'completed compiler differs')
        steps = []
        for generation, local in zip((2, 3), expected['local_reference_steps']):
            step = m.load(m.retained(root, repeat[f'step{generation}']))
            for key in ('compiler_sha256', 'result_sha256', 'inventory_sha256', 'job_sha256'):
                require(step[key] == local[key], f'local S1 step{generation} {key}')
            execution = step['execution']['execution']
            require({k: v for k, v in execution.items() if k != 'elapsed_micros'} == local['execution_without_elapsed'], 'non-time execution fields differ')
            steps.append(dict(generation=generation, **{k: step[k] for k in ('compiler_sha256', 'result_sha256', 'inventory_sha256', 'job_sha256')},
                              elapsed_micros=execution['elapsed_micros'], command_elapsed_nanoseconds=step['commands'][-1]['elapsed_nanoseconds']))
        if producer['status'] == 'passed':
            m.compare([(root, producer)])
        else:
            require(producer['target'] == 'x86_64-apple-darwin' and producer['status'] == 'running', 'unexpected unfinished producer')
            for key, identity in repeat['corpora'].items():
                m.corpus_identity(m.load(m.retained(root, identity)), sha_bytes(compiler), repeat['tools']['joy'], m.CORPORA[key[3:] + '.py'])
        checks.append(dict(name=name, artifact_id=artifact, zip_sha256=sha(archive), file_count=len(files), raw_bytes=sum(x.file_size for x in files),
                           receipt_status=producer['status'], receipt_sha256=sha(root / 'receipt.json'), local_s1_steps=steps))
        reports.append((root, producer))
    p = command('matrix-local-red', [sys.executable, '-W', 'error', str(runner_path), '--matrix', str(restored), '--output', str(inputs / 'restored-012-matrix-red')], expected=1)
    require(error_text.encode() in p.stderr, 'unexpected matrix rejection')
    local = m.load(inputs / 'restored-012-matrix-red/receipt.json')
    require(local['ci_origin'] is None and local['status'] == 'failed', 'local replay provenance')
    retain(mac, 'operations/local-matrix-receipt.json', (inputs / 'restored-012-matrix-red/receipt.json').read_bytes())
    try:
        m.compare_matrix(reports, origin)
    except ValueError as error:
        require('ValueError: ' + str(error) == error_text, 'different explicit-origin error')
    else:
        raise ValueError('incomplete matrix accepted')
    aid = 10953060170
    api = load(inputs / f'artifact-{aid}.json')
    original_zip = inputs / f'artifact-{aid}.zip'
    require(api['digest'] == 'sha256:' + sha(original_zip) and api['size_in_bytes'] == original_zip.stat().st_size, 'aggregate API digest/size')
    require(api['workflow_run']['id'] == 36359020560 and api['workflow_run']['head_sha'] == head, 'aggregate artifact origin')
    with zipfile.ZipFile(original_zip) as z:
        require(z.namelist() == ['receipt.json'], 'unexpected aggregate files')
        raw_aggregate = z.read('receipt.json')
    original = json.loads(raw_aggregate)
    require(original['status'] == 'failed' and original['error'] == error_text and original['ci_origin'] == origin, 'actual aggregate result')
    hashes = {name: sha(restored / name / 'receipt.json') for name in final['artifacts']}
    for receipt_value in (original, local):
        rows = receipt_value['platform_reports']
        require(len(rows) == 12 and {PurePosixPath(x['path']).parent.name: x['sha256'] for x in rows} == hashes, 'aggregate receipt hashes differ')
    final_run = load(inputs / 'run-36359020560-final-direct.json')
    job = load(inputs / 'job-108794676918-direct.json')
    for value in (final_run, job):
        require(value['head_sha'] == head and value['run_attempt'] == 1 and value['status'] == 'completed' and value['conclusion'] == 'failure', 'final API result')
    require(final_run['id'] == 36359020560 and job['run_id'] == 36359020560, 'final API run')
    retain(aggregate, 'artifact-10953060170.zip', original_zip.read_bytes(), compress=False)
    retain(aggregate, 'artifact-10953060170.json', (inputs / f'artifact-{aid}.json').read_bytes())
    retain(aggregate, 'receipt.json', raw_aggregate)
    for filename in ('job-108794676918-direct.json', 'job-108794676918-api.log', 'run-36359020560-final-direct.json', '36359020560-20260928T050602Z.json', 'aggregate-validation.json'):
        retain(aggregate, filename, (inputs / filename).read_bytes())
    for number, job, artifact in ((1, 108732342534, 10951539650), (2, 108732342711, 10952109432)):
        for suffix in ('direct.json', 'api.log'):
            retain(mac, f'github/job-{job}-{suffix}', (inputs / f'job-{job}-{suffix}').read_bytes())
        retain(mac, f'independent/artifact-{artifact}-download.json', (inputs / f'artifact-{artifact}-download.json').read_bytes())
    for filename in ('intel-partial-validation-strict.json', 'validate-partial-intel.py', 'verify-aggregate.py'):
        retain(mac, 'independent/' + filename, (inputs / filename).read_bytes())
    report = dict(status='retention-verified', matrix_acceptance=False, ci_result='failure', source_revision=source_revision,
                  original_head_sha=head, run_id=36359020560, run_attempt=1, old_index_sha256=old_sha, final_index_sha256=final_sha,
                  prior_ten_entries_and_stored_bytes_unchanged=True, restored=str(restored), platform_count=12, platforms=checks,
                  local_cli_exit_code=p.returncode, explicit_origin_error=error_text, aggregate_receipt_sha256=sha_bytes(raw_aggregate),
                  aggregate_all_twelve_original_receipt_hashes_match=True, aggregate_zip_sha256=sha(original_zip))
    receipt(mac, 'operations/validation.json', report)
    receipt(aggregate, 'binding.json', dict(original_origin=origin, original_status='failed', error=error_text, platform_receipt_hashes=hashes,
                                         aggregate_receipt_sha256=sha_bytes(raw_aggregate), local_replay_ci_origin=None, matrix_acceptance=False))
    print(json.dumps(dict(final_index_sha256=final_sha, platforms=12, matrix_acceptance=False, restored=str(restored))), flush=True)
finally:
    for folder, entries in manifests.items():
        with (folder / 'files.json').open('x', encoding='utf-8') as stream:
            json.dump(dict(scope='Lossless final failed-run evidence; archival checks do not establish matrix acceptance', files=entries), stream, indent=2)
            stream.write('\n')

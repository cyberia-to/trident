"""Exact ordered chunks for the reviewed SH7 archive; no archive rewriting."""
import hashlib
import json
from pathlib import Path
import re

EXPECTED = {'bytes': 602191451,
            'sha256': 'fa0f99785b4f499067683949a4126a1e4837558fbd421c0c4d61fedc39000d61'}
PART_BYTES = 128 * 1024 * 1024
REPOSITORY = 'cyberia-to/trisha'
RELEASE = 389977897
TAG = 'candidate-20260916.1'


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(path):
    with path.open('rb') as source:
        digest = hashlib.file_digest(source, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


def valid_name(name):
    return isinstance(name, str) and name not in {'.', '..'} and re.fullmatch(r'[A-Za-z0-9._-]+', name)


def validate(manifest, expected):
    require(manifest['schema'] == 'trident/sh7-ordered-parts/v1', 'part schema')
    require({k: manifest['archive'][k] for k in ('bytes', 'sha256')} == expected, 'archive identity')
    require(valid_name(manifest['archive']['name']), 'archive filename')
    size = manifest['part_bytes']
    require(isinstance(size, int) and size > 0, 'part size')
    count = (expected['bytes'] + size - 1) // size
    require(len(manifest['parts']) == count and count > 0, 'part count')
    offset = 0
    names = set()
    for number, part in enumerate(manifest['parts'], 1):
        require(part['number'] == number and part['offset'] == offset, 'part order/offset')
        require(valid_name(part['name']) and part['name'] not in names, 'unique safe part name')
        require(part['bytes'] == min(size, expected['bytes'] - offset), 'part length')
        require(re.fullmatch('[0-9a-f]{64}', part['sha256']), 'part SHA-256')
        names.add(part['name'])
        offset += part['bytes']
    require(offset == expected['bytes'], 'complete ordered archive')


def split(source, destination, prefix, expected=EXPECTED, part_bytes=PART_BYTES):
    require(valid_name(prefix), 'safe prefix')
    require(source.is_file() and not source.is_symlink(), 'regular archive required')
    require(source.stat().st_size == expected['bytes'], 'reviewed archive size')
    destination.mkdir()
    count = (expected['bytes'] + part_bytes - 1) // part_bytes
    rows = []
    whole = hashlib.sha256()
    with source.open('rb') as original:
        for number in range(1, count + 1):
            size = min(part_bytes, expected['bytes'] - (number - 1) * part_bytes)
            name = f'{prefix}.part-{number:02}-of-{count:02}'
            digest = hashlib.sha256()
            remaining = size
            with (destination / name).open('xb') as part:
                while remaining:
                    block = original.read(min(1024 * 1024, remaining))
                    require(block, 'archive truncated while splitting')
                    part.write(block)
                    digest.update(block)
                    whole.update(block)
                    remaining -= len(block)
            rows.append(dict(number=number, offset=(number - 1) * part_bytes,
                             name=name, bytes=size, sha256=digest.hexdigest()))
        require(original.read(1) == b'', 'archive grew while splitting')
    require(whole.hexdigest() == expected['sha256'], 'reviewed archive hash')
    manifest = dict(schema='trident/sh7-ordered-parts/v1',
        archive=dict(name=source.name, **expected), part_bytes=part_bytes, parts=rows)
    validate(manifest, expected)
    with (destination / 'parts.json').open('x') as output:
        json.dump(manifest, output, indent=2)
        output.write('\n')
    return manifest


def asset_identity(asset, expected):
    require(isinstance(asset['id'], int) and asset['id'] > 0, 'server asset id')
    require(asset['name'] == expected['name'], 'server asset name')
    require(asset['size'] == expected['bytes'], 'server asset size')
    require(asset.get('digest') == 'sha256:' + expected['sha256'], 'server asset digest')
    require(asset['state'] == 'uploaded', 'server asset upload incomplete')
    url = f'https://api.github.com/repos/{REPOSITORY}/releases/assets/{asset["id"]}'
    require(asset['url'] == url, 'server asset origin')
    return {key: asset[key] for key in ('id', 'name', 'size', 'digest', 'state', 'url', 'browser_download_url')}


def assemble(manifest, downloaded, destination, expected=EXPECTED):
    validate(manifest, expected)
    digest = hashlib.sha256()
    count = 0
    with destination.open('xb') as output:
        for part in manifest['parts']:
            path = downloaded / part['name']
            require(identity(path) == {k: part[k] for k in ('bytes', 'sha256')}, 'downloaded part identity')
            with path.open('rb') as source:
                while block := source.read(1024 * 1024):
                    output.write(block)
                    digest.update(block)
                    count += len(block)
    require({'bytes': count, 'sha256': digest.hexdigest()} == expected, 'reassembled archive identity')
    restored = identity(destination)
    require(restored == expected, 'reassembled file read-back identity')
    return restored

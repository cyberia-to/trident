# Ordered SH7 evidence transport

Scope: transfer the immutable reviewed 602191451-byte archive, SHA256 fa0f99785b4f499067683949a4126a1e4837558fbd421c0c4d61fedc39000d61, to existing unpublished Trisha draft389977897 / candidate-20260916.1. Preserve the stopped original attempt; do not delete its asset.

1. Record original process, network progress, command and failed receipt; stop only authorized gh PID89540 after exact argv/parent checks.
2. Split the exact archive into ordered128MiB parts under unique names; record full archive and each part hash/offset.
3. Review source before execution. Upload at most4 parts concurrently. Every upload checks draft identity and absent tag before and after, refuses an existing name, uses no clobber. Each upload has a7200-second transport deadline, without changing proof caps.
4. Require server asset id/name/size/SHA256/state, independently download each asset, verify part bytes, reassemble in manifest order and verify full archive size/SHA256.
5. Upload/download the immutable part manifest, verify its bytes too, and retain all command logs, asset metadata, success/failure receipts and reviewed source identity. No release edit/promotion/tag operation; no original evidence edits.

State: completed successfully. The original stopped upload and its failed receipt remain preserved. All five exact parts were uploaded to draft389977897, checked against server SHA256, independently downloaded and reassembled to the original602191451-byte archive SHAfa0f99785b4f499067683949a4126a1e4837558fbd421c0c4d61fedc39000d61. The uploaded/downloaded4763-byte manifest is asset604791641, SHA9bc033f4dffb8e248a55b445db884ca035886705923f2c7a596daa45914febac. Final draft/tag-absence checks passed; no publication, tag creation, overwrite or deletion occurred. Independent final-review.json passed all64 exact commands,128 transport output hashes and11 preparation logs. Monitor writes are quiescent. Original archive, local parts and restored payloads remain retained outside the compact audit package.

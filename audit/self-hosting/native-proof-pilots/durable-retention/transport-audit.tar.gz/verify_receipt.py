"""Independent replay of the retained SH7 chunk-transport receipt (read-only)."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import sys

ARCHIVE = dict(bytes=602191451,
    sha256='fa0f99785b4f499067683949a4126a1e4837558fbd421c0c4d61fedc39000d61')
MANIFEST = dict(bytes=1435,
    sha256='71da09afe32c78d01bc3a43cd2e80e35a2dd9804fd1e51fd5a1d5cd3f6399f29')
REPO = 'cyberia-to/trisha'
RELEASE = 389977897
TAG = 'candidate-20260916.1'


def check(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    check(path.is_file() and not path.is_symlink(), f'regular file: {path}')
    count = 0
    hasher = hashlib.sha256()
    with path.open('rb') as source:
        while block := source.read(1024 * 1024):
            count += len(block)
            hasher.update(block)
    return dict(bytes=count, sha256=hasher.hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--original', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    run = args.run.resolve()
    home = run.parent
    report = json.loads((run / 'receipt.json').read_text())
    check(report['status'] == 'passed' and report['failures'] == [], 'complete successful transport')
    check(report['archive'] == report['reassembled'] == ARCHIVE, 'full archive binding')
    check(report['repository'] == REPO and report['release_id'] == RELEASE and report['tag'] == TAG,
          'transport destination')
    check(report['upload_workers'] == 4 and report['upload_wall_seconds'] == 7200, 'transport limits')
    check(digest(home / 'parts/parts.json') == report['part_manifest'] == MANIFEST, 'reviewed manifest')
    manifest = json.loads((home / 'parts/parts.json').read_text())
    check(manifest['archive'] == dict(name=args.original.name, **ARCHIVE), 'original filename')
    check(digest(args.original) == ARCHIVE, 'original archive unchanged')
    check(digest(run / manifest['archive']['name']) == ARCHIVE, 'restored archive identity')
    check(len(manifest['parts']) == 5 and manifest['part_bytes'] == 134217728, 'five ordered parts')
    for filename, expected in report['source'].items():
        check(digest(home / filename) == expected, 'executed source unchanged: ' + filename)
    source_review = json.loads((home / 'root-review.json').read_text())
    check(source_review['verdict'] == 'no blocking findings'
          and source_review['prepared_manifest_sha256'] == MANIFEST['sha256'], 'independent source review binding')
    for name in ('chunks.py', 'transport.py', 'test_chunks.py'):
        check(digest(home / name)['sha256'] == source_review['source_at_acknowledgment'][name],
              'root-reviewed executable source unchanged')
    preparation = json.loads((home / 'preparation-checks.json').read_text())
    preparation_logs = 0
    for expected in preparation['source'].values():
        check(digest(home / expected['path']) == {k: expected[k] for k in ('bytes', 'sha256')},
              'tested preparation source unchanged')
    for command in preparation['commands']:
        check(command['exit_code'] == 0, 'preparation check passed')
        for channel in ('stdout', 'stderr'):
            if channel in command:
                expected = command[channel]
                check(digest(home / expected['path']) == {k: expected[k] for k in ('bytes', 'sha256')},
                      'original observation and preparation log unchanged')
                preparation_logs += 1

    commands = {row['name']: row for row in report['commands']}
    check(len(commands) == len(report['commands']), 'unique command records')
    expected_commands = {}
    checked_logs = 0
    for row in commands.values():
        check(row['elapsed_ns'] > 0 and row['wall_seconds'] == 7200, 'bounded command observation')
        check('error' not in row and 'ended_utc' in row, 'complete command result')
        for channel in ('stdout', 'stderr'):
            item = row[channel]
            path = (run / item['path']).resolve()
            check(path.is_relative_to(run), 'retained output stays in owned run')
            check(digest(path) == {key: item[key] for key in ('bytes', 'sha256')}, 'retained output hash')
            checked_logs += 1

    def record(name, argv, exit_code=0):
        expected_commands[name] = argv
        row = commands[name]
        check(row['argv'] == argv and row['exit_code'] == exit_code, 'exact command: ' + name)
        return run / row['stdout']['path']

    def draft(label):
        release = json.loads(record(label, ['gh', 'api', f'repos/{REPO}/releases/{RELEASE}']).read_text())
        check(release['id'] == RELEASE and release['draft'] is True and release['published_at'] is None
              and release['tag_name'] == TAG, 'retained unpublished draft: ' + label)
        absent = json.loads(record(label + '-tag', ['gh', 'api', f'repos/{REPO}/git/ref/tags/{TAG}'], 1).read_text())
        check(str(absent['status']) == '404', 'retained tag absence: ' + label)
        selected = json.loads(record(label + '-selected', ['gh', 'release', 'view', TAG, '--repo', REPO,
            '--json', 'databaseId,isDraft,tagName,publishedAt']).read_text())
        check(selected == dict(databaseId=RELEASE, isDraft=True, tagName=TAG, publishedAt=None),
              'exact selected draft: ' + label)
        pages = json.loads(record(label + '-assets', ['gh', 'api', '--paginate', '--slurp',
            f'repos/{REPO}/releases/{RELEASE}/assets?per_page=100']).read_text())
        check(isinstance(pages, list) and all(isinstance(page, list) for page in pages), 'complete page inventory')
        return [asset for page in pages for asset in page]

    assets = []

    def transfer(label, source, expected):
        before = draft(label + '-before')
        check(all(a['name'] != expected['name'] for a in before), 'unique absent asset before upload')
        record(label + '-upload', ['gh', 'release', 'upload', TAG, str(source), '--repo', REPO])
        after = [a for a in draft(label + '-after') if a['name'] == expected['name']]
        check(len(after) == 1, 'single remote asset after upload')
        asset = after[0]
        check(asset['size'] == expected['bytes'] and asset['digest'] == 'sha256:' + expected['sha256']
              and asset['state'] == 'uploaded' and type(asset['id']) is int and asset['id'] > 0,
              'remote asset identity')
        check(asset['url'] == f'https://api.github.com/repos/{REPO}/releases/assets/{asset["id"]}',
              'remote asset API origin')
        selected = {key: asset[key] for key in ('id', 'name', 'size', 'digest', 'state', 'url', 'browser_download_url')}
        expected_identity = {key: expected[key] for key in ('bytes', 'sha256')}
        check(report['assets'][label] == dict(selected, downloaded=expected_identity), 'receipt remote/download binding')
        downloaded = record(label + '-download', ['gh', 'api', f'repos/{REPO}/releases/assets/{asset["id"]}',
            '-H', 'Accept: application/octet-stream'])
        check(downloaded == run / 'downloaded' / expected['name'], 'download filename binding')
        check(digest(downloaded) == digest(source) == expected_identity, 'independent downloaded bytes')
        assets.append(selected)
        return downloaded

    reconstructed = hashlib.sha256()
    offset = 0
    for number, part in enumerate(manifest['parts'], 1):
        check(part['number'] == number and part['offset'] == offset
              and part['bytes'] == min(134217728, ARCHIVE['bytes'] - offset), 'part ordering and boundaries')
        path = transfer(f'part-{number:02}', home / 'parts' / part['name'], part)
        with path.open('rb') as source:
            while block := source.read(1024 * 1024):
                reconstructed.update(block)
                offset += len(block)
    check(dict(bytes=offset, sha256=reconstructed.hexdigest()) == ARCHIVE, 'independent ordered whole hash')
    name = manifest['parts'][0]['name'].split('.part-')[0] + '.manifest.json'
    remote_path = run / name
    remote_manifest = json.loads(remote_path.read_text())
    check(remote_manifest == dict(manifest, repository=REPO, release_id=RELEASE, tag=TAG,
        part_assets=[report['assets'][f'part-{n:02}'] for n in range(1, 6)]), 'remote manifest exact binding')
    transfer('manifest', remote_path, dict(name=name, **digest(remote_path)))
    check(report['remote_manifest'] == report['assets']['manifest'], 'terminal manifest asset')
    final = draft('final-draft')
    for asset in assets:
        matches = [row for row in final if row['id'] == asset['id']]
        check(len(matches) == 1 and all(matches[0][key] == value for key, value in asset.items()),
              'final inventory retains exact remote asset')
    check(set(commands) == set(expected_commands) and len(commands) == 64, 'complete exact command set')
    check(len(report['assets']) == 6 and len({a['id'] for a in assets}) == 6, 'six distinct retained assets')
    output = dict(schema='trident/sh7-chunk-transport-review/v1', status='passed',
        completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        command=[sys.executable, *sys.argv], verifier=digest(Path(__file__)),
        transport_receipt=digest(run / 'receipt.json'), reviewed_source=report['source'],
        archive=ARCHIVE, part_manifest=MANIFEST, commands=len(commands), checked_logs=checked_logs,
        preparation_logs=preparation_logs, source_review=digest(home / 'root-review.json'),
        assets=assets, remote_manifest=report['remote_manifest'],
        scope='Rehashes original, local parts, every downloaded asset, restored archive, and all raw logs. '
              'Checks retained server digest and final draft/tag absence. No fresh proof replay or publication.')
    with args.output.open('x') as target:
        json.dump(output, target, indent=2)
        target.write('\n')
    print(json.dumps(dict(status=output['status'], commands=len(commands), assets=len(assets), archive=ARCHIVE)))


if __name__ == '__main__':
    main()

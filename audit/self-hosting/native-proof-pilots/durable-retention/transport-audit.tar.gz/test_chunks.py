import copy
import hashlib
from pathlib import Path
import tempfile
import unittest

import chunks


class ChunkTests(unittest.TestCase):
    def fixture(self, root):
        source = root / 'original.tar.gz'
        data = bytes(range(251)) * 3
        source.write_bytes(data)
        expected = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        manifest = chunks.split(source, root / 'parts', 'fixture-v1', expected, 200)
        return source, expected, manifest

    def test_ordered_uneven_parts_restore_exact_original_without_changing_it(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source, expected, manifest = self.fixture(root)
            self.assertEqual([p['bytes'] for p in manifest['parts']], [200, 200, 200, 153])
            self.assertEqual(chunks.assemble(manifest, root / 'parts', root / 'restored', expected), expected)
            self.assertEqual(source.read_bytes(), (root / 'restored').read_bytes())
            self.assertEqual(chunks.identity(source), expected)
            with self.assertRaises(FileExistsError):
                chunks.assemble(manifest, root / 'parts', root / 'restored', expected)

    def test_missing_reordered_duplicate_or_wrong_length_manifest_rejects(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, expected, good = self.fixture(root)
            variants = []
            value = copy.deepcopy(good); value['parts'].pop(); variants.append(value)
            value = copy.deepcopy(good); value['parts'].reverse(); variants.append(value)
            value = copy.deepcopy(good); value['parts'][1]['name'] = value['parts'][0]['name']; variants.append(value)
            value = copy.deepcopy(good); value['parts'][1]['offset'] -= 1; variants.append(value)
            value = copy.deepcopy(good); value['parts'][1]['bytes'] -= 1; variants.append(value)
            value = copy.deepcopy(good); value['parts'][0]['name'] = '../outside'; variants.append(value)
            value = copy.deepcopy(good); value['archive']['sha256'] = '0' * 64; variants.append(value)
            for value in variants:
                with self.assertRaises(ValueError):
                    chunks.validate(value, expected)

    def test_corrupted_or_missing_download_rejects(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, expected, manifest = self.fixture(root)
            path = root / 'parts' / manifest['parts'][0]['name']
            data = path.read_bytes(); path.write_bytes(bytes([data[0] ^ 1]) + data[1:])
            with self.assertRaises(ValueError):
                chunks.assemble(manifest, root / 'parts', root / 'bad', expected)
            path.unlink()
            with self.assertRaises(FileNotFoundError):
                chunks.assemble(manifest, root / 'parts', root / 'missing', expected)

    def test_wrong_source_hash_prevents_manifest_and_preserves_source(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / 'source'; source.write_bytes(b'actual')
            with self.assertRaises(ValueError):
                chunks.split(source, root / 'parts', 'fixture', {'bytes': 6, 'sha256': '0' * 64}, 4)
            self.assertEqual(source.read_bytes(), b'actual')
            self.assertFalse((root / 'parts/parts.json').exists())

    def test_server_asset_must_bind_origin_name_complete_state_size_and_digest(self):
        expected = {'name': 'part-01', 'bytes': 42, 'sha256': 'a' * 64}
        good = dict(id=7, name=expected['name'], size=42, digest='sha256:' + 'a' * 64,
                    state='uploaded', url='https://api.github.com/repos/cyberia-to/trisha/releases/assets/7',
                    browser_download_url='https://github.com/cyberia-to/trisha/releases/download/draft/part-01')
        self.assertEqual(chunks.asset_identity(good, expected)['id'], 7)
        for key, value in [('id', 8), ('name', 'wrong'), ('size', 41), ('digest', None),
                           ('state', 'starter'), ('url', 'https://example.invalid/7')]:
            with self.assertRaises(ValueError):
                chunks.asset_identity(dict(good, **{key: value}), expected)


if __name__ == '__main__':
    unittest.main()

"""Retain transport sources and raw receipts without duplicating remote payloads."""
import datetime
import hashlib
import json
from pathlib import Path
import tarfile


def identity(path):
    with path.open('rb') as source:
        value = hashlib.file_digest(source, 'sha256').hexdigest()
    return dict(bytes=path.stat().st_size, sha256=value)


def main():
    home = Path(__file__).resolve().parent
    receipt = json.loads((home / 'run-1/receipt.json').read_text())
    review = json.loads((home / 'final-review.json').read_text())
    if receipt['status'] != 'passed' or review['status'] != 'passed':
        raise ValueError('successful final transport and independent review required')
    selected = [p for p in home.iterdir() if p.is_file() and p.suffix in ('.py', '.json', '.md', '.stdout', '.stderr', '.txt')]
    selected += [home / 'parts/parts.json', home / 'run-1/receipt.json']
    for directory in ('original-before', 'original-after', 'monitor', 'run-1/logs'):
        selected += [p for p in (home / directory).rglob('*') if p.is_file()]
    selected += list((home / 'run-1').glob('*.manifest.json'))
    selected += list((home / 'run-1/downloaded').glob('*.manifest.json'))
    files = {str(p.relative_to(home)): identity(p) for p in sorted(set(selected))}
    output = home / 'audit-package'
    output.mkdir()
    archive = output / 'sh7-chunk-transport-audit.tar.gz'
    with tarfile.open(archive, 'x:gz') as target:
        for name in files:
            target.add(home / name, arcname=name, recursive=False)
    with tarfile.open(archive, 'r:gz') as source:
        members = source.getmembers()
        if len(members) != len(files) or {m.name for m in members} != set(files):
            raise ValueError('archive membership differs')
        for member in members:
            stream = source.extractfile(member)
            if stream is None:
                raise ValueError('missing archived regular file')
            value = dict(bytes=member.size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())
            if value != files[member.name]:
                raise ValueError('archived member differs: ' + member.name)
    manifest = dict(schema='trident/sh7-chunk-transport-audit-package/v1', status='passed',
        completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        command=['python3', '-B', str(Path(__file__))], archive=dict(name=archive.name, **identity(archive)),
        files=files, omitted_payloads=dict(reason='Exact original, local split parts and independent downloads remain '
        'locally retained; remote manifest binds each part and complete archive. They are not duplicated in this small audit package.',
        original_archive=receipt['archive'], remote_manifest=receipt['remote_manifest']),
        scope='Source and raw transport audit retention only; no proof result, source or remote asset changes.')
    with (output / 'manifest.json').open('x') as destination:
        json.dump(manifest, destination, indent=2)
        destination.write('\n')
    print(json.dumps(dict(status='passed', files=len(files), archive=manifest['archive'])))


if __name__ == '__main__':
    main()

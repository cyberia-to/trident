"""Upload exact SH7 parts to the existing draft and independently restore them."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import json
from pathlib import Path
import subprocess
import sys
import threading
import time
import traceback

from chunks import (EXPECTED, PART_BYTES, RELEASE, REPOSITORY, TAG, assemble,
                    asset_identity, identity, require, validate)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parts', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    manifest_path = args.parts / 'parts.json'
    manifest = json.loads(manifest_path.read_text())
    validate(manifest, EXPECTED)
    require(manifest['part_bytes'] == PART_BYTES, '128 MiB parts required')
    for part in manifest['parts']:
        require(identity(args.parts / part['name']) == {k: part[k] for k in ('bytes', 'sha256')}, 'local part changed')
    args.output.mkdir()
    logs = args.output / 'logs'
    logs.mkdir()
    downloads = args.output / 'downloaded'
    downloads.mkdir()
    lock = threading.RLock()
    stop_uploads = threading.Event()
    report = dict(schema='trident/sh7-chunk-transport/v1', status='running',
        command=[sys.executable, *sys.argv], started_utc=now(), repository=REPOSITORY,
        release_id=RELEASE, tag=TAG, archive=EXPECTED, part_manifest=identity(manifest_path),
        source={name: identity(Path(__file__).with_name(name)) for name in ('transport.py', 'chunks.py')},
        upload_workers=4, upload_wall_seconds=7200,
        scope='Evidence transport only; proof caps unchanged; no tag, publication, overwrite or deletion.',
        commands=[], assets={}, failures=[])

    def save():
        with lock:
            temporary = args.output / 'receipt.pending.json'
            temporary.write_text(json.dumps(report, indent=2) + '\n')
            temporary.replace(args.output / 'receipt.json')

    def run(name, argv, expected_exit=0, binary_output=None):
        with lock:
            require(all(row['name'] != name for row in report['commands']), 'duplicate command name')
            row = dict(name=name, argv=list(map(str, argv)), started_utc=now(), wall_seconds=7200)
            report['commands'].append(row)
            save()
        stdout = binary_output or logs / (name + '.stdout')
        stderr = logs / (name + '.stderr')
        started = time.monotonic_ns()
        failure = None
        try:
            with stdout.open('xb') as out, stderr.open('xb') as err:
                process = subprocess.Popen(row['argv'], stdout=out, stderr=err)
                with lock:
                    row['pid'] = process.pid
                    save()
                try:
                    code = process.wait(timeout=7200)
                except subprocess.TimeoutExpired:
                    process.kill()
                    code = process.wait()
                    failure = 'transport wall deadline exceeded'
        except BaseException:
            failure = traceback.format_exc()
            code = None
        with lock:
            row.update(exit_code=code, ended_utc=now(), elapsed_ns=time.monotonic_ns() - started)
            for channel, path in [('stdout', stdout), ('stderr', stderr)]:
                if path.is_file():
                    row[channel] = dict(path=str(path.relative_to(args.output)), **identity(path))
            if failure:
                row['error'] = failure
            save()
        print(name, code, flush=True)
        require(not failure and code == expected_exit, 'command failed: ' + name)
        return stdout

    def draft(name):
        release = json.loads(run(name, ['gh', 'api', f'repos/{REPOSITORY}/releases/{RELEASE}']).read_text())
        require(release['id'] == RELEASE and release['draft'] and release['published_at'] is None
                and release['tag_name'] == TAG, 'exact unpublished draft required')
        absent = json.loads(run(name + '-tag', ['gh', 'api', f'repos/{REPOSITORY}/git/ref/tags/{TAG}'], 1).read_text())
        require(str(absent.get('status')) == '404', 'tag must remain absent')
        selected = json.loads(run(name + '-selected', ['gh', 'release', 'view', TAG, '--repo', REPOSITORY,
            '--json', 'databaseId,isDraft,tagName,publishedAt']).read_text())
        require(selected['databaseId'] == RELEASE and selected['isDraft'] and selected['tagName'] == TAG
                and selected['publishedAt'] is None, 'upload command resolves a different release')
        pages = json.loads(run(name + '-assets', ['gh', 'api', '--paginate', '--slurp',
            f'repos/{REPOSITORY}/releases/{RELEASE}/assets?per_page=100']).read_text())
        require(isinstance(pages, list) and all(isinstance(page, list) for page in pages), 'asset inventory shape')
        return [asset for page in pages for asset in page]

    def transfer(label, path, expected):
        require(not stop_uploads.is_set(), 'another part failed; new upload refused')
        require(identity(path) == {k: expected[k] for k in ('bytes', 'sha256')}, 'upload file changed')
        before = draft(label + '-before')
        require(not any(asset['name'] == expected['name'] for asset in before), 'asset name already exists')
        require(not stop_uploads.is_set(), 'another part failed; new upload refused')
        run(label + '-upload', ['gh', 'release', 'upload', TAG, path, '--repo', REPOSITORY])
        after = draft(label + '-after')
        matches = [asset for asset in after if asset['name'] == expected['name']]
        require(len(matches) == 1, 'exactly one uploaded asset required')
        asset = asset_identity(matches[0], expected)
        with lock:
            report['assets'][label] = asset
            save()
        destination = downloads / expected['name']
        run(label + '-download', ['gh', 'api', f'repos/{REPOSITORY}/releases/assets/{asset["id"]}',
            '-H', 'Accept: application/octet-stream'], binary_output=destination)
        require(identity(destination) == {k: expected[k] for k in ('bytes', 'sha256')}, 'download differs from part')
        require(identity(path) == {k: expected[k] for k in ('bytes', 'sha256')}, 'local part changed during transport')
        with lock:
            report['assets'][label]['downloaded'] = identity(destination)
            save()
        return asset

    save()
    try:
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = {pool.submit(transfer, f'part-{part["number"]:02}', args.parts / part['name'], part): part
                       for part in manifest['parts']}
            for future in as_completed(futures):
                try:
                    future.result()
                except BaseException:
                    stop_uploads.set()
                    with lock:
                        report['failures'].append(dict(part=futures[future]['number'], error=traceback.format_exc()))
                        save()
        require(not report['failures'], 'one or more part transports failed; all records/assets preserved')
        restored = args.output / manifest['archive']['name']
        report['reassembled'] = assemble(manifest, downloads, restored)
        require(identity(manifest_path) == report['part_manifest'], 'immutable local manifest changed')
        filename = manifest['parts'][0]['name'].split('.part-', 1)[0] + '.manifest.json'
        final_manifest = dict(manifest, repository=REPOSITORY, release_id=RELEASE, tag=TAG,
            part_assets=[report['assets'][f'part-{part["number"]:02}'] for part in manifest['parts']])
        publication = args.output / filename
        with publication.open('x') as output:
            json.dump(final_manifest, output, indent=2)
            output.write('\n')
        transfer('manifest', publication, dict(name=filename, **identity(publication)))
        draft('final-draft')
        for command in report['commands']:
            for channel in ('stdout', 'stderr'):
                record = command[channel]
                require(identity(args.output / record['path']) == {k: record[k] for k in ('bytes', 'sha256')},
                        'retained command log changed')
        report.update(status='passed', completed_utc=now(), remote_manifest=report['assets']['manifest'])
    except BaseException:
        report.update(status='failed', error=traceback.format_exc())
        raise
    finally:
        save()
    print(json.dumps(dict(status=report['status'], archive=report['reassembled'], manifest=report['remote_manifest'])))


if __name__ == '__main__':
    main()

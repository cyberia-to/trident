"""Freeze ordered parts of the already reviewed archive before network writes."""
import datetime
import json
from pathlib import Path
import sys
import time

from chunks import EXPECTED, PART_BYTES, identity, require, split

root = Path(__file__).resolve().parent
source = root.parent / 'sh7-retention/sh7-native-c2-complete-evidence-20261002.tar.gz'
prefix = 'sh7-fa0f99785b4f-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
started = time.monotonic_ns()
manifest = split(source, root / 'parts', prefix)
require(identity(source) == EXPECTED, 'original archive changed')
receipt = dict(schema='trident/sh7-chunk-preparation/v1', status='passed',
    command=[sys.executable, *sys.argv], source=str(source), source_identity=EXPECTED,
    part_bytes=PART_BYTES, parts=manifest['parts'], manifest=identity(root / 'parts/parts.json'),
    elapsed_ns=time.monotonic_ns() - started,
    checker={name: identity(root / name) for name in ('prepare.py', 'chunks.py')})
with (root / 'preparation.json').open('x') as output:
    json.dump(receipt, output, indent=2)
    output.write('\n')
print(json.dumps(dict(status=receipt['status'], parts=len(manifest['parts']), manifest=receipt['manifest'])))

"""Changed expected compiler/source/dependency/options/JOB inputs, without execution."""
import copy
import json
from pathlib import Path
import subprocess
from prepare import identity, document, save

HERE = Path(__file__).resolve().parent
R2 = HERE.parent
JOY = R2 / 'transport-install/installed/bin/joy'
FLAGS = ['--budget', '100000000', '--arena-nodes', '100000000', '--frames', '65536',
         '--artifact-bytes', '16777216', '--artifact-nodes', '196608', '--artifact-depth', '4096',
         '--validation-visits', '16777216', '--resident-nodes', '3145728',
         '--collection-work', '1000000000', '--time-ms', '300000']


def compiler_coordinates(path):
    raw = path.read_bytes()
    assert raw[:8] == b'NOXDAG01'
    nodes = {}
    cursor = 44
    for _ in range(int.from_bytes(raw[40:44], 'little')):
        particle = raw[cursor:cursor+32]
        length = raw[cursor+32]
        body = raw[cursor+33:cursor+33+length]
        assert length in [8, 64] and len(body) == length
        nodes[particle] = int.from_bytes(body, 'little') if length == 8 else (body[:32], body[32:])
        cursor += 33 + length
    assert cursor == len(raw)
    fields = []
    rest = raw[8:40]
    for _ in range(5):
        head, rest = nodes[rest]
        fields.append(head)
    assert nodes[rest] == 0 and [nodes[p] for p in fields[:4]] == [0x41525431, 0, 1, 1]
    return {'program_particle': raw[8:40].hex(), 'formula_particle': fields[4].hex()}


def main():
    c1 = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap/measurements/bootstrap-prepare/repeat-1/c1.dag')
    save(HERE / 'inputs/different-compiler.dag', c1.read_bytes())
    report = {'scope': 'Admitted external expectations for negative checks against the aggregate pilot certificate; no compiler execution',
              'compilers': {'actual': {**identity(HERE/'inputs/compiler.dag'), **compiler_coordinates(HERE/'inputs/compiler.dag')},
                            'different': {'origin': str(c1), **identity(c1), **compiler_coordinates(c1)}}, 'variants': {}}
    original = HERE / 'cases/aggregate'
    manifest = json.loads((original / 'package.json').read_text())
    for mode in ['source', 'dependency', 'options', 'job-limit', 'compiler']:
        directory = HERE / 'negatives' / mode
        changed = copy.deepcopy(manifest)
        for module in changed['modules']:
            source = (original / module['file']).read_text()
            if mode == 'source' and module['logical_path'] == 'sample':
                assert 'values.Item{y:9,x:7}' in source
                source = source.replace('values.Item{y:9,x:7}', 'values.Item{y:8,x:7}', 1)
            if mode == 'dependency' and module['logical_path'] == 'bank.values':
                assert 'pub fn echo(x:Item)->Item{x}' in source
                source = source.replace('pub fn echo(x:Item)->Item{x}', 'pub fn echo(x:Item)->Item{Item{x:x.x+1,y:x.y}}', 1)
            save(directory / module['file'], source.encode())
        if mode == 'options': changed['options']['cfg_flags'] = ['pilot_changed']
        if mode == 'job-limit': changed['limits']['reductions'] -= 1
        document(directory / 'package.json', changed)
        compiler = HERE / 'inputs' / ('different-compiler.dag' if mode == 'compiler' else 'compiler.dag')
        argv = ['python3', str(HERE/'run.py'), '--source-receipt', str(R2/'transport-install/postinstall/receipt.json'),
                'pack-negative-'+mode, '--', str(JOY), 'pack-job', '--compiler', str(compiler),
                '--manifest', str(directory/'package.json'), '--output', str(directory/'job.dag'), *FLAGS]
        subprocess.run(argv, check=True)
        packed = json.loads((HERE/'attempts'/('pack-negative-'+mode)/'stdout').read_text())['package']
        report['variants'][mode] = {'manifest': identity(directory/'package.json'), 'job': identity(directory/'job.dag'),
                                    'sources': {m['logical_path']: identity(directory/m['file']) for m in changed['modules']},
                                    'admission': packed}
    document(HERE/'negative-inputs.json', report)
    print(json.dumps({mode: row['job'] for mode,row in report['variants'].items()}))


if __name__ == '__main__':
    main()

"""Bind independently codec-valid changed outputs to the actual-C2 pilot proof."""
import json
from pathlib import Path
from attacks import guarded, verify, PROOF
from prepare import document, identity

HERE = Path(__file__).resolve().parent
HELPER = HERE / "target-mutator/release/compiler-pilot-valid-output-mutator"
BUILD = HERE / "valid-output-mutator/build/receipt.json"


def main():
    modes = ["copy", "valid-output-payload", "valid-output-topology",
             "valid-output-payload-rebound", "valid-output-topology-rebound"]
    results = []
    for mode in modes:
        name = "valid-output-control" if mode == "copy" else mode
        proof = HERE / "mutated" / (name + ".proof")
        guarded("mutate-" + name, HELPER, [PROOF, proof, mode], install=BUILD)
        if mode == "copy":
            assert proof.read_bytes() == PROOF.read_bytes()
            result = verify(name, proof, expect=0)
        else:
            error = "semantic terminal: Claim" if mode.endswith("rebound") else "certificate result identity mismatch"
            result = verify(name, proof, error=error)
            noun = Path(str(proof) + ".dag")
            raw = noun.read_bytes()
            assert raw[:8] == b"NOXDAG01"
            original = json.loads((HERE / "attempts/prove-aggregate-1/stdout").read_text())["verification"]["output_particle"]
            assert raw[8:40].hex() != original
            result.update(valid_regenerated_noun=identity(noun),
                          regenerated_root=raw[8:40].hex(), original_checked_root=original,
                          standalone_codec_validation="helper decodes original; constructs altered reachable DAG; encodes and fresh-decodes/encodes to identical canonical bytes; no evaluator calls",
                          terminal_particle_rebound=mode.endswith("rebound"))
        results.append(result)
    report = {"schema": "joy/actual-compiler-valid-output-attacks/v1",
              "scope": "Actual complete C2 aggregate proof, fully rebuilt public transport chains and codec-valid regenerated NOXDAG output",
              "controls": 1, "rejected": 4, "results": results,
              "source_revisions": json.loads((HERE / "production-source/inputs.json").read_text()),
              "helper_build_receipt": identity(BUILD), "driver": identity(Path(__file__))}
    document(HERE / "adversarial-valid-output-results.json", report)
    print(json.dumps({"controls": 1, "rejected": 4}))


if __name__ == "__main__":
    main()

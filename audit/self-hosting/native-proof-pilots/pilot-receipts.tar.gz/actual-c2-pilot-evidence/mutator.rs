//! Actual-certificate adversarial generator; never evaluates a noun formula.
use joy_rs::structured::certificate::transport::{Limits, Reader, Writer};
use std::{
    env,
    fs::{File, OpenOptions},
    io::{self, Read, Seek, SeekFrom, Write},
};

fn bad(message: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message)
}
fn exact<const N: usize>(input: &mut impl Read) -> io::Result<[u8; N]> {
    let mut bytes = [0; N];
    input.read_exact(&mut bytes)?;
    Ok(bytes)
}
fn hex<const N: usize>(value: &str) -> io::Result<[u8; N]> {
    if value.len() != N * 2 {
        return Err(bad("hex length"));
    }
    let mut out = [0; N];
    for (i, b) in out.iter_mut().enumerate() {
        *b = u8::from_str_radix(&value[2 * i..2 * i + 2], 16).map_err(|_| bad("hex"))?;
    }
    Ok(out)
}
fn context(args: &[String]) -> io::Result<[u8; 32]> {
    if args.len() != 6 {
        return Err(bad("context: program formula input profile budget frames"));
    }
    let mut h = hemera::Hasher::new();
    h.update(b"joy/nox/disclosed-compiler/v1\0");
    for arg in &args[..3] {
        h.update(&hex::<32>(arg)?);
    }
    h.update(&[args[3].parse::<u8>().map_err(|_| bad("profile"))?]);
    h.update(
        &args[4]
            .parse::<u64>()
            .map_err(|_| bad("budget"))?
            .to_le_bytes(),
    );
    h.update(
        &args[5]
            .parse::<u32>()
            .map_err(|_| bad("frames"))?
            .to_le_bytes(),
    );
    Ok(*h.finalize().as_bytes())
}

fn mutate_output(output: &mut [u8], topology: bool) -> io::Result<()> {
    if output.len() < 44 || &output[..8] != b"NOXDAG01" {
        return Err(bad("output framing"));
    }
    let count = u32::from_le_bytes(output[40..44].try_into().map_err(|_| bad("count"))?);
    let mut cursor = 44usize;
    let mut changed = false;
    for _ in 0..count {
        let length = *output
            .get(cursor + 32)
            .ok_or_else(|| bad("record length"))? as usize;
        let end = cursor
            .checked_add(33 + length)
            .ok_or_else(|| bad("overflow"))?;
        let body = output
            .get_mut(cursor + 33..end)
            .ok_or_else(|| bad("record body"))?;
        if !changed
            && ((!topology && length == 8)
                || (topology && length == 64 && body[..32] != body[32..]))
        {
            if topology {
                let (left, right) = body.split_at_mut(32);
                left.swap_with_slice(right);
            } else {
                body[0] ^= 1;
            }
            changed = true;
        }
        cursor = end;
    }
    if cursor != output.len() || !changed {
        return Err(bad("missing output mutation"));
    }
    Ok(())
}

fn main() -> io::Result<()> {
    let args: Vec<_> = env::args().collect();
    if args.len() < 4 {
        return Err(bad("INPUT OUTPUT MODE [context coordinates]"));
    }
    let mode = args[3].as_str();
    let mut input = File::open(&args[1])?;
    if input.metadata()?.len() > 1 << 30 {
        return Err(bad("input file cap"));
    }
    let header = exact::<40>(&mut input)?;
    if &header[..8] != b"JOYSC001" {
        return Err(bad("magic"));
    }
    let old_context = header[8..40].try_into().map_err(|_| bad("context bytes"))?;
    let new_context = if mode == "rebind" {
        context(&args[4..])?
    } else {
        old_context
    };
    input.seek(SeekFrom::Start(0))?;
    let limits = Limits {
        wire_bytes: 1 << 30,
        decoded_bytes: 2 << 30,
        frames: (2 << 30) + 1,
    };
    let mut reader = Reader::new(input, old_context, limits)?;
    let output = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&args[2])?;
    let mut writer = Writer::new(output, new_context, limits)?;
    let mut changed = mode == "rebind" || mode == "copy";
    let mut enters = 0u64;
    let mut count = 0u64;
    loop {
        count = count
            .checked_add(1)
            .filter(|c| *c <= 100_000_000)
            .ok_or_else(|| bad("record cap"))?;
        let tag = exact::<1>(&mut reader)?[0];
        if tag == 6 {
            let mut terminal = exact::<44>(&mut reader)?;
            let length = u32::from_le_bytes(
                terminal[40..44]
                    .try_into()
                    .map_err(|_| bad("result length"))?,
            ) as usize;
            if length == 0 || length > 16_777_216 {
                return Err(bad("result cap"));
            }
            let mut result = Vec::new();
            result
                .try_reserve_exact(length)
                .map_err(|_| bad("result allocation"))?;
            result.resize(length, 0);
            reader.read_exact(&mut result)?;
            match mode {
                "cost" => {
                    let cost =
                        u64::from_le_bytes(terminal[32..40].try_into().map_err(|_| bad("cost"))?);
                    terminal[32..40].copy_from_slice(
                        &cost
                            .checked_add(1)
                            .ok_or_else(|| bad("cost overflow"))?
                            .to_le_bytes(),
                    );
                    changed = true;
                }
                "output-payload" | "output-topology" => {
                    mutate_output(&mut result, mode == "output-topology")?;
                    changed = true;
                }
                "omit-terminal" => changed = true,
                _ => (),
            }
            if mode != "omit-terminal" {
                writer.write_all(&[tag])?;
                writer.write_all(&terminal)?;
                writer.write_all(&result)?;
            }
            break;
        }
        let len = match tag {
            0 | 1 | 3 | 4 => 8,
            2 | 5 => 12,
            _ => return Err(bad("record tag")),
        };
        let mut record = [0u8; 12];
        reader.read_exact(&mut record[..len])?;
        if tag == 3 {
            enters += 1;
            if !changed && mode == "continuation" && enters > 1 && record[..4] != record[4..8] {
                let object: [u8; 4] = record[..4].try_into().map_err(|_| bad("object"))?;
                record[4..8].copy_from_slice(&object);
                changed = true;
            }
        }
        if !changed && tag == 5 && mode == "generation" {
            record[4] ^= 1;
            changed = true;
        }
        writer.write_all(&[tag])?;
        writer.write_all(&record[..len])?;
    }
    reader.finish()?;
    if !changed {
        return Err(bad("requested mutation was not applied"));
    }
    let (output, stats) = writer.finish()?;
    output.sync_all()?;
    println!("{{\"mode\":\"{mode}\",\"records\":{count},\"enters\":{enters},\"wire_bytes\":{},\"decoded_bytes\":{}}}", stats.wire_bytes, stats.decoded_bytes);
    Ok(())
}

"""Retain one isolated command with explicit wall, sampled RSS and disk guards."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20):
            digest.update(block)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def rss_tree(pid):
    raw = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,rss='], text=True)
    rows = [tuple(map(int, line.split())) for line in raw.splitlines()]
    selected = {pid}
    while True:
        following = selected | {child for child, parent, _ in rows if parent in selected}
        if following == selected:
            break
        selected = following
    processes = [dict(pid=p, ppid=pp, rss_kib=r) for p, pp, r in rows if p in selected]
    return dict(time_ns=time.time_ns(), processes=processes,
                tree_rss_kib=sum(p['rss_kib'] for p in processes))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    parser.add_argument('--seconds', type=int, default=330)
    parser.add_argument('--rss-mib', type=int, default=3072)
    parser.add_argument('--disk-mib', type=int, default=2048)
    parser.add_argument('--source-receipt', type=Path)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    argv = args.command[1:] if args.command[:1] == ['--'] else args.command
    if not argv or not Path(argv[0]).is_absolute() or Path(args.name).name != args.name:
        parser.error('require a single attempt name and absolute executable')
    directory = HERE / 'attempts' / args.name
    directory.mkdir(parents=True, exist_ok=False)
    disk_cap = args.disk_mib << 20
    env = dict(os.environ, PATH=str(HERE / 'empty-path'))
    report = dict(schema='joy/actual-compiler-pilot-command/v1', status='prepared',
                  argv=argv, cwd=str(directory), environment={'PATH': env['PATH']},
                  guards=dict(wall_seconds=args.seconds, sampled_rss_kib=args.rss_mib << 10,
                              total_attempt_bytes=disk_cap, per_file_bytes=disk_cap,
                              sample_interval_seconds=1),
                  binary=dict(path=argv[0], **identity(Path(argv[0]))),
                  driver=identity(Path(__file__)), started_ns=time.time_ns(),
                  inputs_manifest=identity(HERE / 'inputs.json'), sampled_peak_tree_rss_kib=0)
    if args.source_receipt:
        source = args.source_receipt.resolve()
        (directory / 'source-receipt.json').write_bytes(source.read_bytes())
        report['source_receipt'] = dict(path=str(source), **identity(source))
    argument_files = [Path(arg) for arg in argv[1:]
                      if Path(arg).is_absolute() and Path(arg).is_file()]
    report['argument_files_start'] = {str(path): identity(path) for path in argument_files}
    expected_inputs = json.loads((HERE / 'inputs.json').read_text())
    closure = {str(HERE / 'inputs/compiler.dag'): identity(HERE / 'inputs/compiler.dag')}
    assert closure[str(HERE / 'inputs/compiler.dag')] == {
        k: expected_inputs['compiler'][k] for k in ['bytes', 'sha256']}
    for case, row in expected_inputs['cases'].items():
        for source in row['source_files'].values():
            path = HERE / 'cases' / case / source['file']
            closure[str(path)] = identity(path)
            assert closure[str(path)] == {k: source[k] for k in ['bytes', 'sha256']}
    report['pilot_sources_start'] = closure
    receipt = directory / 'receipt.json'

    def save():
        receipt.write_text(json.dumps(report, indent=2) + '\n')

    def file_cap():
        resource.setrlimit(resource.RLIMIT_FSIZE, (disk_cap, disk_cap))

    started = time.monotonic()
    child = None
    try:
        with (directory / 'stdout').open('xb') as out, (directory / 'stderr').open('xb') as err, (directory / 'rss.jsonl').open('x') as samples:
            child = subprocess.Popen(argv, cwd=directory, env=env, stdout=out, stderr=err,
                                     start_new_session=True, preexec_fn=file_cap)
            report.update(status='running', pid=child.pid)
            save()
            print(json.dumps({'status': 'running', 'pid': child.pid, 'receipt': str(receipt)}), flush=True)
            while child.poll() is None:
                sample = rss_tree(child.pid)
                samples.write(json.dumps(sample) + '\n')
                samples.flush()
                report['sampled_peak_tree_rss_kib'] = max(report['sampled_peak_tree_rss_kib'], sample['tree_rss_kib'])
                elapsed = time.monotonic() - started
                disk = sum(p.stat().st_size for p in directory.iterdir() if p.is_file())
                guard = 'wall' if elapsed > args.seconds else 'rss' if sample['tree_rss_kib'] > args.rss_mib << 10 else 'disk' if disk > disk_cap else None
                report.update(elapsed_seconds=elapsed, sampled_attempt_bytes=disk)
                if guard:
                    report['guard_triggered'] = guard
                    os.killpg(child.pid, signal.SIGKILL)
                    break
                save()
                try:
                    child.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass
            report.update(exit_code=child.wait(), elapsed_seconds=time.monotonic() - started)
            report['status'] = 'guard-killed' if 'guard_triggered' in report else 'passed' if report['exit_code'] == 0 else 'rejected'
    except BaseException as error:
        if child and child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()
        report.update(status='driver-failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        report.update(ended_ns=time.time_ns(), binary_end=identity(Path(argv[0])))
        report['argument_files_end'] = {str(path): identity(path) for path in argument_files}
        report['pilot_sources_end'] = {path: identity(Path(path)) for path in closure}
        report['files'] = {p.name: identity(p) for p in directory.iterdir() if p.is_file() and p != receipt}
        if report['binary_end'] != {k: report['binary'][k] for k in ['bytes', 'sha256']}:
            report['status'] = 'binary-changed'
        if report['argument_files_start'] != report['argument_files_end'] or closure != report['pilot_sources_end']:
            report['status'] = 'inputs-changed'
        save()
        print(json.dumps({k: report.get(k) for k in ['status', 'exit_code', 'elapsed_seconds', 'sampled_peak_tree_rss_kib', 'guard_triggered']}), flush=True)
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())

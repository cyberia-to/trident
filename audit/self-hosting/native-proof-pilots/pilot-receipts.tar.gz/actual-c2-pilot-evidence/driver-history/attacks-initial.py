"""Rebuild valid transport chains around actual-C2 semantic mutations."""
import json
from pathlib import Path
import subprocess
import sys
from prepare import identity, document
from cases import FLAGS, INSTALL, JOY

HERE = Path(__file__).resolve().parent
MUTATOR = HERE/'target-mutator/release/compiler-pilot-mutator'
PROOF = HERE/'attempts/prove-aggregate-1/proof.joysc'
COMPILER = HERE/'inputs/compiler.dag'
JOB = HERE/'cases/aggregate/job.dag'


def guarded(name, binary, args, expect=0, install=None):
    args = list(map(str,args))
    receipt = install or INSTALL/'postinstall/receipt.json'
    command=[sys.executable,str(HERE/'run.py'),'--source-receipt',str(receipt),name,'--',str(binary),*args]
    result=subprocess.run(command)
    report=json.loads((HERE/'attempts'/name/'receipt.json').read_text())
    assert report['exit_code']==expect and report['status']==('passed' if expect==0 else 'rejected'),report
    assert result.returncode==(0 if expect==0 else 1)
    return report


def mutate(mode, name, coordinates=()):
    dest=HERE/'mutated'/name
    guarded('mutate-'+name,MUTATOR,[PROOF,dest,mode,*coordinates],install=HERE/'mutator-build/receipt.json')
    return dest


def verify(name, proof, compiler=COMPILER, job=JOB, expect=1, error=None):
    protected=HERE/'protected'/name
    protected.write_bytes(b'previous complete artifact\n')
    report=guarded('attack-'+name,JOY,['verify-artifact',compiler,'--input',job,'--proof',proof,
                                    '--output',protected,'--force',*FLAGS],expect)
    stdout=(HERE/'attempts'/('attack-'+name)/'stdout').read_text()
    stderr=(HERE/'attempts'/('attack-'+name)/'stderr').read_text()
    if expect:
        assert not stdout and error in stderr,(name,stderr)
        assert protected.read_bytes()==b'previous complete artifact\n'
    else:
        checked=json.loads(stdout)['verification']
        actual=json.loads((HERE/'attempts/prove-aggregate-1/stdout').read_text())['verification']
        for key in ['program_particle','input_particle','output_particle','charged_reductions','records','transport','compiler_job']:
            assert checked[key]==actual[key],key
    return {'name':name,'expected_exit':expect,'actual_exit':report['exit_code'],'stderr':stderr,
            'proof':identity(proof),'expected_program':identity(compiler),'expected_input':identity(job),
            'destination_preserved':expect==1,'receipt':'attempts/attack-'+name+'/receipt.json'}


def main():
    (HERE/'mutated').mkdir();(HERE/'protected').mkdir()
    negatives=json.loads((HERE/'negative-inputs.json').read_text())
    actual=negatives['compilers']['actual']
    pack=json.loads((HERE/'attempts/pack-aggregate/stdout').read_text())['package']
    original=[actual['program_particle'],actual['formula_particle'],pack['job_particle'],'1','100000000','65536']
    results=[]
    for mode in ['copy','rebind']:
        dest=mutate(mode,'control-'+mode+'.proof',original if mode=='rebind' else ())
        assert dest.read_bytes()==PROOF.read_bytes()
        results.append(verify('control-'+mode,dest,expect=0))
    for mode,row in negatives['variants'].items():
        compiler=HERE/'inputs/different-compiler.dag' if mode=='compiler' else COMPILER
        job=HERE/'negatives'/mode/'job.dag'
        results.append(verify('expected-'+mode,PROOF,compiler,job,error='format/context mismatch'))
        coords=negatives['compilers']['different' if mode=='compiler' else 'actual']
        rebound=mutate('rebind','rebound-'+mode+'.proof',[coords['program_particle'],coords['formula_particle'],
                      row['admission']['job_particle'],'1',str(row['admission']['limits']['reductions']),'65536'])
        results.append(verify('rebound-'+mode,rebound,compiler,job,error='semantic record: Key'))
    for mode, error in [('continuation','semantic record: Key'),('generation','semantic record:'),
                        ('cost','semantic terminal:'),('output-payload','HashMismatch'),
                        ('output-topology','HashMismatch'),('omit-terminal','failed to fill whole buffer')]:
        dest=mutate(mode,mode+'.proof')
        results.append(verify(mode,dest,error=error))
    assert PROOF.stat().st_size<16<<20
    raw=PROOF.read_bytes()
    def end(start):
        length=int.from_bytes(raw[start+14:start+18],'little')
        assert length<=65536
        return start+82+length
    a=end(40);b=end(a)
    changes={'drop-frame':raw[:40]+raw[a:],'swap-frames':raw[:40]+raw[a:b]+raw[40:a]+raw[b:],
             'trailing-byte':raw+b'\0','truncated':raw[:-1]}
    for mode,bytes_ in changes.items():
        dest=HERE/'mutated'/(mode+'.proof');dest.write_bytes(bytes_)
        error='order/chain mismatch' if mode in ['drop-frame','swap-frames'] else 'trailing bytes' if mode=='trailing-byte' else 'failed to fill whole buffer'
        results.append(verify(mode,dest,error=error))
    document(HERE/'adversarial-results.json',{'schema':'joy/actual-compiler-adversarial/v1',
             'scope':'Actual full frozen-C2 aggregate proof; fresh installed verifier for every case; public transport chain reconstruction for semantic mutations',
             'control_byte_equality':True,'controls':sum(r['expected_exit']==0 for r in results),
             'rejected':sum(r['expected_exit']==1 for r in results),'results':results})
    print(json.dumps({'controls':sum(r['expected_exit']==0 for r in results),'rejected':sum(r['expected_exit']==1 for r in results)}))


if __name__=='__main__':main()

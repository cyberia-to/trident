"""Assemble immutable small audit inputs and index retained large proof files."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "audit-package-v2"


def identity(path):
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"bytes": path.stat().st_size, "sha256": digest}


def read(path):
    return json.loads((ROOT / path).read_text())


def main():
    OUT.mkdir(exist_ok=False)
    sources = read("production-source/inputs.json")
    specs = [
        ("loop", "prove-loop-1", "verify-loop-result-1", "loop-comparison.json"),
        ("aggregate", "prove-aggregate-1", "verify-aggregate-result-1", "aggregate-comparison.json"),
        ("compile-error", "prove-compile-error-1", "verify-compile-error-result-1", "compile-error-comparison.json"),
        ("scale-baseline", "prove-scale-baseline-1", "verify-scale-baseline-result-1", "scale-baseline-comparison.json"),
        ("scale-valid65536", "prove-scale-valid65536-1", "verify-scale-valid65536-result-1", "scale-valid65536-comparison.json"),
    ]
    pilots = []
    for name, prove, verify, comparison in specs:
        pr = read(f"attempts/{prove}/receipt.json")
        vr = read(f"attempts/{verify}/receipt.json")
        assert pr["status"] == vr["status"] == "passed"
        pv = read(f"attempts/{prove}/stdout")["verification"]
        vv = read(f"attempts/{verify}/stdout")["verification"]
        keys = ["program_particle", "input_particle", "output_particle", "charged_reductions",
                "invocations", "expanded_steps", "logical_peak_frames", "semantic_events",
                "records", "transport", "compiler_job", "format", "disclosure", "physical_resource_claim"]
        assert all(pv[k] == vv[k] for k in keys)
        assert "prover_observations" not in vv
        actual_proof = identity(ROOT / "attempts" / prove / "proof.joysc")
        assert actual_proof == pr["files"]["proof.joysc"]
        assert actual_proof["bytes"] == pv["transport"]["wire_bytes"]
        pilots.append({"name": name, "prover_receipt": f"attempts/{prove}/receipt.json",
                       "verifier_receipt": f"attempts/{verify}/receipt.json", "comparison": comparison,
                       "proof": {"external_path": str(ROOT / "attempts" / prove / "proof.joysc"), **actual_proof},
                       "verified": {k: pv[k] for k in keys},
                       "prover_host_observations": pv["prover_observations"],
                       "prove_wall_seconds": pr["elapsed_seconds"], "verify_wall_seconds": vr["elapsed_seconds"],
                       "prove_sampled_peak_rss_kib": pr["sampled_peak_tree_rss_kib"],
                       "verify_sampled_peak_rss_kib": vr["sampled_peak_tree_rss_kib"]})
    adversarial = read("adversarial-results.json")
    assert adversarial["controls"] == 2 and adversarial["rejected"] == 20
    valid_outputs = read("adversarial-valid-output-results.json")
    assert valid_outputs["controls"] == 1 and valid_outputs["rejected"] == 4
    for case in adversarial["results"] + valid_outputs["results"]:
        receipt = read(case["receipt"])
        assert receipt["exit_code"] == case["actual_exit"] == case["expected_exit"]
        if case["expected_exit"]:
            assert case["destination_preserved"] and receipt["status"] == "rejected"
        else:
            assert receipt["status"] == "passed"
    summary = {"schema": "trident/actual-compiler-proof-pilots/v1", "status": "passed",
               "scope": "Actual accepted complete C2 on bounded SH3 and SH4 workloads; subject to independent acceptance review; full SH8 self-build proofs are separate.",
               "profile": "joy-nox-disclosed-compiler-v1", "disclosure": "complete public witness",
               "proof_properties": "Explicit public semantic certificate; no succinctness or zero-knowledge claim; no CCS profile claim.",
               "physical_resource_claim": "unattested", "source_revisions": sources,
               "binary": read("attempts/prove-loop-1/receipt.json")["binary"],
               "compiler": read("inputs.json")["compiler"], "pilots": pilots,
               "adversarial_summary": {"controls": 3, "rejected": 24, "control_byte_equality": True,
                                       "initial_results": "adversarial-results.json",
                                       "valid_regenerated_output_results": "adversarial-valid-output-results.json"},
               "retained_harness_failures": read("driver-failures.json"),
               "historical_negative_compiler": "inputs/different-compiler.dag is historical seed SHA256 4b8276068704063eb13e5555bca872372d2975b4ac71cf93edc03273222327b6, not accepted SH6 C1.",
               "rust_reference_boundary": "Loop and aggregate compare raw executed output bytes against ABI-adapted Rust references; ART1 bytes differ and are not claimed equal.",
               "scale_reference_boundary": "Exact accepted SH4 source bytes and same complete C2; explicit separate pilot resource profile changes JOB limits. Charge, depth and steps match historical execution; extracted ART1 and executed output bytes equal historical results.",
               "notes": ["Each proof and verifier command has exact argv, empty search PATH, binary identity and immutable argument hashes in its receipt.",
                         "RSS and wall times are host observations. Prover reset count includes the initial noun-table snapshot.",
                         "Large proof and compiler files are retained at indexed external paths; all small raw inputs, outputs, logs, receipts and drivers are copied below.",
                         "Original preparation snapshots intentionally retain their chronological pending wording. This final summary records completed pilot status."]}
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    # Inventory only the owned experiment, excluding build caches and this package.
    excluded = {"audit-package", "audit-package-v2", "target-mutator", "__pycache__", "empty-path"}
    manifest = {}
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if relative.parts[0] in excluded or not path.is_file():
            continue
        record = identity(path)
        retain = path.stat().st_size <= 1024 * 1024
        record.update(storage="package" if retain else "external", external_path=str(path))
        if retain:
            destination = OUT / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
            assert identity(destination) == {k: record[k] for k in ["bytes", "sha256"]}
        manifest[str(relative)] = record
    # Include helper binary identity without distributing build-cache contents.
    helper = ROOT / "target-mutator/release/compiler-pilot-mutator"
    manifest[str(helper.relative_to(ROOT))] = {**identity(helper), "storage": "external", "external_path": str(helper)}
    helper = ROOT / "target-mutator/release/compiler-pilot-valid-output-mutator"
    manifest[str(helper.relative_to(ROOT))] = {**identity(helper), "storage": "external", "external_path": str(helper)}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"status": "packaged", "files": len(manifest),
                      "copied_files": sum(v["storage"] == "package" for v in manifest.values()),
                      "copied_bytes": sum(v["bytes"] for v in manifest.values() if v["storage"] == "package"),
                      "summary": identity(OUT / "summary.json"), "manifest": identity(OUT / "manifest.json")}))


if __name__ == "__main__":
    main()

"""Freeze actual C2 and accepted SH3 pilot sources; no compiler execution."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
R2 = HERE.parent
PREP = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap/measurements/selfhost-source-preparation/final/prepared')
TRIDENT = R2 / 'certificate/trident'
JOY = R2 / 'transport-install/installed/bin/joy'


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20):
            digest.update(block)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as out:
        out.write(data)


def document(path, data):
    save(path, (json.dumps(data, indent=2) + '\n').encode())


def main():
    limits = dict(source_bytes=4096, modules=32, diagnostics=16,
                  sequence_length=65536, validation_visits=16777216,
                  artifact_bytes=16777216, artifact_nodes=196608,
                  artifact_depth=4096, reductions=100000000,
                  arena_nodes=100000000, evaluator_frames=65536)
    options = dict(target=0, input_profile=0, output_profile=0,
                   optimization=0, cfg_flags=[])
    loop_body = 'let mut x=0 for i in 2..5{x=x*10+as_field(i)} x'
    aggregate = 'program sample use bank.values fn pass(x:values.Item)->bank.values.Item{x} fn main()->Field{let x:bank.values.Item=values.Item{y:9,x:7} let y:values.Item=bank.values.echo(pass(x)) if (values.Empty{})==(bank.values.Empty{}){y.x*10+y.y}else{0}}'
    dependency = '// different foreign offsets\nmodule bank.values pub struct Item{pub x:Field,pub y:Field} pub struct Empty{} pub fn echo(x:Item)->Item{x}'
    error_entry = 'program sample use z.dep fn main()->Field{dep.good()}'
    error_dep = 'module z.dep fn unused()->Field{missing} pub fn good()->Field{7}'
    cases = {
        'loop': dict(modules={'sample': 'program sample fn main()->Field{' + loop_body + '}'},
                     expected_value=234, status='success', fixture='tests/native_compiler/loops.rs', search=loop_body),
        'aggregate': dict(modules={'sample': aggregate, 'bank.values': dependency},
                          expected_value=79, status='success', fixture='tests/native_compiler/type_imports.rs', search=aggregate),
        'compile-error': dict(modules={'sample': error_entry, 'a.padding': 'module a.padding', 'z.dep': error_dep},
                              status='compile_error', expected_diagnostic={'code': 5, 'module': 'z.dep', 'span': 'missing'},
                              fixture='tests/native_compiler/function_imports.rs', search=error_dep),
    }
    provenance = json.loads((PREP / 'receipt.json').read_text())
    assert identity(PREP / 'compiler.dag')['sha256'] == '76a07c08265bd2ef525164472b6b53ac3f0e6cbbedce3250c4202f40ffba34c8'
    assert len(provenance['sources']) == 94
    assert sum(row['bytes'] for row in provenance['sources'].values()) == 370544
    save(HERE / 'inputs/compiler.dag', (PREP / 'compiler.dag').read_bytes())
    for name in ['receipt.json', 'package.json']:
        save(HERE / 'compiler-provenance' / name, (PREP / name).read_bytes())
    for row in provenance['sources'].values():
        original = PREP / row['copy']
        assert identity(original) == {k: row[k] for k in ['bytes', 'sha256']}
        save(HERE / 'compiler-provenance' / row['copy'], original.read_bytes())
    vectors = json.loads((R2 / 'transport-install/joy/cli/tests/compiler_vectors.json').read_text())
    save(HERE / 'inputs/zero.dag', bytes.fromhex(vectors['files']['zero']))
    install = R2 / 'transport-install/postinstall/receipt.json'
    install_data = json.loads(install.read_text())
    assert install_data['exit'] == 0 and not install_data['warnings']
    assert identity(JOY)['sha256'] == install_data['sha256']
    save(HERE / 'pack-install.json', install.read_bytes())
    report = dict(schema='joy/actual-compiler-pilot-inputs/v1', scope='Actual full frozen C2 on bounded accepted SH3 workloads; SH7/SH8 acceptance pending',
                  compiler=dict(original=str(PREP / 'compiler.dag'), **identity(HERE / 'inputs/compiler.dag')),
                  compiler_source_modules=94, compiler_source_bytes=370544,
                  pack_binary=dict(path=str(JOY), **identity(JOY)),
                  trident_fixture_revision=subprocess.check_output(['git', '-C', str(TRIDENT), 'rev-parse', 'HEAD'], text=True).strip(),
                  cases={}, oracle_transform='For successful cases only: rename fn main()->Field to fn result()->Field and append fn main(input:Noun)->Noun{nox_noun_atom(result())}. This adapts only the raw seed ABI; reference output is compared after separate execution.')
    for name, case in cases.items():
        fixture = TRIDENT / case['fixture']
        assert case['search'] in fixture.read_text()
        manifest = dict(version=1, entry_module='sample', entry_function='main', modules=[], options=options, limits=limits)
        sources = {}
        for module, source in sorted(case['modules'].items()):
            relative = module.replace('.', '/') + '.tri'
            path = HERE / 'cases' / name / relative
            save(path, source.encode())
            sources[module] = dict(file=relative, **identity(path))
            manifest['modules'].append(dict(logical_path=module, file=relative, origin_name='sh3-pilot', origin_version='1'))
            if case['status'] == 'success':
                oracle = source
                if module == 'sample':
                    oracle = source.replace('fn main()->Field', 'fn result()->Field', 1) + ' fn main(input:Noun)->Noun{nox_noun_atom(result())}'
                save(HERE / 'oracle' / name / relative, oracle.encode())
        document(HERE / 'cases' / name / 'package.json', manifest)
        report['cases'][name] = {k: v for k, v in case.items() if k not in ['modules', 'search']}
        report['cases'][name].update(source_files=sources, source_bytes=sum(v['bytes'] for v in sources.values()), fixture_identity=identity(fixture))
    (HERE / 'empty-path').mkdir()
    document(HERE / 'inputs.json', report)
    print(json.dumps({name: {'modules': len(row['source_files']), 'source_bytes': row['source_bytes']} for name, row in report['cases'].items()}))


if __name__ == '__main__':
    main()

"""Exact accepted short/65536-byte SH4 workloads through frozen C2 certificates."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from prepare import identity, save, document

HERE = Path(__file__).resolve().parent
INSTALL = HERE.parent/'production-install'
JOY = INSTALL/'installed/bin/joy'
OLD = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap/measurements/lexer-v9-c2-source-scale.json')
HOST = ['--budget','600000000','--arena-nodes','20000000','--frames','65536',
        '--artifact-bytes','16777216','--artifact-nodes','196608','--artifact-depth','4096',
        '--validation-visits','16777216','--resident-nodes','3145728',
        '--collection-work','200000000','--time-ms','900000']
PROOF = ['--proof-bytes','4294967296','--proof-decoded-bytes','8589934592',
         '--proof-records','500000000','--proof-steps','600000000','--proof-cache-slots','65536']


def run(name, args):
    subprocess.run([sys.executable,str(HERE/'run.py'),'--seconds','930','--disk-mib','8192',
                    '--source-receipt',str(INSTALL/'postinstall/receipt.json'),name,'--',str(JOY),*map(str,args)],check=True)
    return json.loads((HERE/'attempts'/name/'stdout').read_text())


def prepare():
    receipt = json.loads(OLD.read_text())
    assert receipt['status']=='passed' and receipt['compiler_sha256_start']==identity(HERE/'inputs/compiler.dag')['sha256']
    save(HERE/'scale-historical-receipt.json',OLD.read_bytes())
    report={'schema':'joy/compiler-source-scale-proof-inputs/v1','historical_receipt':dict(path=str(OLD),**identity(OLD)),
            'host_flags':HOST,'proof_flags':PROOF,'guards':{'wall_seconds':930,'sampled_rss_kib':3145728,'disk_bytes':8<<30},'cases':{}}
    for name in ['baseline','valid65536']:
        row=next(r for r in receipt['observations'] if r['case']==name)
        source=Path(row['source_file']);assert identity(source)['sha256']==row['source_sha256']
        directory=HERE/'scale'/name
        save(directory/'sample.tri',source.read_bytes())
        manifest=copy.deepcopy(row['manifest']);manifest['limits'].update(reductions=600000000,arena_nodes=20000000)
        document(directory/'package.json',manifest)
        packed=run('pack-scale-'+name,['pack-job','--compiler',HERE/'inputs/compiler.dag','--manifest',directory/'package.json','--output',directory/'job.dag',*HOST])
        prior=row['compiler_execution']['execution']
        report['cases'][name]={'source':dict(path=str(source),**identity(source)), 'job':identity(directory/'job.dag'),
                                'admission':packed['package'], 'historical':{k:prior[k] for k in ['charged_reductions','peak_frames','allocated_nodes','elapsed_micros','compaction']},
                                'expected_program_sha256':row['program_sha256'],'expected_output_sha256':row['output_sha256'],'expected_value':row['expected']}
    document(HERE/'scale-inputs.json',report)


def execute(name):
    expected=json.loads((HERE/'scale-inputs.json').read_text())['cases'][name]
    source=HERE/'scale'/name/'sample.tri';assert identity(source)=={k:expected['source'][k] for k in ['bytes','sha256']}
    compiler=HERE/'inputs/compiler.dag';job=HERE/'scale'/name/'job.dag'
    assert identity(job)==expected['job']
    prefix='scale-'+name
    proof=HERE/'attempts'/('prove-'+prefix+'-1')/'proof.joysc'
    proved=run('prove-'+prefix+'-1',['prove-artifact',compiler,'--input',job,'--output','proof.joysc',*HOST,*PROOF])['verification']
    verified=run('verify-'+prefix+'-result-1',['verify-artifact',compiler,'--input',job,'--proof',proof,'--output','result.dag',*HOST,*PROOF])['verification']
    for key in ['program_particle','input_particle','output_particle','charged_reductions','invocations','logical_peak_frames','expanded_steps','semantic_events','records','transport','compiler_job']:
        assert proved[key]==verified[key],key
    assert verified['compiler_job']['status']=='success' and 'prover_observations' not in verified
    run('verify-'+prefix+'-program-1',['verify-artifact',compiler,'--input',job,'--proof',proof,'--emit','program','--output','program.dag',*HOST,*PROOF])
    program=HERE/'attempts'/('verify-'+prefix+'-program-1')/'program.dag'
    assert identity(program)['sha256']==expected['expected_program_sha256']
    run('execute-'+prefix+'-1',['run-artifact',program,'--input',HERE/'inputs/zero.dag','--output','output.dag'])
    output=HERE/'attempts'/('execute-'+prefix+'-1')/'output.dag'
    assert identity(output)['sha256']==expected['expected_output_sha256']
    assert identity(source)=={k:expected['source'][k] for k in ['bytes','sha256']}
    result={'case':name,'same_verified_fields':True,'same_exact_program_as_historical':True,'same_exact_output_as_historical':True,
            'scalar':13,'current_job':identity(job),'program':identity(program),'output':identity(output),'prover_report':proved,'verifier_report':verified}
    if name=='valid65536':
        baseline=HERE/'attempts/verify-scale-baseline-program-1/program.dag'
        assert baseline.read_bytes()==program.read_bytes()
        result['same_exact_program_as_short_proof']=True
        assert proved['prover_observations']['resets']>1
    document(HERE/(prefix+'-comparison.json'),result)
    print(json.dumps({'case':name,'status':'passed','charge':proved['charged_reductions'],'proof':proved['transport'],'observations':proved['prover_observations']}),flush=True)


if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    else:execute(sys.argv[1])

"""Run one already packed actual-C2 pilot and compare independently checked outputs."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
INSTALL = HERE.parent / 'production-install'
JOY = INSTALL / 'installed/bin/joy'
FLAGS = ['--budget', '100000000', '--arena-nodes', '100000000', '--frames', '65536',
         '--artifact-bytes', '16777216', '--artifact-nodes', '196608', '--artifact-depth', '4096',
         '--validation-visits', '16777216', '--resident-nodes', '3145728',
         '--collection-work', '1000000000', '--time-ms', '300000',
         '--proof-bytes', '1073741824', '--proof-decoded-bytes', '2147483648',
         '--proof-records', '100000000', '--proof-steps', '200000000', '--proof-cache-slots', '65536']


def run(name, args, expect=0):
    argv = [sys.executable, str(HERE/'run.py'), '--source-receipt', str(INSTALL/'postinstall/receipt.json'),
            name, '--', str(JOY), *map(str, args)]
    result = subprocess.run(argv)
    receipt = json.loads((HERE/'attempts'/name/'receipt.json').read_text())
    assert receipt['exit_code'] == expect, receipt
    assert receipt['status'] == ('passed' if expect == 0 else 'rejected'), receipt
    assert result.returncode == (0 if expect == 0 else 1)
    output = (HERE/'attempts'/name/'stdout').read_text()
    return json.loads(output) if expect == 0 else (HERE/'attempts'/name/'stderr').read_text()


def main(case):
    inputs = json.loads((HERE/'inputs.json').read_text())
    expected = inputs['cases'][case]
    compiler = HERE/'inputs/compiler.dag'
    job = HERE/'cases'/case/'job.dag'
    proof = HERE/'attempts'/f'prove-{case}-1'/'proof.joysc'
    proved = run(f'prove-{case}-1', ['prove-artifact', compiler, '--input', job, '--output', 'proof.joysc', *FLAGS])['verification']
    verified = run(f'verify-{case}-result-1', ['verify-artifact', compiler, '--input', job, '--proof', proof,
                                           '--output', 'result.dag', *FLAGS])['verification']
    for key in ['program_particle', 'input_particle', 'output_particle', 'charged_reductions', 'invocations',
                'logical_peak_frames', 'expanded_steps', 'semantic_events', 'records', 'transport', 'compiler_job']:
        assert proved[key] == verified[key], key
    assert 'prover_observations' not in verified
    assert verified['compiler_job']['status'] == expected['status']
    packed = json.loads((HERE/'attempts'/f'pack-{case}'/'stdout').read_text())['package']
    assert verified['program_particle'] == packed['compiler_particle']
    assert verified['input_particle'] == packed['job_particle']
    for key in ['package_particle', 'modules', 'entry_function', 'entry_module', 'options', 'limits']:
        assert verified['compiler_job'][key] == packed[key], key
    comparison = dict(case=case, same_verified_fields=True, fresh_verifier_observations_absent=True,
                      exact_package_bindings=True, status=expected['status'])
    if expected['status'] == 'success':
        run(f'verify-{case}-program-1', ['verify-artifact', compiler, '--input', job, '--proof', proof,
                                      '--output', 'program.dag', '--emit', 'program', *FLAGS])
        program = HERE/'attempts'/f'verify-{case}-program-1'/'program.dag'
        run(f'execute-{case}-1', ['run-artifact', program, '--input', HERE/'inputs/zero.dag', '--output', 'output.dag'])
        output = (HERE/'attempts'/f'execute-{case}-1'/'output.dag').read_bytes()
        oracle = (HERE/'attempts'/f'oracle-run-{case}'/'output.dag').read_bytes()
        assert output == oracle
        assert len(output) == 85 and output[76] == 8 and int.from_bytes(output[77:85], 'little') == expected['expected_value']
        comparison.update(compiled_output_equal_rust_reference=True, scalar=expected['expected_value'],
                          compiled_artifact_bytes_equal_rust_reference=program.read_bytes() == (HERE/'oracle'/case/'reference.dag').read_bytes(),
                          output_sha256=hashlib.sha256(output).hexdigest())
    else:
        diagnostic = verified['compiler_job']['diagnostics']
        assert len(diagnostic) == 1 and diagnostic[0]['code'] == expected['expected_diagnostic']['code'], diagnostic
        comparison['diagnostics'] = diagnostic
        protected = HERE/'protected-compile-error.dag'
        protected.write_bytes(b'previous complete artifact\n')
        error = run(f'verify-{case}-program-refused-1', ['verify-artifact', compiler, '--input', job, '--proof', proof,
                                                     '--output', protected, '--emit', 'program', '--force', *FLAGS], expect=1)
        assert 'guest compilation failed' in error and protected.read_bytes() == b'previous complete artifact\n'
        comparison['compile_error_preserves_destination'] = True
    (HERE/f'{case}-comparison.json').write_text(json.dumps(comparison, indent=2)+'\n')
    print(json.dumps(comparison), flush=True)


if __name__ == '__main__':
    main(sys.argv[1])

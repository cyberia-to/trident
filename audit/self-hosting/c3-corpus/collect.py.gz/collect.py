"""Retain exact completed C3 corpus evidence; never execute or replace artifacts."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
source = args.input.resolve()
inputs = json.loads((source / 'inputs.json').read_text())
summary = json.loads((source / 'summary.json').read_text())
assert summary['passed'] and summary['inputs_unchanged']
compiler, binary = Path(inputs['compiler']), Path(inputs['binary'])
assert sha(compiler.read_bytes()) == inputs['compiler_sha256']
assert sha(binary.read_bytes()) == inputs['binary_sha256']
repo = Path(summary['results']['main']['cwd'])
assert all(sha((repo / path).read_bytes()) == value for path, value in inputs['source_sha256'].items())
output = args.output.resolve()
output.mkdir()
evidence, results = {}, {}


def retain(name, compressed=False):
    data = (source / name).read_bytes()
    stored = gzip.compress(data, mtime=0) if compressed else data
    target = name + '.gz' if compressed else name
    with (output / target).open('xb') as file:
        file.write(stored)
    evidence[target] = dict(original=str(source / name), original_sha256=sha(data),
                            original_bytes=len(data), sha256=sha(stored), bytes=len(stored))


for name in ['inputs.json', 'summary.json', 'run.py', 'collect.py']:
    retain(name, name.endswith('.py'))
historical = dict(main='full', constants='constants', callable='callable', types='types',
                  intrinsics='intrinsic', **{'generated-profile': 'profile'})
for name, row in summary['results'].items():
    data = (source / (name + '.json')).read_bytes()
    receipt = json.loads(data)
    assert row['exit_code'] == 0 and receipt['status'] == 'passed'
    assert len(receipt['observations']) == row['expected_observations']
    assert receipt['compiler_mode'] == 'provided'
    assert Path(receipt['compiler_path']).resolve() == compiler
    assert receipt['compiler_sha256_start'] == receipt['compiler_sha256_end'] == inputs['compiler_sha256']
    assert receipt.get('binary_sha256', receipt.get('binary_sha256_start')) == inputs['binary_sha256']
    assert receipt.get('binary_sha256_end', inputs['binary_sha256']) == inputs['binary_sha256']
    assert sha(data) == row['receipt_sha256']
    assert sha((source / (name + '.log')).read_bytes()) == row['log_sha256']
    builds = [command for command in receipt['commands'] if command['command'][1] == 'build']
    for command in builds:
        argv = command['command']
        assert command.get('reference_only') is True
        assert argv[argv.index('--artifact-profile') + 1] == 'raw'
        assert Path(argv[argv.index('-o') + 1]).resolve() != compiler
    previous_path = repo / ('audit/self-hosting/source-capacity-' + historical[name] + '-cli.json')
    previous = json.loads(previous_path.read_text())
    assert len(previous['observations']) == len(receipt['observations'])
    for old, new in zip(previous['observations'], receipt['observations']):
        for key in ['case', 'limit', 'source_hex', 'sources', 'expected', 'boundary']:
            assert old.get(key) == new.get(key), (name, key, old.get('case'))
    results[name] = dict(observations=len(receipt['observations']), commands=len(receipt['commands']),
                        reference_builds=len(builds), compiler_seed_builds=0,
                        historical_case_sources_and_expectations_equal=True,
                        historical_receipt=str(previous_path.relative_to(repo)),
                        historical_receipt_sha256=sha(previous_path.read_bytes()))
    retain(name + '-command.json')
    retain(name + '.json', True)
    retain(name + '.log', True)

generated = json.loads((source / 'generated-profile.json').read_text())
retained = Path(generated['artifact_directory'])
archive = io.BytesIO()
with tarfile.open(fileobj=archive, mode='w', format=tarfile.PAX_FORMAT) as tar:
    for item in generated['files']:
        path = retained / item['path']
        assert path.resolve().is_relative_to(retained.resolve())
        data = path.read_bytes()
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
        info = tarfile.TarInfo(item['path'])
        info.size, info.mtime, info.mode = len(data), 0, 0o644
        tar.addfile(info, io.BytesIO(data))
stored = gzip.compress(archive.getvalue(), mtime=0)
with (output / 'generated-artifacts.tar.gz').open('xb') as file:
    file.write(stored)
evidence['generated-artifacts.tar.gz'] = dict(sha256=sha(stored), bytes=len(stored),
    files=len(generated['files']), source_directory=str(retained),
    file_manifest='generated-profile.json.gz: files')
validation = dict(scope='Actual C3 semantic corpora only; clean repeat, platforms and proofs are separate',
    command=['python3', str(source / 'collect.py'), '--input', str(source), '--output', str(output)],
    launch_revision=inputs['revision'], compiler_sha256=inputs['compiler_sha256'],
    compiler_particle=inputs['compiler_particle'], binary_sha256=inputs['binary_sha256'],
    all_source_hashes_unchanged=True, results=results, evidence=evidence,
    encoding='Raw receipts/logs preserved exactly with deterministic gzip; no whitespace normalization')
(output / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
print(json.dumps(dict(status='retained', output=str(output), observations=sum(r['observations'] for r in results.values()))))

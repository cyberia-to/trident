import hashlib,json,os,platform,subprocess,sys
from pathlib import Path
R=Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
W=R/'portable-native-smoke/trident-selfbuild-guide'
OUT=Path(__file__).resolve().parent
NAMES=['scripts/prepare-selfhost-source.py','scripts/test_prepare_selfhost_source.py','scripts/fixtures/selfhost-kit-metadata.tar.gz','docs/guides/self-hosted-compilation.md','reference/self-hosting-jobs.md','.github/workflows/selfhost-bootstrap.yml']
def identity(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
r={'schema':'trident/selfbuild-portability-followup/v1','source_revision':'98c5897aafde1072c692e0c1373d30f40f917e0d','status':'running','platform':platform.platform(),'scope':'Local repeated 21 cases; no Windows execution claim; helper and guest inputs unchanged','before':{n:identity(W/n) for n in NAMES},'commands':[]}
try:
 for name,args in [('ordinary',[]),('optimized',['-O'])]:
  argv=[sys.executable,'-B',*args,'-W','error','-m','unittest','discover','-s','scripts','-p','test_prepare_selfhost_source.py','-v']
  with (OUT/(name+'.stdout')).open('xb') as out,(OUT/(name+'.stderr')).open('xb') as err:
   c=subprocess.run(argv,cwd=W,stdout=out,stderr=err,timeout=180,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  r['commands'].append({'argv':argv,'cwd':str(W),'exit_code':c.returncode,'stdout':identity(OUT/(name+'.stdout')),'stderr':identity(OUT/(name+'.stderr'))})
  assert c.returncode==0
 r['after']={n:identity(W/n) for n in NAMES};assert r['before']==r['after']
 r['status']='passed'
finally:
 (OUT/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')

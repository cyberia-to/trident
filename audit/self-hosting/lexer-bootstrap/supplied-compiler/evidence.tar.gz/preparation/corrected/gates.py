import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
W = R / 'portable-native-smoke/trident-selfbuild-guide'
OUT = Path(__file__).resolve().parent
PATHS = ['scripts/prepare-selfhost-source.py', 'scripts/test_prepare_selfhost_source.py',
         'scripts/fixtures/selfhost-kit-metadata.tar.gz', 'docs/guides/self-hosted-compilation.md',
         'reference/self-hosting-jobs.md', '.github/workflows/selfhost-bootstrap.yml']


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


report = dict(capture_revision='57491633fbccb58ae44dca2da438ee31430be1bc',
              status='running', before={name: identity(W / name) for name in PATHS}, commands=[])
commands = [
    ('guards', [sys.executable, '-B', '-W', 'error', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_prepare_selfhost_source.py', '-v']),
    ('guards-optimized', [sys.executable, '-B', '-O', '-W', 'error', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_prepare_selfhost_source.py', '-v']),
    ('bootstrap-guards', [sys.executable, '-B', '-W', 'error', '-m', 'unittest', 'discover', '-s', 'audit/self-hosting', '-p', 'test_bootstrap*.py', '-v']),
    ('actionlint', [str(R / 'actionlint-bin/actionlint'), '.github/workflows/selfhost-bootstrap.yml', '.github/workflows/selfhost-bootstrap-repeat.yml']),
    ('diff-check', ['git', 'diff', '--check']),
]
try:
    for name, argv in commands:
        with (OUT / (name + '.stdout')).open('xb') as out, (OUT / (name + '.stderr')).open('xb') as err:
            run = subprocess.run(argv, cwd=W, stdout=out, stderr=err, timeout=180,
                                 env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        row = dict(name=name, argv=argv, cwd=str(W), exit_code=run.returncode,
                   stdout=identity(OUT / (name + '.stdout')), stderr=identity(OUT / (name + '.stderr')))
        report['commands'].append(row)
        assert run.returncode == 0, name
    links = []
    for name in PATHS:
        if name.endswith('.md'):
            for link in re.findall(r'\[[^\]]*\]\(([^)]*)\)', (W / name).read_text()):
                if '://' not in link and not link.startswith('#'):
                    assert (W / name).parent.joinpath(link.split('#')[0]).exists(), (name, link)
                    links.append(dict(file=name, target=link))
    report['links'] = links
    report['after'] = {name: identity(W / name) for name in PATHS}
    assert report['before'] == report['after']
    report.update(status='passed', focused_unique=21, routing_unique=46, optimized_repeated=21)
finally:
    (OUT / 'gates.json').write_text(json.dumps(report, indent=2) + '\n')

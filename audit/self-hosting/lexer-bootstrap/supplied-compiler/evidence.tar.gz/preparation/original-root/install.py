import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
OUT = Path(__file__).resolve().parent / 'postinstall'
SOURCE = R / 'portable-native-smoke/trident-selfbuild-guide'
PREFIX = R / 'install-selfbuild-guide'
OUT.mkdir()
assert not PREFIX.exists()


def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()


def family():
    return {name: dict(path=str(R / 'portable-native-smoke' / name),
                       revision=git(R / 'portable-native-smoke' / name, 'rev-parse', 'HEAD'),
                       status=git(R / 'portable-native-smoke' / name, 'status', '--porcelain'))
            for name in ['trident-selfbuild-guide', 'nox', 'joy', 'hemera', 'strata', 'zheng', 'bbg', 'lens', 'neuron']}


env = dict(os.environ, CARGO_TARGET_DIR=str(R / 'target-selfbuild-guide'), CARGO_BUILD_JOBS='1',
           RUSTUP_TOOLCHAIN='1.89.0', PATH=str(PREFIX / 'bin') + os.pathsep + os.environ['PATH'])
argv = ['cargo', 'install', '--path', '.', '--root', str(PREFIX), '--locked', '--offline', '--force']
receipt = dict(status='running', argv=argv, cwd=str(SOURCE), before=family(), started_ns=time.time_ns(),
               environment={key: env[key] for key in ['CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'RUSTUP_TOOLCHAIN', 'PATH']})
assert all(not row['status'] for row in receipt['before'].values())
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
with (OUT / 'stdout').open('xb') as out, (OUT / 'stderr').open('xb') as err:
    result = subprocess.run(argv, cwd=SOURCE, env=env, stdout=out, stderr=err)
receipt.update(exit_code=result.returncode, after=family(), ended_ns=time.time_ns())
receipt['status'] = 'passed' if result.returncode == 0 and receipt['before'] == receipt['after'] else 'failed'
receipt['warning_lines'] = [line for line in (OUT / 'stderr').read_text().splitlines() if 'warning:' in line.lower()]
if receipt['warning_lines']:
    receipt['status'] = 'failed'
if result.returncode == 0:
    binary = PREFIX / 'bin/trident'
    data = binary.read_bytes()
    receipt['binary'] = dict(path=str(binary), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    version = subprocess.run([str(binary), '--version'], capture_output=True, check=False)
    (OUT / 'version.stdout').write_bytes(version.stdout)
    (OUT / 'version.stderr').write_bytes(version.stderr)
    receipt['version_exit'] = version.returncode
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(0 if receipt['status'] == 'passed' else 1)

import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

R=Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
P=Path(__file__).resolve().parent
W=R/'portable-native-smoke/trident-selfbuild-guide'
OUT=W/'audit/self-hosting/lexer-bootstrap/supplied-compiler'
r=json.loads((R/'measurements/selfhost-source-execution/receipt.json').read_bytes())
a=json.loads((OUT/'receipt.json').read_bytes())
if r['status']!='passed':
    raise ValueError('write a failure-specific report; never manufacture success')
readme=f'''# Supplied-C2 frozen-source preparation and self-build

This local rehearsal prepared all 94 frozen S1 modules (370544 bytes), packed
them twice from relocated source trees, then ran the supplied C2 once with the
third installed Rust-1.89-built Joy. C3 is exactly the supplied C2: 9691488 bytes,
SHA-256 `76a07c08265bd2ef525164472b6b53ac3f0e6cbbedce3250c4202f40ffba34c8`.
The package remains explicitly `rehearsal`. This supplies no accepted-kit
positive, replacement native matrix, corpus verdict or SH7/SH8 proof claim.

## Source and runtime binding

Helper/source unit: `98c5897aafde1072c692e0c1373d30f40f917e0d`, based on
`57491633fbccb58ae44dca2da438ee31430be1bc`. Helper SHA-256:
`4f2381880f7da77265ed562cb99bc0e7bcad4c5f7df28f8c62bf7a37f55c3711`.
All 94 source bytes and all 627 tracked Rust, Trident and Cargo inputs equal
that base. See retained `preparation/portability/source-integrity.json`.
A standalone matching Trident checkout/source archive suffices; preparation
also passed on a directory containing only the 94 source files, relocated to
a path containing spaces and Unicode. Coordinated archive packaging is not a
consumer dependency. The runtime path needs Python, Joy and verified C2/kit
metadata plus those source files, with no Rust toolchain or Trisha/Neptune
installation.

The guide was adapted from existing Trident guide commit
`82fdd1fd45fd14f3ac8da60a53d9e1a3e675c18e`; kit sample paths replace audit links
absent at base 57491633. Later guide wording and a WinError-1314-only symlink
test skip do not change the helper or guest inputs. Capture records retain
actual dirty-source identities at execution rather than relabeling them with
a later documentation commit.

Installed Joy: 5233200 bytes, SHA-256
`4035bca898e760666206f445c939c784ea248bff4f82c2c4f0a75254c3c48885`.
The retained `runtime-provenance/` records bind the original third candidate's
committed source closure, Rust 1.89 and exact binary. The source Trident is
57491633; Joy is `adb424023ae11a2264567d21171c3c2b3aa06f64`, with Nox
`172811b7746cdcd6ab198a3ed976dc6c19f55d5b` and Zheng
`633e5ba980db94ca10d9d6b67cf24d9d3aef63a7`. The executable remains external at
the exact path/length/hash in `receipt.json`; its raw bytes are not duplicated.

## Observed commands and limits

The full argv, cwd, environment, exit status and raw stdout/stderr are retained
for five preparation commands: default rejection of the actual rehearsal kit
(exit 1), two explicit rehearsal preparations and two `joy pack-job` calls
(exit 0). Both 6762002-byte JOB1 files have SHA-256
`3474e5583e7b3ac36bdd526435bb2ae584691774a009e29ca02407c22589f13d`.
The source contents, package manifest, admission packages and JOB1 bytes are
identical across relocation. No source parser or compiler is invoked by the
preparer. The exact manifest is in both retained prepared trees.

The subsequent single command was the guide's `joy run-artifact compiler.dag
--input job.dag --emit program --output c3.dag`, with absolute input/output
paths recorded in `execution/receipt.json`, and these unchanged explicit flags:

```text
--arena-nodes 1000000000 --budget 20000000000 --frames 65536
--time-ms 7200000 --validation-visits 16777216
--resident-nodes 3145728 --collection-work 10000000000
```

Packing and execution used an empty executable PATH and absolute Python/Joy
paths; Cargo, rustc and Trident were unavailable on PATH. `/bin/ps` sampled
RSS every 30 seconds without participating in compilation. There was one
guest run, no retry, host seed fallback or limit change. Source bytes, C2,
JOB1 and Joy were checked before and after execution.

Joy returned exit 0 and compiler-job success after {r['elapsed_micros']} us.
It charged {r['execution_summary']['charged_reductions']} reductions,
allocated {r['execution_summary']['allocated_nodes']} cumulative nodes and
reached {r['execution_summary']['peak_frames']} frames. Sampled process-tree
RSS peaked at {r['sampled_peak_tree_rss_kib']} KiB; this is a sampled observation,
not an RSS bound. C3 equals C2 byte for byte. Admission compiler/job particles
match execution program/input particles, and every non-time execution field
matches the original S1 C2-to-C3 record. Only `elapsed_micros` is excluded.
The historical record used a 3600000 ms host deadline; this command used the
published 7200000 ms deadline. The compiler/job/runtime counters are otherwise
compared exactly. Both raw receipts remain retained.

## Local checks and retained history

There are 21 distinct helper guards and 46 existing bootstrap routing guards.
The 21 helper guards passed in ordinary and optimized Python; repeated runs
are not additional distinct tests. The final local portability repetition
also passed all 21 with zero skips on this Mac. It does not claim execution
on Windows. Symlink creation skips only explicit Windows privilege error
1314; all unexpected errors remain failures. The actual Mac case-insensitive
path guard executed. Actionlint and diff checks passed. Postcommit isolated
`cargo install --path . --locked --offline --force` and version check passed
with zero warnings; its nine clean source identities, exact argv and raw
logs are retained under `postinstall/`. No Rust or compiler source changed.

The original preparation run and first final capture are preserved separately
from corrected checks. Review led to physical case-alias protection and helper
identity binding before the final packing/run. Later corrections preserved
existing reference-section topology and removed an English-only missing-file
assertion. Independent review and root cheap-pack review are retained as raw
receipts; their timestamps/source hashes are not rewritten as later runs.

The final documentation/audit commit intentionally uses `[skip ci]` to avoid
rerunning the unchanged 36-phase matrix for transport-only changes. This is
not a green CI result for that head. Original matrix acceptance belongs to
its own original receipts and pinned 57491633 input; see the
[self-hosting ledger](../../../self-hosting-progress.md). No workflow settings,
required checks or branch protection were altered. GitHub documents the
HEAD-marker behavior in [Skipping workflow runs](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/skip-workflow-runs).

## Retention and offline verification

`evidence.tar.gz` retains {a['members']} named raw files totaling {a['raw_bytes']}
bytes; identical bytes use ordinary tar hardlinks. Gzip/tar timestamps and
owners are zero. `files-*.json` lists each original path, raw SHA-256 and size.
Every archived member was byte-compared with its original. The original
measurement files remain unchanged. Raw log whitespace was not normalized.

```sh
python3 verify.py
```

This checks every retained byte plus receipt/input/output/particle/counter
bindings without running a compiler. It is an evidence check, not a fresh
guest execution or acceptance authority. The executable is not needed for
this verification. To repeat the actual guest run, use the unchanged prepared
compiler/JOB1 and an independently verified installed Joy with the published
flags, fresh destinations and retained exit/log evidence.
'''
(OUT/'README.md').write_text(readme)
shutil.copyfile(P/'verify-retained.py',OUT/'verify.py')
with (OUT/'verification.json').open('xb') as stdout:
    subprocess.run([sys.executable,'-B','-W','error',str(OUT/'verify.py')],cwd=OUT,stdout=stdout,check=True)
links=[]
for name in ['docs/guides/self-hosted-compilation.md','reference/self-hosting-jobs.md','audit/self-hosting/lexer-bootstrap/supplied-compiler/README.md']:
    for link in re.findall(r'\[[^\]]*\]\(([^)]*)\)',(W/name).read_text()):
        if '://' not in link and not link.startswith('#'):
            if not (W/name).parent.joinpath(link.split('#')[0]).exists(): raise ValueError((name,link))
            links.append(dict(file=name,target=link))
(OUT/'links.json').write_text(json.dumps(dict(status='passed',links=links),indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=W,check=True)
rows=[]
for path in sorted(OUT.iterdir()):
    if path.is_file():
        raw=path.read_bytes();rows.append(dict(path=path.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(OUT/'files.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(dict(status='passed',delivery_files=len(rows)+1,archive=a['archive'],members=a['members'])))

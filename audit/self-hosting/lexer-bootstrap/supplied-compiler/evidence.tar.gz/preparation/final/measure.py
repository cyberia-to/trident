"""Actual supplied-C2 packaging only, with no Rust/Cargo/Trident on PATH."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
ROOT = Path(__file__).resolve().parent
SOURCE = R / 'portable-native-smoke/trident-selfbuild-guide'
SCRIPT = SOURCE / 'scripts/prepare-selfhost-source.py'
KIT = R / 'measurements/selfhost-kit/rehearsal-1/kit'
JOY = R / 'measurements/coordinated-soft3-release-3/candidate пробел/bin/joy'
FLAGS = ['--arena-nodes', '1000000000', '--budget', '20000000000', '--frames', '65536',
         '--time-ms', '7200000', '--validation-visits', '16777216',
         '--resident-nodes', '3145728', '--collection-work', '10000000000']
EXPECTED = '3474e5583e7b3ac36bdd526435bb2ae584691774a009e29ca02407c22589f13d'


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


env = dict(os.environ, PATH=str(ROOT / 'empty-path'), PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
(ROOT / 'empty-path').mkdir()
report = dict(status='running', scope='Actual historical-C2 transport rehearsal; no guest compiler execution or acceptance',
              started_ns=time.time_ns(), source_revision='57491633fbccb58ae44dca2da438ee31430be1bc',
              helper_start=identity(SCRIPT), joy_start=identity(JOY), kit_manifest=identity(KIT / 'kit.json'),
              environment={key: env[key] for key in ['PATH', 'PYTHONDONTWRITEBYTECODE', 'PYTHONUTF8']},
              unavailable_tools={name: shutil.which(name, path=env['PATH']) for name in ['cargo', 'rustc', 'trident']},
              commands=[], host_flags=FLAGS, expected_job_sha256=EXPECTED)
assert not any(report['unavailable_tools'].values())
assert report['joy_start']['sha256'] == '4035bca898e760666206f445c939c784ea248bff4f82c2c4f0a75254c3c48885'


def flush():
    (ROOT / 'measurement.json').write_text(json.dumps(report, indent=2) + '\n')


def run(label, args, expected=0):
    row = dict(label=label, argv=list(map(str, args)), cwd=str(ROOT), started_ns=time.time_ns())
    report['commands'].append(row)
    flush()
    with (ROOT / (label + '.stdout')).open('xb') as out, (ROOT / (label + '.stderr')).open('xb') as err:
        result = subprocess.run(row['argv'], cwd=ROOT, env=env, stdout=out, stderr=err, timeout=180)
    row.update(exit_code=result.returncode, ended_ns=time.time_ns(),
               stdout=identity(ROOT / (label + '.stdout')), stderr=identity(ROOT / (label + '.stderr')))
    flush()
    assert result.returncode == expected, label


try:
    common = [sys.executable, '-B', '-W', 'error', SCRIPT, '--kit', KIT,
              '--kit-manifest-sha256', report['kit_manifest']['sha256']]
    rejected = ROOT / 'default-rejected'
    run('default-rejects-rehearsal', [*common, '--source-root', SOURCE, '--output', rejected], 1)
    assert not rejected.exists()
    first, second = ROOT / 'prepared', ROOT / 'prepared пробел'
    run('prepare', [*common, '--source-root', SOURCE, '--output', first, '--rehearsal'])
    mapping = json.loads((KIT / 'fixed-point.json').read_bytes())['fixed_point']['source_sha256_set']
    relocated = ROOT / 'relocated source пробел'
    relocated.mkdir()
    for row in mapping.values():
        target = relocated / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((SOURCE / row['path']).read_bytes())
    run('prepare-relocated', [*common, '--source-root', relocated, '--output', second, '--rehearsal'])
    for label, directory in [('pack', first), ('pack-relocated', second)]:
        run(label, [JOY, 'pack-job', '--compiler', directory / 'compiler.dag', '--manifest',
                    directory / 'package.json', '--output', directory / 'job.dag', *FLAGS])
        assert identity(directory / 'job.dag')['sha256'] == EXPECTED
    assert (first / 'package.json').read_bytes() == (second / 'package.json').read_bytes()
    assert (first / 'job.dag').read_bytes() == (second / 'job.dag').read_bytes()
    a, b = [json.loads((ROOT / (label + '.stdout')).read_bytes()) for label in ['pack', 'pack-relocated']]
    assert a['ok'] is True and b['ok'] is True and a['package'] == b['package']
    report.update(status='passed', job=identity(first / 'job.dag'), relocated_job=identity(second / 'job.dag'),
                  exact_manifest_bytes_equal=True, exact_job_bytes_equal=True, exact_admission_packages_equal=True,
                  prepared_receipts=[identity(path / 'receipt.json') for path in [first, second]],
                  module_count=94, source_bytes=370544, guest_runs=0)
except BaseException as error:
    report.update(status='failed', error=dict(kind=type(error).__name__, message=str(error)))
    raise
finally:
    report.update(ended_ns=time.time_ns(), helper_end=identity(SCRIPT), joy_end=identity(JOY))
    if report['helper_end'] != report['helper_start'] or report['joy_end'] != report['joy_start']:
        report['status'] = 'inputs-changed'
    flush()

"""Retain completed transport/full-run evidence; preserve every selected raw byte."""
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
M = R / 'measurements'
P = M / 'selfhost-source-preparation'
E = M / 'selfhost-source-execution'
W = R / 'portable-native-smoke/trident-selfbuild-guide'
OUT = W / 'audit/self-hosting/lexer-bootstrap/supplied-compiler'


def identity(path):
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def load(path):
    return json.loads(path.read_bytes())


execution = load(E / 'receipt.json')
if execution['status'] in ('preflight', 'running'):
    raise ValueError('execution still mutable')
selected = {}


def add(name, path):
    if name in selected or path.is_symlink() or not path.is_file():
        raise ValueError('invalid selected file: ' + name)
    selected[name] = path


def tree(prefix, path):
    for member in sorted(path.rglob('*')):
        if member.is_file():
            add(prefix + '/' + member.relative_to(path).as_posix(), member)


for folder, prefix in [(P, 'preparation/original-root'), (P / 'final', 'preparation/final'),
                       (P / 'corrected', 'preparation/corrected'), (P / 'portability', 'preparation/portability'),
                       (P / 'postinstall', 'postinstall')]:
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.name != 'collect.py':
            add(prefix + '/' + path.name, path)
for suffix in ['prepared', 'prepared пробел']:
    tree('preparation/final/' + suffix, P / 'final' / suffix)
for path in sorted(E.iterdir()):
    if path.is_file():
        add('execution/' + path.name, path)
for name in ['prepare.json', 'build.json', 'candidate пробел/candidate.json',
             'candidate пробел/source-verification.json']:
    add('runtime-provenance/' + name, M / 'coordinated-soft3-release-3' / name)
add('independent-review.json', M / 'coordinated-soft3-release-3/independent-preparer-review.json')
add('collector.py', Path(__file__))
rows = [{'path': name, 'original_path': str(path), **identity(path)} for name, path in sorted(selected.items())]
OUT.mkdir(parents=True, exist_ok=False)
payload = OUT / 'evidence.tar.gz'
stored = {}
with payload.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for row in rows:
                info = tarfile.TarInfo(row['path'])
                info.mode = 0o644
                key = (row['bytes'], row['sha256'])
                if key in stored:
                    info.type = tarfile.LNKTYPE
                    info.linkname = stored[key]
                    tar.addfile(info)
                else:
                    info.size = row['bytes']
                    stored[key] = row['path']
                    with selected[row['path']].open('rb') as data:
                        tar.addfile(info, data)
if payload.stat().st_size > 50_000_000:
    raise ValueError('retention compressed bound')
expected = {row['path']: row for row in rows}
seen = set()
with tarfile.open(payload, 'r:gz') as tar:
    for item in tar:
        if item.name not in expected or item.name in seen or not (item.isfile() or item.islnk()):
            raise ValueError('unexpected tar member')
        seen.add(item.name)
        data = tar.extractfile(item).read()
        row = expected[item.name]
        if data != selected[item.name].read_bytes() or len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise ValueError('original byte comparison failed')
if seen != expected.keys():
    raise ValueError('missing archive member')
for index in range(0, len(rows), 250):
    path = OUT / f'files-{index // 250:02}.json'
    path.write_text('[\n' + ',\n'.join(json.dumps(row, ensure_ascii=False, sort_keys=True) for row in rows[index:index + 250]) + '\n]\n')
receipt = dict(schema='trident/supplied-compiler-retention/v1', status='retained',
               source_revision=execution['source_revision'], execution_status=execution['status'],
               archive=dict(path=payload.name, **identity(payload)), members=len(rows),
               raw_bytes=sum(row['bytes'] for row in rows), stored_contents=len(stored),
               exact_original_byte_comparison=True, gzip_mtime=0, tar_mtime=0,
               compression='deterministic gzip; identical raw files share ordinary tar hardlinks',
               execution_source_capture=load(P / 'corrected/gates.json')['after'],
               delivery_source_capture=load(P / 'portability/receipt.json')['after'],
               preparation=identity(P / 'final/measurement.json'), execution=identity(E / 'receipt.json'),
               postinstall=identity(P / 'postinstall/receipt.json'),
               fixture=dict(path='scripts/fixtures/selfhost-kit-metadata.tar.gz',
                            **identity(W / 'scripts/fixtures/selfhost-kit-metadata.tar.gz')),
               raw_fixture_origin=str(M / 'selfhost-kit/rehearsal-1/kit'),
               external_joy=dict(path=str(M / 'coordinated-soft3-release-3/candidate пробел/bin/joy'),
                                 **identity(M / 'coordinated-soft3-release-3/candidate пробел/bin/joy')),
               scope='Historical rehearsal transport and one guest self-build; no accepted-kit positive, matrix/corpus/proof closure')
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, sort_keys=True))

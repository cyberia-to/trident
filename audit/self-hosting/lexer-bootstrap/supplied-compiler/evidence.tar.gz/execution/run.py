"""One actual C2(S1) run using existing exact prepared bytes and installed Joy."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
M = R / 'measurements'
OUT = Path(__file__).resolve().parent
PREP = M / 'selfhost-source-preparation/final/prepared'
JOY = M / 'coordinated-soft3-release-3/candidate пробел/bin/joy'
BASELINE = M / 'lexer-v9-c2-to-c3.json'
COMPILER = '76a07c08265bd2ef525164472b6b53ac3f0e6cbbedce3250c4202f40ffba34c8'
JOB = '3474e5583e7b3ac36bdd526435bb2ae584691774a009e29ca02407c22589f13d'
FLAGS = ['--arena-nodes', '1000000000', '--budget', '20000000000', '--frames', '65536',
         '--time-ms', '7200000', '--validation-visits', '16777216',
         '--resident-nodes', '3145728', '--collection-work', '10000000000']


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def load(path):
    return json.loads(path.read_bytes())


def required(value, message):
    if not value:
        raise ValueError(message)


def prepared_inputs():
    receipt = load(PREP / 'receipt.json')
    required(receipt['status'] == 'prepared' and receipt['kit_status'] == 'rehearsal', 'qualified preparation')
    required(len(receipt['sources']) == 94, 'full source count')
    for name, row in receipt['files'].items():
        required(identity(PREP / name) == row, 'changed prepared file: ' + name)
    required(sum(row['bytes'] for row in receipt['sources'].values()) == 370544, 'complete source bytes')
    result = {name: identity(PREP / name) for name in ['compiler.dag', 'job.dag', 'package.json', 'receipt.json']}
    required(result['compiler.dag']['sha256'] == COMPILER and result['job.dag']['sha256'] == JOB, 'exact compiler/JOB')
    return dict(files=result, copied_sources=receipt['sources'])


def rss_tree(pid):
    raw = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,rss='], text=True)
    rows = [tuple(map(int, line.split())) for line in raw.splitlines()]
    selected = {pid}
    while True:
        following = selected | {child for child, parent, rss in rows if parent in selected}
        if selected == following:
            break
        selected = following
    samples = [dict(pid=child, ppid=parent, rss_kib=rss) for child, parent, rss in rows if child in selected]
    return dict(time_ns=time.time_ns(), processes=samples, tree_rss_kib=sum(row['rss_kib'] for row in samples))


report = dict(schema='trident/supplied-compiler-selfbuild/v1', status='preflight',
              scope='One historical supplied-C2 frozen-S1 rehearsal; no matrix/corpus/proof acceptance',
              started_ns=time.time_ns(), driver=identity(Path(__file__)),
              cwd=str(OUT), commands=[], guest_runs=1, host_flags=FLAGS,
              binary=dict(path=str(JOY), **identity(JOY)), baseline=dict(path=str(BASELINE), **identity(BASELINE)))


def flush():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')


process = None
try:
    install = load(M / 'selfhost-source-preparation/postinstall/receipt.json')
    required(install['status'] == 'passed' and not install['warning_lines'], 'postcommit installation')
    report['source_revision'] = install['before']['trident-selfbuild-guide']['revision']
    report['postinstall'] = identity(M / 'selfhost-source-preparation/postinstall/receipt.json')
    required(report['binary']['sha256'] == '4035bca898e760666206f445c939c784ea248bff4f82c2c4f0a75254c3c48885', 'pinned installed Joy')
    required(load(M / 'selfhost-source-preparation/final/measurement.json')['status'] == 'passed', 'actual pack gate')
    report['inputs_start'] = prepared_inputs()
    for source, name in [(PREP / 'receipt.json', 'preparation.json'),
                         (PREP / 'package.json', 'package.json'),
                         (M / 'selfhost-source-preparation/final/pack.stdout', 'admission.json'),
                         (BASELINE, 'baseline.json')]:
        with (OUT / name).open('xb') as dst:
            dst.write(source.read_bytes())
    (OUT / 'empty-path').mkdir()
    env = dict(os.environ, PATH=str(OUT / 'empty-path'))
    report['environment'] = dict(PATH=env['PATH'])
    report['unavailable_tools'] = {name: shutil.which(name, path=env['PATH']) for name in ['cargo', 'rustc', 'trident']}
    required(not any(report['unavailable_tools'].values()), 'no host compiler on PATH')
    argv = [str(JOY), 'run-artifact', str(PREP / 'compiler.dag'), '--input', str(PREP / 'job.dag'),
            '--emit', 'program', '--output', str(OUT / 'c3.dag'), *FLAGS]
    command = dict(argv=argv, cwd=str(OUT), status='running', started_ns=time.time_ns())
    report['commands'].append(command)
    with (OUT / 'stdout').open('xb') as out, (OUT / 'stderr').open('xb') as err, (OUT / 'rss.jsonl').open('x') as memory:
        process = subprocess.Popen(argv, cwd=OUT, env=env, stdout=out, stderr=err)
        report.update(status='running', pid=process.pid, sampled_peak_tree_rss_kib=0)
        flush()
        print(json.dumps(dict(status='running', pid=process.pid, receipt=str(OUT / 'receipt.json'))), flush=True)
        while True:
            sample = rss_tree(process.pid)
            memory.write(json.dumps(sample) + '\n')
            memory.flush()
            report['sampled_peak_tree_rss_kib'] = max(report['sampled_peak_tree_rss_kib'], sample['tree_rss_kib'])
            flush()
            try:
                code = process.wait(timeout=30)
                break
            except subprocess.TimeoutExpired:
                print(json.dumps(dict(status='running', elapsed_seconds=(time.time_ns() - command['started_ns']) // 1000000000,
                                      sampled_peak_tree_rss_kib=report['sampled_peak_tree_rss_kib'])), flush=True)
    command.update(status='completed', exit_code=code, ended_ns=time.time_ns(),
                   stdout=identity(OUT / 'stdout'), stderr=identity(OUT / 'stderr'))
    if code != 0:
        report.update(status='runtime-rejected', output_exists=(OUT / 'c3.dag').exists())
    else:
        execution = load(OUT / 'stdout')
        baseline = load(BASELINE)['execution']
        admission = load(OUT / 'admission.json')['package']
        required(execution['ok'] is True and execution['execution']['compiler_job']['status'] == 'success', 'guest compiler success')
        result = identity(OUT / 'c3.dag')
        required(result['sha256'] == COMPILER and (OUT / 'c3.dag').read_bytes() == (PREP / 'compiler.dag').read_bytes(), 'exact C3/C2 bytes')
        required(execution['execution']['program_particle'] == admission['compiler_particle'] and
                 execution['execution']['input_particle'] == admission['job_particle'], 'admission/execution binding')
        current_fields = {key: value for key, value in execution['execution'].items() if key != 'elapsed_micros'}
        baseline_fields = {key: value for key, value in baseline['execution'].items() if key != 'elapsed_micros'}
        required(current_fields == baseline_fields, 'all non-time execution fields')
        required(execution['published_particle'] == baseline['published_particle'], 'published compiler particle')
        report.update(status='passed', output=result, exact_c3_c2_bytes_equal=True,
                      non_time_execution_fields_equal=True, excluded_execution_fields=['elapsed_micros'],
                      elapsed_micros=execution['execution']['elapsed_micros'],
                      baseline_elapsed_micros=baseline['execution']['elapsed_micros'],
                      execution_summary={key: execution['execution'][key] for key in
                                         ['charged_reductions', 'allocated_nodes', 'peak_frames', 'program_particle', 'input_particle', 'output_particle']},
                      published_particle=execution['published_particle'])
except BaseException as error:
    report.update(status='failed', error=dict(kind=type(error).__name__, message=str(error)))
    raise
finally:
    report.update(ended_ns=time.time_ns(), binary_end=identity(JOY), inputs_end=prepared_inputs())
    if report['binary_end'] != {key: report['binary'][key] for key in ['bytes', 'sha256']} or report['inputs_end'] != report.get('inputs_start'):
        report['status'] = 'inputs-changed'
    flush()
raise SystemExit(0 if report['status'] == 'passed' else 1)

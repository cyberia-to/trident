"""Continue the exact local S1 bootstrap after its in-flight C1 execution.

Preserves actual stage results; this local continuation is separate from the
two clean origin repetitions and native CI platform acceptance.
"""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'measurements'
REPO = ROOT / 'trident-lexer'
JOY = ROOT / 'install-compiler-work-budget/bin/joy'
FIRST = HERE / 'lexer-v9-c1-to-c2.json'
SECOND = HERE / 'lexer-v9-c2-to-c3.json'
INVENTORY = HERE / 'lexer-v9-inventory.json'
REPORT = HERE / 'lexer-v9-followup.json'
PROFILE = ['--budget', '20000000000', '--arena-nodes', '1000000000',
           '--time-ms', '3600000', '--validation-visits', '16777216',
           '--resident-nodes', '3145728', '--collection-work', '10000000000']
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CARGO_TARGET_DIR=str(ROOT / 'target-probe'))
env.pop('PYTHONOPTIMIZE', None)
if sys.flags.optimize or REPORT.exists():
    raise RuntimeError('unoptimized Python and fresh evidence path required')
report = dict(scope='Local frozen S1 follow-up; clean repetitions/platforms remain separate',
              status='waiting-for-c1', script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              commands={})
lock = threading.Lock()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def flush():
    temporary = REPORT.with_suffix('.next.json')
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(REPORT)


def run(name, argv, timeout):
    command = list(map(str, argv))
    log = HERE / ('lexer-v9-' + name + '.log')
    row = dict(command=command, cwd=str(REPO), status='running', log=str(log))
    with lock:
        report['commands'][name] = row
        flush()
    print('started ' + name, flush=True)
    start = time.monotonic_ns()
    try:
        with log.open('x') as stream:
            child = subprocess.run(command, cwd=REPO, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, check=False, timeout=timeout)
        row.update(status='completed', exit_code=child.returncode)
        if child.returncode:
            raise RuntimeError(name + ' failed; see exact retained log')
    except BaseException as error:
        row.update(status='failed', error=str(error))
        raise
    finally:
        row.update(elapsed_nanoseconds=time.monotonic_ns() - start,
                   log_sha256=sha(log) if log.exists() else None)
        with lock:
            flush()
    print('completed ' + name, flush=True)


flush()
try:
    deadline = time.monotonic_ns() + 7_200_000_000_000
    while True:
        try:
            first = json.loads(FIRST.read_text())
        except json.JSONDecodeError:
            first = dict(status='running')
        if first['status'] != 'running':
            break
        if time.monotonic_ns() >= deadline:
            raise TimeoutError('waiting for separately bounded C1 execution')
        time.sleep(5)
    if first['status'] != 'compiler-returned' or first['published_kind'] != 'program':
        raise RuntimeError('C1 did not publish C2')
    compiler = Path(first['artifact_directory']) / 'result.dag'
    if sha(compiler) != first['result_sha256']:
        raise RuntimeError('actual C2 changed')
    report.update(status='running', first_receipt_sha256=sha(FIRST), compiler_sha256=sha(compiler))
    flush()
    with ThreadPoolExecutor(max_workers=3) as pool:
        second = pool.submit(run, 'c2-to-c3', [sys.executable, REPO / 'audit/self-hosting/probe-native-closure.py',
            '--joy', JOY, '--compiler', compiler, '--inventory', INVENTORY,
            '--output', SECOND, *PROFILE, '--emit', 'program'], 4000)
        c2_corpus = pool.submit(run, 'c2-corpus-launcher', [sys.executable,
            HERE / 'lexer-v9-c2-corpus/run.py'], 5400)
        scale = pool.submit(run, 'c2-source-scale', [sys.executable,
            ROOT / 'trident/audit/self-hosting/source-scale-compacting/check.py',
            '--joy', JOY, '--joy-sha256', sha(JOY), '--compiler', compiler,
            '--compiler-sha256', sha(compiler), '--producer-receipt', FIRST,
            '--producer-receipt-sha256', sha(FIRST), '--output', HERE / 'lexer-v9-c2-source-scale.json'], 7200)
        second.result()
        run('fixed-point', [sys.executable, REPO / 'audit/self-hosting/check-selfhost-fixed-point.py',
            '--first', FIRST, '--second', SECOND, '--inventory-checker',
            ROOT / 'target-probe/release/examples/selfhost_inventory', '--joy', JOY,
            '--output', HERE / 'lexer-v9-fixed-point.json'], 300)
        c3_corpus = pool.submit(run, 'c3-corpus-launcher', [sys.executable,
            HERE / 'lexer-v9-c3-corpus/run.py'], 5400)
        for future in (c2_corpus, scale, c3_corpus):
            future.result()
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='failed', error=str(error))
    raise
finally:
    flush()

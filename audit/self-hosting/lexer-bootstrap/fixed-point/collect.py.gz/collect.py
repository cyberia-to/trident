"""Archive the completed S1 fixed point without changing execution receipts."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

if sys.flags.optimize:
    raise RuntimeError('unoptimized Python is required')
ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'trident'
MEASUREMENTS = ROOT / 'measurements'
AUDIT = REPO / 'audit/self-hosting/lexer-bootstrap'
OUT = AUDIT / 'fixed-point'
SOURCE = '77213171d39b88c5f41221912251cc4813ac2b11'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


first_path = MEASUREMENTS / 'lexer-v9-c1-to-c2.json'
second_path = MEASUREMENTS / 'lexer-v9-c2-to-c3.json'
comparison_path = MEASUREMENTS / 'lexer-v9-fixed-point.json'
first, second, comparison = map(read_json, (first_path, second_path, comparison_path))
assert comparison['status'] == 'passed'
assert first['status'] == second['status'] == 'compiler-returned'
assert first['published_kind'] == second['published_kind'] == 'program'
assert (AUDIT / 'c1-to-c2.json').read_bytes() == first_path.read_bytes()
assert len(first['sources']) == len(second['sources']) == 94
for row, receipt in zip(comparison['steps'], (first_path, second_path)):
    assert row['receipt_sha256'] == sha(receipt.read_bytes())
assert comparison['fixed_point']['compiler_chain_bound'] is True
assert comparison['fixed_point']['exact_artifact_bytes_equal'] is True
assert first['compiler_sha256'] != first['result_sha256']
assert first['result_sha256'] == second['compiler_sha256'] == second['result_sha256']
first_dir, second_dir = (Path(step['artifact_directory']) for step in (first, second))
assert first_dir != second_dir
assert Path(second['compiler']).resolve() == (first_dir / 'result.dag').resolve()
assert (first_dir / 'result.dag').read_bytes() == (second_dir / 'result.dag').read_bytes()
assert sha((second_dir / 'result.dag').read_bytes()) == second['result_sha256']
assert first['host_flags'] == second['host_flags']
assert first['binary_sha256'] == second['binary_sha256']
assert first['inventory_sha256'] == second['inventory_sha256']
with tarfile.open(AUDIT / 'sources.tar.gz') as archive:
    manifest = archive.extractfile('package.json').read()
    assert manifest == (first_dir / 'package.json').read_bytes() == (second_dir / 'package.json').read_bytes()
    for module in json.loads(manifest)['modules']:
        name = module['logical_path']
        a, b = first['sources'][name], second['sources'][name]
        raw = archive.extractfile(module['file']).read()
        assert raw == Path(a['copy']).read_bytes() == Path(b['copy']).read_bytes()
        assert sha(raw) == a['sha256'] == b['sha256']
        assert raw == subprocess.check_output(['git', 'show', SOURCE + ':' + a['path']], cwd=REPO)
followup = read_json(MEASUREMENTS / 'lexer-v9-followup.json')
checker_row = followup['commands']['fixed-point']
assert checker_row['status'] == 'completed' and checker_row['exit_code'] == 0
checker = Path(checker_row['command'][1])
assert checker.read_bytes() == (REPO / 'audit/self-hosting/check-selfhost-fixed-point.py').read_bytes()
OUT.mkdir(exist_ok=False)
files = {}


def retain(path, name, compress=False):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0) if compress else raw
    with (OUT / name).open('xb') as output:
        output.write(stored)
    files[name] = dict(original=str(path), original_sha256=sha(raw), original_bytes=len(raw),
                       sha256=sha(stored), bytes=len(stored))


retain(second_path, 'c2-to-c3.json')
retain(comparison_path, 'comparison.json')
retain(second_dir / 'result.dag', 'c3.dag.gz', True)
retain(second_dir / 'job.dag', 'job2.dag.gz', True)
retain(checker, 'check-selfhost-fixed-point.py.gz', True)
retain(Path(checker_row['log']), 'comparison.log.gz', True)
retain(Path(__file__), 'collect.py.gz', True)
report = dict(schema='trident/full-source-fixed-point-artifacts/v1', source_revision=SOURCE,
    scope='Actual S1 C1(S)->C2->C3 byte fixed point; semantic and clean-platform gates separate',
    first_receipt='../c1-to-c2.json', first_receipt_sha256=sha(first_path.read_bytes()),
    source_archive='../sources.tar.gz', source_archive_sha256=sha((AUDIT / 'sources.tar.gz').read_bytes()),
    all_94_second_source_files_and_manifest_byte_identical_to_archived_first=True,
    all_94_source_files_match_committed_source=True,
    checker_command=checker_row, checker_sha256=sha(checker.read_bytes()), files=files)
(OUT / 'artifacts.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='retained', compiler_sha256=second['result_sha256'], output=str(OUT))))
